import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { setDb, migrate, getDb } from '../src/db/db';
import { openNodeDb } from './nodeDb';
import { profilesRepo, dollarRepo, dollarAlertsRepo, subscriptionsRepo, feedRepo, assistantRepo, financeRepo, tasksRepo, goalsRepo, goalProgress, remindersRepo, habitsRepo, countdownsRepo, routinesRepo } from '../src/db/repos';
import { defaultSettings } from '../src/db/defaults';
import { exportProfile, restoreProfile } from '../src/db/backup';
import { parseDolarApi, parseArgentinaDatos, evaluateAlerts, seriesFor, variation, formatPesos, describeAlert } from '../src/logic/dollar';
import { nextCycleDate, daysUntilCharge, rolledDate, monthlyAmount, totals, matchSubscription, shouldRenewOnPayment, cycleProgress } from '../src/logic/subscriptions';
import { parseRss, newsFeedUrl, rankItems, adjustWeight, topicsFromInterests, splitSourceFromTitle, topicDef, stripHtml } from '../src/logic/discover';
import { parseIntent, extractAmount, extractDate, extractTime, guessCategory } from '../src/assistant/intents';
import { loadAssistantData, respond, dailyMessage } from '../src/assistant/engine';
import { applyConfirm } from '../src/assistant/actions';
import { buildNotificationPlan } from '../src/logic/notificationPlan';
import type { DollarRate, DiscoverItem, Profile } from '../src/types';

let A = 0;
let B = 0;
const mk = (name: string) => profilesRepo.create({ name, birthDate: null, age: null, avatarColor: '#8B5CF6', answers: { wakeTime: '07:00' }, settings: { ...defaultSettings(), modules: { countdown: true, routines: true, dollar: true, subscriptions: true, feed: true, assistant: true, salary: true, holidays: true, transport: true, watchlist: true } }, securityQuestion: 'q' });

before(async () => {
  const db = openNodeDb();
  setDb(db);
  await migrate(db);
  A = await mk('Ana');
  B = await mk('Beto');
});

// ---------- Dólar ----------

test('dólar: interpreta DolarAPI y ArgentinaDatos, series y variación', () => {
  const now = new Date(2026, 10, 5, 20, 0);
  const rates = parseDolarApi([
    { moneda: 'USD', casa: 'blue', nombre: 'Blue', compra: 1465, venta: 1485, fechaActualizacion: '2026-11-05T22:30:00.000Z' },
    { moneda: 'USD', casa: 'oficial', nombre: 'Oficial', compra: 1025, venta: 1045, fechaActualizacion: '2026-11-05T22:30:00.000Z' },
    { casa: 'desconocida', compra: 1, venta: 2 },
    { casa: 'cripto', compra: 'x', venta: null },
  ], now);
  assert.equal(rates.length, 2);
  assert.equal(rates[0].sell, 1485);
  assert.equal(rates[0].date, '2026-11-05');
  const hist = parseArgentinaDatos([{ casa: 'blue', compra: 1440, venta: 1460, fecha: '2026-11-04' }, { casa: 'blue', compra: 1430, venta: 1448, fecha: '2026-11-03' }, { fecha: 'mal' }], 'blue');
  assert.equal(hist.length, 2);
  const all = [...rates.filter((r) => r.casa === 'blue'), ...hist];
  const s = seriesFor(all, 7, now);
  assert.deepEqual(s.map((p) => p.value), [1448, 1460, 1485]);
  const v = variation(all, 'blue')!;
  assert.equal(v.abs, 25);
  assert.equal(v.prevDate, '2026-11-04');
  assert.equal(formatPesos(1485), '$ 1.485');
  assert.equal(formatPesos(1485.5), '$ 1.485,50');
});

test('dólar: alertas se disparan una vez y respetan el umbral', () => {
  const now = new Date(2026, 10, 5, 20, 0);
  const rates: DollarRate[] = [
    { casa: 'blue', date: '2026-11-05', buy: 1465, sell: 1485, updatedAt: now.toISOString() },
    { casa: 'blue', date: '2026-11-04', buy: 1440, sell: 1450, updatedAt: now.toISOString() },
  ];
  const base = { id: 1, profileId: A, casa: 'blue' as const, enabled: true, lastFiredAt: null, createdAt: '2026-11-01T00:00:00' };
  const hits = evaluateAlerts([
    { ...base, id: 1, kind: 'above', value: 1480 },
    { ...base, id: 2, kind: 'above', value: 1500 },
    { ...base, id: 3, kind: 'below', value: 1490 },
    { ...base, id: 4, kind: 'change', value: 2 },
    { ...base, id: 5, kind: 'change', value: 5 },
    { ...base, id: 6, kind: 'above', value: 1400, lastFiredAt: '2026-11-05T19:00:00' },
    { ...base, id: 7, kind: 'above', value: 1400, enabled: false },
  ], rates, now);
  assert.deepEqual(hits.map((h) => h.alert.id).sort(), [1, 3, 4]);
  assert.ok(hits[0].title.includes('1.480'));
  assert.equal(describeAlert({ casa: 'blue', kind: 'change', value: 2 }), 'Blue sube o baja más de 2,0% en el día');
});

test('dólar: repos guardan cotizaciones y alertas por perfil', async () => {
  await dollarRepo.upsertMany([
    { casa: 'blue', date: '2026-11-05', buy: 1465, sell: 1485, updatedAt: '2026-11-05T22:00:00.000Z' },
    { casa: 'blue', date: '2026-11-04', buy: 1440, sell: 1450, updatedAt: '2026-11-04T22:00:00.000Z' },
    { casa: 'tarjeta', date: '2026-11-05', buy: 1350, sell: 1360, updatedAt: '2026-11-05T22:00:00.000Z' },
  ]);
  await dollarRepo.upsert({ casa: 'blue', date: '2026-11-05', buy: 1470, sell: 1490, updatedAt: '2026-11-05T23:00:00.000Z' });
  const latest = await dollarRepo.latest();
  assert.equal(latest.find((r) => r.casa === 'blue')?.sell, 1490, 'upsert actualiza el día');
  assert.equal((await dollarRepo.series('blue', '2026-11-01', '2026-11-05')).length, 2);
  const id = await dollarAlertsRepo.create(A, { casa: 'blue', kind: 'above', value: 1500, enabled: true });
  await dollarAlertsRepo.create(B, { casa: 'oficial', kind: 'below', value: 1000, enabled: true });
  assert.equal((await dollarAlertsRepo.list(A)).length, 1);
  assert.equal((await dollarAlertsRepo.listAll()).length, 2);
  await dollarAlertsRepo.remove(B, id);
  assert.equal((await dollarAlertsRepo.list(A)).length, 1, 'otro perfil no puede borrar');
  await assert.rejects(dollarAlertsRepo.create(A, { casa: 'blue', kind: 'above', value: 0, enabled: true }));
});

// ---------- Suscripciones ----------

test('suscripciones: ciclos, días, renovación, totales y vínculo con gastos', async () => {
  const now = new Date(2026, 10, 5);
  assert.equal(nextCycleDate('2026-01-31', 'monthly'), '2026-02-28');
  assert.equal(nextCycleDate('2026-11-05', 'weekly'), '2026-11-12');
  assert.equal(nextCycleDate('2026-11-05', 'yearly'), '2027-11-05');
  assert.equal(daysUntilCharge({ nextDate: '2026-11-07' }, now), 2);
  assert.equal(rolledDate({ nextDate: '2026-08-10', cycle: 'monthly' }, now), '2026-11-10');
  assert.equal(rolledDate({ nextDate: '2026-11-10', cycle: 'monthly' }, now), null);
  assert.equal(monthlyAmount({ amount: 120000, cycle: 'yearly' }), 10000);
  assert.equal(monthlyAmount({ amount: 1000, cycle: 'weekly' }), 4333);
  assert.ok(cycleProgress({ nextDate: '2026-11-07', cycle: 'monthly' }, now) > 80);
  const subs = [
    { id: 1, profileId: A, name: 'Streaming de series', icon: 'Tv', color: '#f00', amount: 1490000, currency: 'ARS' as const, cycle: 'monthly' as const, nextDate: '2026-11-07', remindDaysBefore: 2, active: true, category: 'Entretenimiento', createdAt: '' },
    { id: 2, profileId: A, name: 'Juegos online', icon: 'Gamepad2', color: '#00f', amount: 1200, currency: 'USD' as const, cycle: 'monthly' as const, nextDate: '2026-11-24', remindDaysBefore: null, active: true, category: 'Juegos', createdAt: '' },
    { id: 3, profileId: A, name: 'Gym', icon: 'Dumbbell', color: '#0f0', amount: 500000, currency: 'ARS' as const, cycle: 'monthly' as const, nextDate: '2026-11-01', remindDaysBefore: null, active: false, category: 'Salud', createdAt: '' },
  ];
  const t = totals(subs, 1360);
  assert.equal(t.count, 2);
  assert.equal(t.monthlyArs, 1490000 + Math.round(1200 * 1360));
  assert.equal(t.monthlyUsd, 1200);
  assert.equal(totals(subs, null).hasUnconvertedUsd, true);
  assert.equal(matchSubscription(subs, { name: 'streaming de series', kind: 'expense' })?.id, 1);
  assert.equal(matchSubscription(subs, { name: 'Gym', kind: 'expense' }), null, 'las pausadas no cuentan');
  assert.equal(matchSubscription(subs, { name: 'Streaming de series', kind: 'income' }), null);
  assert.equal(shouldRenewOnPayment({ nextDate: '2026-11-07', cycle: 'monthly' }, '2026-11-05'), true);
  assert.equal(shouldRenewOnPayment({ nextDate: '2026-11-07', cycle: 'monthly' }, '2026-10-20'), false);

  const id = await subscriptionsRepo.create(A, { name: 'Música', icon: 'Music', color: '#0f0', amount: 850000, currency: 'ARS', cycle: 'monthly', nextDate: '2026-11-17', remindDaysBefore: 2, active: true, category: 'Entretenimiento' });
  assert.equal(await subscriptionsRepo.get(B, id), null);
  await subscriptionsRepo.setNextDate(B, id, '2030-01-01');
  assert.equal((await subscriptionsRepo.get(A, id))?.nextDate, '2026-11-17', 'otro perfil no modifica');
  const plan = buildNotificationPlan({ profileId: A, profileName: 'Ana', settings: defaultSettings().notifications, tasks: [], events: [], habits: [], reminders: [], goals: [], subscriptions: await subscriptionsRepo.list(A), now: new Date(2026, 10, 5, 8) });
  const ids = plan.map((n) => n.id);
  assert.ok(ids.includes(`p${A}:sub:${id}:pre`));
  assert.ok(ids.includes(`p${A}:sub:${id}:day`));
  assert.equal(plan.find((n) => n.id === `p${A}:sub:${id}:pre`)?.title, 'En 2 días se cobra Música');
});

test('metas de ahorro: el progreso sale del monto ahorrado', async () => {
  assert.equal(goalProgress({ progress: 10, savingTarget: 100000, savingSaved: 25000 }), 25);
  assert.equal(goalProgress({ progress: 40, savingTarget: null, savingSaved: 0 }), 40);
  const id = await goalsRepo.create(A, { title: 'Ahorrar para la bici', description: '', term: 'short', targetDate: null, progress: 0, savingTarget: 50000, savingSaved: 10000, savingCurrency: 'USD', savingCasa: 'blue' });
  let g = (await goalsRepo.get(A, id))!;
  assert.equal(g.progress, 20);
  assert.equal(g.savingCurrency, 'USD');
  await goalsRepo.addSaving(A, id, 40000);
  g = (await goalsRepo.get(A, id))!;
  assert.equal(g.progress, 100);
  assert.ok(g.completedAt, 'al llegar al monto se marca alcanzado');
  // Un objetivo viejo (sin ahorro) sigue funcionando igual
  const id2 = await goalsRepo.create(A, { title: 'Leer', description: '', term: 'short', targetDate: null, progress: 30 });
  assert.equal((await goalsRepo.get(A, id2))?.progress, 30);
});

// ---------- Descubrir ----------

test('descubrir: lector RSS, fuente del título, orden y aprendizaje', () => {
  const xml = `<?xml version="1.0"?><rss><channel><title>x</title>
    <item><title><![CDATA[Se confirmó la cartelera &amp; más - Olé]]></title><link>https://ejemplo.com/nota-1</link><pubDate>Thu, 05 Nov 2026 12:00:00 GMT</pubDate><description><![CDATA[<a href="x">Dos peleas</a> por el título &lt;b&gt;]]></description><source url="https://ole.com.ar">Olé</source></item>
    <item><title>Sin link</title><description>x</description></item>
    <item><title>Con imagen</title><link>https://ejemplo.com/nota-2</link><media:content url="https://img.ejemplo.com/a.jpg" medium="image"/><pubDate>Wed, 04 Nov 2026 12:00:00 GMT</pubDate></item>
  </channel></rss>`;
  const items = parseRss(xml);
  assert.equal(items.length, 2);
  assert.equal(items[0].title, 'Se confirmó la cartelera & más - Olé');
  assert.equal(items[0].link, 'https://ejemplo.com/nota-1');
  assert.equal(items[0].summary, 'Dos peleas por el título <b>');
  assert.equal(items[0].source, 'Olé');
  assert.equal(items[1].imageUrl, 'https://img.ejemplo.com/a.jpg');
  assert.deepEqual(splitSourceFromTitle('Se confirmó la cartelera - Olé', 'Olé'), { title: 'Se confirmó la cartelera', source: 'Olé' });
  assert.deepEqual(splitSourceFromTitle('Título raro', ''), { title: 'Título raro', source: '' });
  assert.equal(stripHtml('<p>Hola &amp; chau</p>'), 'Hola & chau');
  assert.ok(newsFeedUrl('UFC MMA').startsWith('https://news.google.com/rss/search?q=UFC%20MMA&hl=es-419&gl=AR'));
  assert.deepEqual(topicsFromInterests(['Videojuegos', 'Cine y series', 'Rarísimo']), ['Videojuegos', 'Cine']);
  assert.equal(topicDef('ufc').key, 'UFC');
  assert.equal(topicDef('Boca').query, 'Boca');
  const w = adjustWeight(adjustWeight({}, 'UFC', 2), 'Cine', -2);
  assert.deepEqual(w, { UFC: 2, Cine: -2 });
  const now = new Date('2026-11-05T20:00:00Z');
  const mkItem = (id: number, topic: string, hoursAgo: number): DiscoverItem => ({ id, profileId: A, topic, title: `n${id}`, summary: '', url: `https://x/${id}`, source: '', imageUrl: null, publishedAt: new Date(now.getTime() - hoursAgo * 3600_000).toISOString(), saved: false, hidden: false, opened: false, fetchedAt: '' });
  const ranked = rankItems([mkItem(1, 'Cine', 1), mkItem(2, 'UFC', 3), mkItem(3, 'UFC', 4), mkItem(4, 'UFC', 5), mkItem(5, 'Cine', 2)], w, now);
  assert.equal(ranked[0].topic, 'UFC', 'el tema con más peso sube');
  for (let i = 2; i < ranked.length; i++) assert.ok(!(ranked[i].topic === ranked[i - 1].topic && ranked[i].topic === ranked[i - 2].topic), 'no más de 2 seguidas del mismo tema');
});

test('feed: repos por perfil, sin duplicados y con límite', async () => {
  const items = [1, 2, 3].map((i) => ({ kind: 'news' as const, topic: 'UFC', externalId: `news:https://x/${i}`, title: `Nota ${i}`, text: '', url: `https://x/${i}`, author: 'Olé', imageUrl: null, publishedAt: `2026-11-0${i}T12:00:00.000Z`, likes: null, extra: {} }));
  assert.equal(await feedRepo.addMany(A, items), 3);
  assert.equal(await feedRepo.addMany(A, items), 0, 'no repite por id externo');
  assert.equal(await feedRepo.addMany(B, items.slice(0, 1)), 1, 'otro perfil tiene su propia copia');
  const list = await feedRepo.list(A);
  assert.equal(list.length, 3);
  assert.equal(list[0].title, 'Nota 3', 'más nuevo primero');
  await feedRepo.setFlag(A, list[0].id, 'saved', true);
  await feedRepo.setFlag(A, list[1].id, 'hidden', true);
  assert.equal((await feedRepo.list(A)).length, 2);
  assert.equal((await feedRepo.saved(A)).length, 1);
  await feedRepo.setFlag(B, list[0].id, 'hidden', true);
  assert.equal((await feedRepo.get(A, list[0].id))?.hidden, false, 'otro perfil no modifica');
  await feedRepo.prune(A, 'news', 1);
  assert.equal((await feedRepo.saved(A)).length, 1, 'los guardados no se borran');
  await feedRepo.pruneTopics(A, 'news', ['Cine']);
  assert.equal((await feedRepo.list(A)).filter((x) => !x.saved).length, 0, 'se borran las de temas quitados');
});

// ---------- Amigo ----------

test('amigo: entiende frases en español', () => {
  const ctx = { today: '2026-11-05' }; // jueves
  assert.deepEqual(extractAmount('gaste 3.500 en el super'), { cents: 350000, rest: 'gaste en el super' });
  assert.equal(extractAmount('me gaste $ 1200,50').cents, 120050);
  assert.equal(extractAmount('pague 2 lucas de nafta').cents, 200000);
  assert.equal(extractDate('tengo examen el lunes', ctx).date, '2026-11-09');
  assert.equal(extractDate('pasado manana', ctx).date, '2026-11-07');
  assert.equal(extractDate('el 25/12', ctx).date, '2026-12-25');
  assert.equal(extractDate('el 3 de enero', ctx).date, '2027-01-03');
  assert.equal(extractTime('llamar a las 10').time, '10:00');
  assert.equal(extractTime('a las 8 de la noche').time, '20:00');
  assert.equal(extractTime('reunion 14:30').time, '14:30');
  assert.equal(guessCategory('nafta'), 'Transporte');
  assert.equal(guessCategory('supermercado'), 'Comida');

  const e = parseIntent('Gasté 3500 en el súper', ctx);
  assert.equal(e.type, 'add_expense');
  if (e.type === 'add_expense') { assert.equal(e.amount, 350000); assert.equal(e.name, 'Súper'); assert.equal(e.date, '2026-11-05'); }
  const e2 = parseIntent('ayer pague 2500 de nafta', ctx);
  if (e2.type === 'add_expense') { assert.equal(e2.date, '2026-11-04'); assert.equal(e2.name, 'Nafta'); } else assert.fail('gasto con fecha');
  const r = parseIntent('recordame llamar al medico mañana a las 10', ctx);
  assert.equal(r.type, 'add_reminder');
  if (r.type === 'add_reminder') { assert.equal(r.title, 'Llamar al medico'); assert.equal(r.date, '2026-11-06'); assert.equal(r.time, '10:00'); }
  const tk = parseIntent('tengo que estudiar fisica el viernes', ctx);
  assert.equal(tk.type, 'add_task');
  if (tk.type === 'add_task') { assert.equal(tk.title, 'Estudiar fisica'); assert.equal(tk.date, '2026-11-06'); }
  const inc = parseIntent('cobre 150000 del laburo', ctx);
  assert.equal(inc.type, 'add_income');
  assert.deepEqual(parseIntent('¿Cuánto gasté esta semana?', ctx), { type: 'spending', period: 'week', category: null });
  assert.deepEqual(parseIntent('cuanto gaste en comida este mes', ctx), { type: 'spending', period: 'month', category: 'Comida' });
  assert.deepEqual(parseIntent('que tengo pendiente mañana', ctx), { type: 'pending', date: '2026-11-06', label: 'mañana' });
  assert.deepEqual(parseIntent('¿Qué hice hoy?', ctx), { type: 'summary', period: 'today' });
  assert.deepEqual(parseIntent('a cuanto esta el dolar blue', ctx), { type: 'dollar', casa: 'blue' });
  assert.deepEqual(parseIntent('como voy con mis objetivos', ctx), { type: 'goals' });
  assert.equal(parseIntent('cuanto me falta para pagar netflix', ctx).type, 'subscriptions');
  assert.equal(parseIntent('cuanto falta para el viaje', ctx).type, 'countdown');
  assert.equal(parseIntent('hola', ctx).type, 'greet');
  assert.equal(parseIntent('llamate Max', ctx).type, 'rename');
  assert.equal(parseIntent('se mas directo', ctx).type, 'personality');
  assert.equal(parseIntent('asdfgh qwerty', ctx).type, 'unknown');
});

test('amigo: responde con datos reales, sólo del perfil, y anota con confirmación', async () => {
  await financeRepo.create(A, { kind: 'expense', name: 'Súper', emoji: '', category: 'Comida', quantity: 1, unitPrice: null, amount: 1890000, date: '2026-11-05', description: '' });
  await financeRepo.create(A, { kind: 'expense', name: 'Bondi', emoji: '', category: 'Transporte', quantity: 1, unitPrice: null, amount: 110000, date: '2026-11-03', description: '' });
  await financeRepo.create(B, { kind: 'expense', name: 'Secreto', emoji: '', category: 'Otros', quantity: 1, unitPrice: null, amount: 99900000, date: '2026-11-05', description: '' });
  await tasksRepo.create(A, { title: 'Entregar informe', description: '', dueDate: '2026-11-06', dueTime: '10:00', priority: 2, category: '', remindMinutes: null });
  await habitsRepo.create(A, { title: 'Leer', frequency: 'daily', weekdays: [], targetPerWeek: 3, reminderTime: null, color: '#fff', icon: 'BookOpen' });
  await countdownsRepo.create(A, { title: 'Viaje a Córdoba', date: '2026-11-17', time: null, icon: 'Plane', color: '#fff', remindDaysBefore: null, pinned: true });
  const profile = (await profilesRepo.get(A))!;
  const data = await loadAssistantData(profile);
  const now = new Date(2026, 10, 5, 21, 0);

  let r = respond('cuanto gaste esta semana', data, now);
  assert.ok(r.text.includes('$ 20.000'), r.text);
  assert.ok(!r.text.includes('999'), 'no mezcla gastos de otro perfil');
  assert.equal(r.payload?.kind, 'bars');
  r = respond('cuanto gaste en comida esta semana', data, now);
  assert.ok(r.text.includes('18.900'));
  r = respond('que tengo pendiente mañana', data, now);
  assert.ok(r.text.includes('Entregar informe'));
  r = respond('cuanto falta para el viaje', data, now);
  assert.ok(r.text.toLowerCase().includes('faltan 12 días'));
  r = respond('a cuanto esta el dolar', data, now);
  assert.ok(r.text.includes('1.490'), r.text);
  r = respond('que hice hoy', data, now);
  assert.ok(r.text.includes('18.900'));
  r = respond('algo sin sentido zzz', data, now);
  assert.equal(r.payload?.kind, 'chips');

  r = respond('gaste 3500 en nafta', data, now);
  assert.equal(r.payload?.kind, 'confirm');
  if (r.payload?.kind === 'confirm') {
    assert.equal(r.payload.data.amount, 350000);
    assert.equal(r.payload.data.category, 'Transporte');
    const before = (await financeRepo.list(A)).length;
    await applyConfirm(A, r.payload);
    assert.equal((await financeRepo.list(A)).length, before + 1, 'sólo guarda al confirmar');
  }
  r = respond('recordame pagar el gym el lunes a las 9', data, now);
  if (r.payload?.kind === 'confirm') {
    await applyConfirm(A, r.payload);
    const rem = await remindersRepo.list(A);
    assert.ok(rem.some((x) => x.title === 'Pagar el gym' && x.date === '2026-11-09' && x.time === '09:00'));
  } else assert.fail('recordatorio');
  const dm = dailyMessage(data, now)!;
  assert.ok(dm.includes('Ana'));
  assert.ok(dm.includes('Viaje a Córdoba'));

  await assistantRepo.add(A, 'user', 'hola');
  await assistantRepo.add(A, 'assistant', 'Hola', { kind: 'chips', items: [] });
  assert.equal((await assistantRepo.list(A)).length, 2);
  assert.equal((await assistantRepo.list(B)).length, 0);
  await assistantRepo.clear(A);
  assert.equal((await assistantRepo.list(A)).length, 0);
});

// ---------- Copia y borrado ----------

test('copia v3 incluye todo lo nuevo y borrar el perfil lo limpia', async () => {
  await assistantRepo.add(A, 'user', 'x');
  const bk = await exportProfile(A);
  assert.equal(bk.version, 4);
  assert.ok(bk.tables.subscriptions.length >= 1);
  assert.ok(bk.tables.dollar_alerts.length >= 1);
  assert.ok(bk.tables.assistant_messages.length >= 1);
  const C = await mk('Copia');
  await restoreProfile(C, bk, { restoreSettings: true });
  assert.equal((await subscriptionsRepo.list(C)).length, bk.tables.subscriptions.length);
  assert.equal((await goalsRepo.list(C)).find((g) => g.title === 'Ahorrar para la bici')?.savingTarget, 50000);
  assert.equal((await profilesRepo.get(C))?.settings.modules.dollar, true);
  await profilesRepo.remove(C);
  const db = getDb();
  for (const t of ['subscriptions', 'dollar_alerts', 'discover_items', 'assistant_messages', 'goals']) {
    assert.equal((await db.all(`SELECT * FROM ${t} WHERE profile_id = ?`, [C])).length, 0, t);
  }
});
