import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { setDb, migrate, getDb, SCHEMA_VERSION } from '../src/db/db';
import { openNodeDb } from './nodeDb';
import { profilesRepo, countdownsRepo, routinesRepo, tasksRepo, financeRepo } from '../src/db/repos';
import { defaultSettings, mergeSettings, defaultModules } from '../src/db/defaults';
import { exportProfile, restoreProfile } from '../src/db/backup';
import { daysLeft, daysLabel, remaining, progress, sortCountdowns, featured } from '../src/logic/countdown';
import { routineProgress, routineStreak, stepTimes, routineHistory, isRoutineScheduledOn, currentStep } from '../src/logic/routines';
import { searchItems, groupResults, loadSearchData } from '../src/logic/search';
import { buildNotificationPlan } from '../src/logic/notificationPlan';
import { MODULES, isModuleOn } from '../src/modules/registry';
import type { Routine, RoutineLog } from '../src/types';

let A = 0;
let B = 0;

const mkProfile = (name: string) => profilesRepo.create({ name, birthDate: null, age: null, avatarColor: '#8B5CF6', answers: {}, settings: defaultSettings(), securityQuestion: 'q' });

before(async () => {
  const db = openNodeDb();
  setDb(db);
  await migrate(db);
  A = await mkProfile('Ana');
  B = await mkProfile('Beto');
});

// ---------- Migración desde el esquema de la v1 ----------

test('migra una base de la v1 sin perder datos y crea las tablas nuevas', async () => {
  const old = openNodeDb();
  // Esquema mínimo de la v1 (user_version = 1) con datos
  await old.exec(`
    CREATE TABLE profiles (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, birth_date TEXT, age INTEGER, avatar_color TEXT NOT NULL DEFAULT '#8B5CF6', answers TEXT NOT NULL DEFAULT '{}', settings TEXT NOT NULL DEFAULT '{}', security_question TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', due_date TEXT, due_time TEXT, priority INTEGER NOT NULL DEFAULT 1, category TEXT NOT NULL DEFAULT '', remind_minutes INTEGER, completed_at TEXT, created_at TEXT NOT NULL);
    CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL, title TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'event', date TEXT NOT NULL, start_time TEXT, end_time TEXT, all_day INTEGER NOT NULL DEFAULT 0, recurrence TEXT NOT NULL DEFAULT 'none', weekdays TEXT NOT NULL DEFAULT '', until_date TEXT, remind_minutes INTEGER, location TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE goals (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', term TEXT NOT NULL DEFAULT 'short', target_date TEXT, progress INTEGER NOT NULL DEFAULT 0, completed_at TEXT, created_at TEXT NOT NULL);
    CREATE TABLE habits (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL, title TEXT NOT NULL, frequency TEXT NOT NULL DEFAULT 'daily', weekdays TEXT NOT NULL DEFAULT '', target_per_week INTEGER NOT NULL DEFAULT 3, reminder_time TEXT, color TEXT NOT NULL DEFAULT '#8B5CF6', icon TEXT NOT NULL DEFAULT 'sparkles', archived INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
    CREATE TABLE habit_logs (habit_id INTEGER NOT NULL, date TEXT NOT NULL, PRIMARY KEY (habit_id, date));
    CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL, title TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '', is_list INTEGER NOT NULL DEFAULT 0, items TEXT NOT NULL DEFAULT '[]', favorite INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL, kind TEXT NOT NULL, name TEXT NOT NULL, emoji TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT 'Otros', quantity REAL NOT NULL DEFAULT 1, unit_price INTEGER, amount INTEGER NOT NULL, date TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE reminders (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL, title TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'general', date TEXT NOT NULL, time TEXT NOT NULL, repeat TEXT NOT NULL DEFAULT 'none', amount INTEGER, notes TEXT NOT NULL DEFAULT '', done INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
    INSERT INTO profiles (name, settings, created_at) VALUES ('Viejo', '{"themeMode":"light","accent":"blue"}', '2026-01-01T10:00:00');
    INSERT INTO tasks (profile_id, title, created_at) VALUES (1, 'Tarea vieja', '2026-01-01T10:00:00');
    INSERT INTO transactions (profile_id, kind, name, amount, date, created_at) VALUES (1, 'expense', 'Súper', 350000, '2026-01-02', '2026-01-02T10:00:00');
    PRAGMA user_version = 1;
  `);
  await migrate(old);
  const v = await old.first<{ user_version: number }>('PRAGMA user_version');
  assert.equal(v?.user_version, SCHEMA_VERSION);
  const tables = (await old.all<{ name: string }>("SELECT name FROM sqlite_master WHERE type='table'")).map((r) => r.name);
  for (const t of ['countdowns', 'routines', 'routine_logs']) assert.ok(tables.includes(t), `falta ${t}`);
  // Los datos viejos siguen ahí y la configuración vieja se completa con los módulos nuevos
  const prev = getDb();
  setDb(old);
  try {
    const p = await profilesRepo.get(1);
    assert.equal(p?.name, 'Viejo');
    assert.equal(p?.settings.themeMode, 'light');
    assert.equal(p?.settings.accent, 'blue');
    assert.deepEqual(p?.settings.modules, defaultModules());
    assert.equal(p?.settings.glow, 'soft');
    assert.equal((await tasksRepo.list(1))[0].title, 'Tarea vieja');
    assert.equal((await financeRepo.list(1))[0].amount, 350000);
    assert.deepEqual(await countdownsRepo.list(1), []);
  } finally {
    setDb(prev);
  }
});

test('mergeSettings tolera valores inválidos y completa módulos', () => {
  const s = mergeSettings({ modules: { countdown: false, dollar: 'si' } as any, glow: 'mucho' as any, fontScale: 'large' });
  assert.equal(s.modules.countdown, false);
  assert.equal(s.modules.dollar, false);
  assert.equal(s.modules.routines, true);
  assert.equal(s.glow, 'soft');
  assert.equal(s.fontScale, 'large');
  assert.ok(s.dashboardCards.some((c) => c.key === 'countdown'));
});

test('registro de módulos', () => {
  const keys = MODULES.map((m) => m.key);
  for (const k of Object.keys(defaultModules())) assert.ok(keys.includes(k as any), `falta ${k} en el registro`);
  assert.equal(isModuleOn(defaultModules(), 'countdown'), true);
  assert.equal(isModuleOn(defaultModules(), 'dollar'), false, 'los módulos nuevos vienen apagados');
  assert.equal(isModuleOn({ ...defaultModules(), dollar: true }, 'dollar'), true);
  assert.ok(MODULES.every((m) => m.available), 'todos los módulos están disponibles en la 2.0');
});

// ---------- Cuentas regresivas ----------

test('cuentas regresivas: crear, listar, privacidad y lógica', async () => {
  const id = await countdownsRepo.create(A, { title: 'Viaje', date: '2026-12-20', time: null, icon: 'Plane', color: '#A78BFA', remindDaysBefore: 3, pinned: true });
  await countdownsRepo.create(A, { title: 'Examen', date: '2026-11-10', time: '09:00', icon: 'GraduationCap', color: '#FBBF24', remindDaysBefore: null, pinned: false });
  await countdownsRepo.create(B, { title: 'Secreto de Beto', date: '2026-11-15', time: null, icon: 'Star', color: '#fff', remindDaysBefore: null, pinned: true });
  const a = await countdownsRepo.list(A);
  assert.equal(a.length, 2);
  assert.ok(a.every((c) => c.profileId === A));
  assert.equal(await countdownsRepo.get(B, id), null, 'Beto no ve lo de Ana');
  await countdownsRepo.update(B, id, { title: 'Hackeado', date: '2026-12-20', time: null, icon: 'Plane', color: '#A78BFA', remindDaysBefore: null, pinned: true });
  assert.equal((await countdownsRepo.get(A, id))?.title, 'Viaje', 'otro perfil no puede modificar');
  await countdownsRepo.remove(B, id);
  assert.ok(await countdownsRepo.get(A, id), 'otro perfil no puede borrar');
  await assert.rejects(countdownsRepo.create(A, { title: '  ', date: '2026-12-20', time: null, icon: 'Star', color: '#fff', remindDaysBefore: null, pinned: true }));

  const now = new Date(2026, 10, 5, 20, 30); // 5 nov 2026 20:30
  assert.equal(daysLeft({ date: '2026-11-17' }, now), 12);
  assert.equal(daysLabel({ date: '2026-11-17' }, now), 'Faltan 12 días');
  assert.equal(daysLabel({ date: '2026-11-05' }, now), 'Es hoy');
  assert.equal(daysLabel({ date: '2026-11-06' }, now), 'Es mañana');
  assert.equal(daysLabel({ date: '2026-11-02' }, now), 'Pasó hace 3 días');
  const r = remaining({ date: '2026-11-06', time: '08:00' }, now);
  assert.equal(r.days, 0);
  assert.equal(r.hours, 11);
  assert.equal(r.minutes, 30);
  assert.equal(r.past, false);
  assert.equal(remaining({ date: '2026-11-05', time: null }, now).today, true);
  assert.equal(remaining({ date: '2026-11-01', time: null }, now).past, true);
  assert.equal(progress({ date: '2026-11-15', time: null, createdAt: '2026-11-05T00:00:00' }, new Date(2026, 10, 10, 0, 0)), 50);
  const sorted = sortCountdowns(a, now);
  assert.equal(sorted[0].title, 'Examen');
  assert.equal(featured(a, now)?.title, 'Viaje', 'la fijada va al inicio aunque no sea la más cercana');
});

test('notificaciones de cuentas regresivas y rutinas', () => {
  const base = { profileId: A, profileName: 'Ana', settings: defaultSettings().notifications, tasks: [], events: [], habits: [], reminders: [], goals: [], now: new Date(2026, 10, 5, 8, 0) };
  const plan = buildNotificationPlan({
    ...base,
    countdowns: [{ id: 1, profileId: A, title: 'Viaje', date: '2026-11-17', time: null, icon: 'Plane', color: '#fff', remindDaysBefore: 3, pinned: true, createdAt: '2026-11-01T00:00:00' }],
    routines: [{ id: 1, profileId: A, title: 'Mañana', kind: 'morning', icon: 'Sunrise', color: '#fff', startTime: '07:00', steps: [{ id: 's1', title: 'Agua', minutes: 2 }], weekdays: [1, 2, 3, 4, 5], remind: true, archived: false, createdAt: '2026-11-01T00:00:00' }],
  });
  const ids = plan.map((n) => n.id);
  assert.ok(ids.includes(`p${A}:cd:1:pre`));
  assert.ok(ids.includes(`p${A}:cd:1:day`));
  assert.equal(ids.filter((i) => i.startsWith(`p${A}:routine:1`)).length, 5, 'una por día de semana');
  const pre = plan.find((n) => n.id === `p${A}:cd:1:pre`)!;
  assert.equal(pre.title, 'Faltan 3 días');
  assert.equal((pre.trigger as any).date.getDate(), 14);
});

// ---------- Rutinas ----------

test('rutinas: crear, marcar pasos, racha, horarios y privacidad', async () => {
  const id = await routinesRepo.create(A, {
    title: 'Mañana', kind: 'morning', icon: 'Sunrise', color: '#FBBF24', startTime: '07:00', remind: true, weekdays: [],
    steps: [{ id: 'a', title: 'Agua', minutes: 2 }, { id: 'b', title: 'Estirar', minutes: 5 }, { id: 'c', title: 'Ducha', minutes: 15 }],
  });
  const r = (await routinesRepo.get(A, id))!;
  assert.equal(r.steps.length, 3);
  assert.deepEqual(stepTimes(r), ['07:00', '07:02', '07:07']);
  assert.equal(await routinesRepo.get(B, id), null);
  assert.equal(await routinesRepo.toggleStep(B, id, '2026-11-05', 'a'), null, 'Beto no puede marcar pasos de Ana');

  let log = (await routinesRepo.toggleStep(A, id, '2026-11-05', 'a'))!;
  assert.deepEqual(log.doneSteps, ['a']);
  assert.equal(log.completed, false);
  assert.equal(currentStep(r, log)?.id, 'b');
  assert.equal(routineProgress(r, log).pct, 33);
  await routinesRepo.toggleStep(A, id, '2026-11-05', 'b');
  log = (await routinesRepo.toggleStep(A, id, '2026-11-05', 'c'))!;
  assert.equal(log.completed, true);
  log = (await routinesRepo.toggleStep(A, id, '2026-11-05', 'c'))!;
  assert.equal(log.completed, false, 'desmarcar un paso quita el completado');
  await routinesRepo.setAll(A, id, '2026-11-05', true);
  await routinesRepo.setAll(A, id, '2026-11-04', true);
  await routinesRepo.setAll(A, id, '2026-11-03', true);
  const logs = await routinesRepo.logs(A);
  const mine = logs.get(id)!;
  assert.equal(mine.size, 3);
  // La rutina fue creada hoy (nowStamp), así que la racha sólo cuenta desde su creación.
  const created = r.createdAt.slice(0, 10);
  const fake: Routine = { ...r, createdAt: '2026-11-01T00:00:00' };
  assert.equal(routineStreak(fake, mine, '2026-11-05'), 3);
  assert.equal(routineStreak(fake, mine, '2026-11-06'), 3, 'hoy sin completar no corta la racha');
  assert.equal(routineStreak(fake, mine, '2026-11-07'), 0, 'un día salteado la corta');
  const hist = routineHistory(fake, mine, '2026-11-06', 5);
  assert.deepEqual(hist.map((h) => h.state), ['missed', 'done', 'done', 'done', 'today']);
  const wk: Routine = { ...fake, weekdays: [1, 3] };
  assert.equal(isRoutineScheduledOn(wk, '2026-11-04'), true); // miércoles
  assert.equal(isRoutineScheduledOn(wk, '2026-11-05'), false); // jueves
  assert.ok(created);
  await assert.rejects(routinesRepo.create(A, { title: 'Vacía', kind: 'custom', icon: 'Star', color: '#fff', startTime: null, remind: false, weekdays: [], steps: [] }));
  assert.equal((await routinesRepo.logs(B)).size, 0, 'Beto no ve registros de Ana');
});

test('paso inválido no se guarda y pasos borrados no cuentan', async () => {
  const id = await routinesRepo.create(A, { title: 'Noche', kind: 'night', icon: 'Moon', color: '#fff', startTime: null, remind: false, weekdays: [], steps: [{ id: 'x', title: 'Leer', minutes: 10 }, { id: 'y', title: 'Dormir', minutes: 0 }] });
  const log = (await routinesRepo.toggleStep(A, id, '2026-11-05', 'zzz'))!;
  assert.deepEqual(log.doneSteps, []);
  await routinesRepo.toggleStep(A, id, '2026-11-05', 'x');
  await routinesRepo.update(A, id, { title: 'Noche', kind: 'night', icon: 'Moon', color: '#fff', startTime: null, remind: false, weekdays: [], steps: [{ id: 'y', title: 'Dormir', minutes: 0 }] });
  const r = (await routinesRepo.get(A, id))!;
  const l: RoutineLog = (await routinesRepo.log(A, id, '2026-11-05'))!;
  assert.equal(routineProgress(r, l).done, 0, 'el paso borrado ya no cuenta');
});

// ---------- Búsqueda ----------

test('búsqueda general: encuentra, agrupa y respeta la privacidad', async () => {
  await tasksRepo.create(A, { title: 'Comprar pan', description: '', dueDate: null, dueTime: null, priority: 1, category: 'Compras', remindMinutes: null });
  await financeRepo.create(A, { kind: 'expense', name: 'Panadería', emoji: '', category: 'Comida', quantity: 1, unitPrice: null, amount: 150000, date: '2026-11-05', description: 'medialunas' });
  await tasksRepo.create(B, { title: 'Pan de Beto', description: '', dueDate: null, dueTime: null, priority: 1, category: '', remindMinutes: null });
  const data = await loadSearchData(A);
  const res = searchItems(data, 'pan');
  assert.ok(res.some((r) => r.kind === 'task' && r.title === 'Comprar pan'));
  assert.ok(res.some((r) => r.kind === 'tx' && r.title === 'Panadería'));
  assert.ok(!res.some((r) => r.title === 'Pan de Beto'), 'no aparece lo de otro perfil');
  assert.equal(searchItems(data, 'p').length, 0, 'mínimo 2 letras');
  assert.ok(searchItems(data, 'medialunas').some((r) => r.kind === 'tx'), 'busca también en la descripción');
  assert.ok(searchItems(data, 'PANADERIA').some((r) => r.title === 'Panadería'), 'sin acentos ni mayúsculas');
  const groups = groupResults(res);
  assert.equal(groups[0].kind, 'task');
  assert.ok(groups.every((g) => g.items.length));
});

// ---------- Copia de seguridad ----------

test('la copia incluye cuentas regresivas, rutinas y sus registros', async () => {
  const bk = await exportProfile(A);
  assert.equal(bk.version, 4);
  assert.ok(bk.tables.countdowns.length >= 2);
  assert.ok(bk.tables.routines.length >= 2);
  assert.ok((bk.routineLogs ?? []).length >= 3);
  const C = await mkProfile('Copia');
  const r = await restoreProfile(C, bk, { restoreSettings: false });
  assert.ok(r.total > 0);
  const cds = await countdownsRepo.list(C);
  assert.equal(cds.length, bk.tables.countdowns.length);
  const logs = await routinesRepo.logs(C);
  let n = 0;
  for (const m of logs.values()) n += m.size;
  assert.equal(n, (bk.routineLogs ?? []).length);
  // Una copia vieja (v1, sin esas tablas) sigue restaurando
  const oldBk: any = { ...bk, version: 1, tables: { tasks: bk.tables.tasks }, routineLogs: undefined };
  await restoreProfile(C, oldBk, { restoreSettings: false });
  assert.equal((await countdownsRepo.list(C)).length, 0);
});

test('borrar un perfil borra sus rutinas, registros y cuentas regresivas', async () => {
  const D = await mkProfile('Temporal');
  const rid = await routinesRepo.create(D, { title: 'X', kind: 'custom', icon: 'Star', color: '#fff', startTime: null, remind: false, weekdays: [], steps: [{ id: 'a', title: 'a', minutes: 1 }] });
  await routinesRepo.setAll(D, rid, '2026-11-05', true);
  await countdownsRepo.create(D, { title: 'Y', date: '2026-12-01', time: null, icon: 'Star', color: '#fff', remindDaysBefore: null, pinned: true });
  await profilesRepo.remove(D);
  const db = getDb();
  assert.equal((await db.all('SELECT * FROM routines WHERE profile_id = ?', [D])).length, 0);
  assert.equal((await db.all('SELECT * FROM routine_logs WHERE routine_id = ?', [rid])).length, 0);
  assert.equal((await db.all('SELECT * FROM countdowns WHERE profile_id = ?', [D])).length, 0);
});

test('la bienvenida crea una rutina de mañana si el usuario dio su hora de levantarse', async () => {
  const { createProfileFromSetup } = await import('../src/services/createProfile');
  const Pin = await import('../src/security/pin');
  const mem = new Map<string, string>();
  Pin.configureSecurity({ get: async (k) => mem.get(k) ?? null, set: async (k, v) => void mem.set(k, v), del: async (k) => void mem.delete(k) });
  const pid = await createProfileFromSetup({
    name: 'Nuevo', birthDate: null, age: 20, answers: { wakeTime: '06:45' }, schedules: [], goals: [], habits: [],
    pin: '7391', pinLength: 4, securityQuestion: '¿Mascota?', securityAnswer: 'Firulais', biometrics: false, themeMode: 'dark', accent: 'violet', avatarColor: '#fff',
    modules: { countdown: false },
  }, []);
  const p = (await profilesRepo.get(pid))!;
  assert.equal(p.settings.modules.countdown, false);
  assert.equal(p.settings.modules.routines, true);
  const rs = await routinesRepo.list(pid);
  assert.equal(rs.length, 1);
  assert.equal(rs[0].startTime, '06:45');
  assert.equal(rs[0].kind, 'morning');
  assert.ok(rs[0].steps.length >= 3);
});
