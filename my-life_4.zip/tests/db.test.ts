import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { setDb, migrate, getDb } from '../src/db/db';
import { openNodeDb } from './nodeDb';
import { profilesRepo, tasksRepo, financeRepo, habitsRepo, notesRepo, goalsRepo, eventsRepo, remindersRepo } from '../src/db/repos';
import { defaultSettings } from '../src/db/defaults';
import { exportProfile, restoreProfile, transactionsToCsv } from '../src/db/backup';
import * as Pin from '../src/security/pin';

let A = 0;
let B = 0;

before(async () => {
  const db = openNodeDb();
  setDb(db);
  await migrate(db);
  await migrate(db); // idempotente
  const mem = new Map<string, string>();
  Pin.configureSecurity({
    get: async (k) => mem.get(k) ?? null,
    set: async (k, v) => void mem.set(k, v),
    del: async (k) => void mem.delete(k),
  });
  const base = { birthDate: null, age: null, avatarColor: '#8B5CF6', answers: {}, settings: defaultSettings(), securityQuestion: '¿Mascota?' };
  A = await profilesRepo.create({ ...base, name: 'Juan' });
  B = await profilesRepo.create({ ...base, name: 'Tomás' });
});

test('perfiles: creación y configuración independiente', async () => {
  const list = await profilesRepo.list();
  assert.deepEqual(list.map((p) => p.name), ['Juan', 'Tomás']);
  await profilesRepo.updateSettings(A, { themeMode: 'light', accent: 'emerald' });
  const a = await profilesRepo.get(A);
  const b = await profilesRepo.get(B);
  assert.equal(a!.settings.themeMode, 'light');
  assert.equal(b!.settings.themeMode, 'dark');
  assert.equal(a!.settings.notifications.tasks, true);
});

test('privacidad: un perfil no ve ni modifica datos del otro', async () => {
  const tA = await tasksRepo.create(A, { title: 'Tarea de Juan', description: '', dueDate: '2026-11-05', dueTime: null, priority: 1, category: '', remindMinutes: null });
  await tasksRepo.create(B, { title: 'Tarea de Tomás', description: '', dueDate: null, dueTime: null, priority: 1, category: '', remindMinutes: null });
  assert.deepEqual((await tasksRepo.list(A)).map((t) => t.title), ['Tarea de Juan']);
  assert.deepEqual((await tasksRepo.list(B)).map((t) => t.title), ['Tarea de Tomás']);
  assert.equal(await tasksRepo.get(B, tA), null);
  await tasksRepo.remove(B, tA); // intento de borrar dato ajeno
  await tasksRepo.setCompleted(B, tA, true);
  const still = await tasksRepo.get(A, tA);
  assert.ok(still && still.completedAt === null);

  const h = await habitsRepo.create(A, { title: 'Leer', frequency: 'daily', weekdays: [], targetPerWeek: 3, reminderTime: null, color: '#fff', icon: 'book' });
  assert.equal(await habitsRepo.toggle(B, h, '2026-11-04'), false);
  assert.equal((await habitsRepo.logs(A)).size, 0);
  assert.equal(await habitsRepo.toggle(A, h, '2026-11-04'), true);
  assert.ok((await habitsRepo.logs(A)).get(h)!.has('2026-11-04'));
  assert.equal((await habitsRepo.logs(B)).size, 0);
});

test('tareas: completar y deshacer', async () => {
  const id = await tasksRepo.create(A, { title: 'Estudiar', description: 'cap 3', dueDate: '2026-11-04', dueTime: '18:00', priority: 2, category: 'Estudio', remindMinutes: 15 });
  await tasksRepo.setCompleted(A, id, true);
  assert.ok((await tasksRepo.get(A, id))!.completedAt);
  await tasksRepo.setCompleted(A, id, false);
  assert.equal((await tasksRepo.get(A, id))!.completedAt, null);
  await tasksRepo.update(A, id, { title: 'Estudiar mate', description: '', dueDate: null, dueTime: null, priority: 0, category: '', remindMinutes: null });
  assert.equal((await tasksRepo.get(A, id))!.title, 'Estudiar mate');
});

test('finanzas: validaciones y guardado en centavos', async () => {
  const id = await financeRepo.create(A, { kind: 'expense', name: 'Gaseosa', emoji: '🥤', category: 'Comida', quantity: 3, unitPrice: 200000, amount: 600000, date: '2026-11-04', description: '' });
  const t = await financeRepo.get(A, id);
  assert.equal(t!.amount, 600000);
  assert.equal(t!.quantity, 3);
  await assert.rejects(() => financeRepo.create(A, { kind: 'expense', name: '', emoji: '', category: 'Otros', quantity: 1, unitPrice: null, amount: 100, date: '2026-11-04', description: '' }));
  await assert.rejects(() => financeRepo.create(A, { kind: 'expense', name: 'x', emoji: '', category: 'Otros', quantity: 1, unitPrice: null, amount: 0, date: '2026-11-04', description: '' }));
  assert.equal((await financeRepo.list(B)).length, 0);
  const csv = transactionsToCsv(await financeRepo.list(A));
  assert.ok(csv.includes('Gaseosa'));
  assert.ok(csv.includes('6000,00'));
});

test('objetivos: 100% marca como alcanzado', async () => {
  const id = await goalsRepo.create(A, { title: 'Ahorrar', description: '', term: 'short', targetDate: null, progress: 30 });
  await goalsRepo.setProgress(A, id, 100);
  assert.ok((await goalsRepo.get(A, id))!.completedAt);
  await goalsRepo.setProgress(A, id, 80);
  assert.equal((await goalsRepo.get(A, id))!.completedAt, null);
});

test('notas, eventos y recordatorios', async () => {
  const n = await notesRepo.create(A, { title: 'Súper', body: '', category: 'Compras', isList: true, items: [{ text: 'Leche', done: false }], favorite: false });
  await notesRepo.setFavorite(A, n, true);
  const note = await notesRepo.get(A, n);
  assert.equal(note!.items[0].text, 'Leche');
  assert.ok(note!.favorite);
  const e = await eventsRepo.create(A, { title: 'Colegio', type: 'schedule', date: '2026-11-02', startTime: '07:30', endTime: '12:30', allDay: false, recurrence: 'weekly', weekdays: [5, 1, 3], untilDate: null, remindMinutes: 30, location: '', notes: '' });
  assert.deepEqual((await eventsRepo.get(A, e))!.weekdays, [1, 3, 5]);
  const r = await remindersRepo.create(A, { title: 'Pagar luz', kind: 'payment', date: '2026-11-10', time: '09:00', repeat: 'monthly', amount: 1000000, notes: '' });
  await remindersRepo.setDone(A, r, true);
  assert.ok((await remindersRepo.get(A, r))!.done);
  assert.equal((await remindersRepo.list(B)).length, 0);
});

test('copia de seguridad: exportar y restaurar en otro perfil', async () => {
  const backup = await exportProfile(A);
  const json = JSON.parse(JSON.stringify(backup));
  assert.ok(!JSON.stringify(json).includes('pbkdf2'));
  const C = await profilesRepo.create({ name: 'Prueba', birthDate: null, age: null, avatarColor: '#000', answers: {}, settings: defaultSettings(), securityQuestion: '' });
  const r = await restoreProfile(C, json, { restoreSettings: true });
  assert.ok(r.total >= 6);
  assert.equal((await tasksRepo.list(C)).length, (await tasksRepo.list(A)).length);
  assert.equal((await financeRepo.list(C))[0].amount, 600000);
  const logs = await habitsRepo.logs(C);
  assert.equal([...logs.values()][0].size, 1);
  assert.equal((await profilesRepo.get(C))!.settings.accent, 'emerald');
  await assert.rejects(() => restoreProfile(C, { foo: 1 } as any, { restoreSettings: false }));
  await profilesRepo.remove(C);
  assert.equal(await profilesRepo.get(C), null);
  const orphans = await getDb().first<{ n: number }>('SELECT COUNT(*) AS n FROM tasks WHERE profile_id = ?', [C]);
  assert.equal(orphans!.n, 0);
});

test('PIN: identifica a cada persona y nunca se guarda en texto plano', async () => {
  await Pin.setPin(A, '4821');
  await Pin.setPin(B, '739105');
  assert.equal(await Pin.identifyByPin([A, B], '4821'), A);
  assert.equal(await Pin.identifyByPin([A, B], '739105'), B);
  assert.equal(await Pin.identifyByPin([A, B], '0000'), null);
  assert.ok(await Pin.pinInUse([A, B], '4821', B));
  assert.ok(!(await Pin.pinInUse([A, B], '4821', A)));
  // prefijos: 6 dígitos que empiezan con el PIN de 4 de otro, y 4 dígitos que son el comienzo de un PIN de 6
  assert.ok(await Pin.pinInUse([A, B], '482199', B));
  assert.ok(await Pin.pinInUse([A, B], '7391', A));
  assert.ok(!(await Pin.pinInUse([A, B], '7392', A)));
  assert.ok(Pin.isWeakPin('1234') && Pin.isWeakPin('0000') && Pin.isWeakPin('987654'));
  assert.ok(!Pin.isWeakPin('4821'));
  assert.ok(!Pin.isValidPin('12a4') && !Pin.isValidPin('12345') && Pin.isValidPin('123456'));
  await Pin.setRecoveryAnswer(A, '  Firulais ');
  assert.ok(await Pin.checkRecoveryAnswer(A, 'firulais'));
  assert.ok(!(await Pin.checkRecoveryAnswer(A, 'otro')));
});

test('PIN: bloqueo progresivo por intentos incorrectos', async () => {
  await Pin.resetFailures();
  let s = { failures: 0, lockedUntil: 0 };
  for (let i = 0; i < 4; i++) s = await Pin.registerFailure(1000);
  assert.equal(s.lockedUntil, 0);
  s = await Pin.registerFailure(1000);
  assert.equal(s.lockedUntil, 31000);
  for (let i = 0; i < 5; i++) s = await Pin.registerFailure(2000);
  assert.equal(s.lockedUntil, 62000);
  assert.equal(Pin.lockoutDuration(100), 15 * 60_000);
  await Pin.resetFailures();
  assert.equal((await Pin.getLockState()).failures, 0);
});
