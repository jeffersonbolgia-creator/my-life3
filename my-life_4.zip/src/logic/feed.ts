// Lógica del Feed: pestañas, orden de "Para vos", sin spoilers y resumen diario.
// Sin red ni base de datos (testeable). Los intérpretes de cada fuente están en logic/sources/.

import type { FeedItem, FeedKind, FeedSourceKind } from '../types';
import { normalizeText } from '../lib/text';

export interface FeedKindDef {
  kind: FeedKind;
  label: string;
  icon: string;
  color: string;
  /** Qué se sigue para llenar esta pestaña (null = los temas de noticias). */
  source: FeedSourceKind | null;
  /** Cómo se llama lo que se sigue, para los botones ("Seguir cuenta"). */
  followLabel: string;
  /** Texto para la atribución obligatoria de la fuente. */
  attribution: string;
  /** Cuánto se guarda como máximo por perfil. */
  keep: number;
}

export const FEED_KIND_DEFS: FeedKindDef[] = [
  { kind: 'post', label: 'Bluesky', icon: 'AtSign', color: '#60A5FA', source: 'bluesky', followLabel: 'cuenta', attribution: 'Publicaciones de Bluesky', keep: 200 },
  { kind: 'news', label: 'Noticias', icon: 'Newspaper', color: '#F472B6', source: null, followLabel: 'tema', attribution: 'Titulares de Google News', keep: 300 },
  { kind: 'video', label: 'Videos', icon: 'Play', color: '#EF4444', source: 'youtube', followLabel: 'canal', attribution: 'Videos de YouTube', keep: 150 },
  { kind: 'podcast', label: 'Podcasts', icon: 'Podcast', color: '#A78BFA', source: 'podcast', followLabel: 'podcast', attribution: 'Podcasts vía Apple Podcasts', keep: 120 },
  { kind: 'match', label: 'Deportes', icon: 'Trophy', color: '#22C55E', source: 'team', followLabel: 'equipo o liga', attribution: 'Resultados de ESPN', keep: 150 },
  { kind: 'game', label: 'Juegos', icon: 'Gamepad2', color: '#3B82F6', source: 'game', followLabel: 'juego', attribution: 'Precios de Steam · Lanzamientos de RAWG', keep: 120 },
  { kind: 'show', label: 'Series', icon: 'Tv', color: '#E11D48', source: 'show', followLabel: 'serie o película', attribution: 'Datos de TMDB', keep: 120 },
  { kind: 'music', label: 'Música', icon: 'Music', color: '#10B981', source: 'artist', followLabel: 'artista', attribution: 'Lanzamientos vía Apple Music', keep: 120 },
  { kind: 'crypto', label: 'Cripto', icon: 'Bitcoin', color: '#F59E0B', source: 'coin', followLabel: 'moneda', attribution: 'Datos de CoinGecko', keep: 60 },
];

export function kindDef(kind: FeedKind): FeedKindDef {
  return FEED_KIND_DEFS.find((k) => k.kind === kind) ?? FEED_KIND_DEFS[1];
}

/** "hace 5 min", "hace 3 h", "ayer", "hace 4 días". */
export function timeAgo(iso: string, now: Date = new Date()): string {
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return '';
  const m = Math.round((now.getTime() - t) / 60000);
  if (m < 1) return 'ahora';
  if (m < 60) return `hace ${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `hace ${h} h`;
  const d = Math.round(h / 24);
  if (d === 1) return 'ayer';
  if (d < 30) return `hace ${d} días`;
  const mo = Math.round(d / 30);
  return mo <= 1 ? 'hace un mes' : `hace ${mo} meses`;
}

/** Formato corto de números grandes: 1,2 mil, 34 mil, 1,5 M. */
export function compactNumber(n: number): string {
  if (!Number.isFinite(n)) return '';
  if (n < 1000) return String(Math.round(n));
  if (n < 10_000) return `${(n / 1000).toFixed(1).replace('.', ',').replace(',0', '')} mil`;
  if (n < 1_000_000) return `${Math.round(n / 1000)} mil`;
  return `${(n / 1_000_000).toFixed(1).replace('.', ',').replace(',0', '')} M`;
}

/** Pesos por tema o fuente: cada toque suma, cada "menos de esto" resta. */
export function adjustWeight(weights: Record<string, number>, topic: string, delta: number): Record<string, number> {
  const next = { ...weights };
  next[topic] = Math.max(-5, Math.min(10, (next[topic] ?? 0) + delta));
  return next;
}

/** Cuánto pesa la antigüedad según el tipo: una noticia envejece rápido, un precio no tanto. */
const HALF_LIFE_HOURS: Record<FeedKind, number> = { post: 18, news: 36, video: 72, podcast: 96, match: 48, game: 120, show: 120, music: 120, crypto: 24 };

/**
 * Orden de "Para vos": lo más nuevo primero, pero lo que el usuario toca sube y se intercalan
 * tipos y temas para que no sea todo lo mismo.
 */
export function rankFeed(items: FeedItem[], weights: Record<string, number>, now: Date = new Date()): FeedItem[] {
  const scored = items.map((it) => {
    const ageH = Math.max(0, (now.getTime() - new Date(it.publishedAt).getTime()) / 3600_000);
    const hl = HALF_LIFE_HOURS[it.kind] ?? 48;
    const recency = Math.pow(0.5, ageH / hl); // 1 ahora, 0,5 a la vida media
    const w = (weights[it.topic] ?? 0) + (weights[`kind:${it.kind}`] ?? 0);
    const popularity = it.likes ? Math.min(2, Math.log10(it.likes + 1) / 2) : 0;
    return { it, score: recency * 10 + w * 1.5 + popularity + (it.imageUrl ? 0.4 : 0) };
  });
  scored.sort((a, b) => b.score - a.score || b.it.publishedAt.localeCompare(a.it.publishedAt));
  const out: FeedItem[] = [];
  const pending = scored.map((s) => s.it);
  while (pending.length) {
    const last2 = out.slice(-2);
    const idx = pending.findIndex((x) => !(last2.length === 2 && last2.every((l) => l.topic === x.topic && l.kind === x.kind)));
    out.push(pending.splice(idx === -1 ? 0 : idx, 1)[0]);
  }
  return out;
}

/** ¿Hay que tapar esta publicación? Sólo con "sin spoilers" activado y si la fuente la marcó. */
export function isSpoiler(it: Pick<FeedItem, 'spoiler'>, spoilerFree: boolean): boolean {
  return spoilerFree && it.spoiler;
}

export interface FeedSummary {
  text: string;
  /** Ítems que respaldan el resumen (para abrirlos desde la tarjeta). */
  itemIds: number[];
}

const KIND_PHRASE: Record<FeedKind, (n: number, first: FeedItem) => string> = {
  post: (n, f) => n === 1 ? `${f.author || f.authorHandle} publicó: “${trimTo(f.title || f.text, 70)}”` : `hay ${n} publicaciones nuevas en Bluesky, la más votada: “${trimTo(f.title || f.text, 60)}”`,
  news: (n, f) => n === 1 ? `una noticia de ${f.topic}: ${trimTo(f.title, 80)}` : `${n} noticias nuevas; la principal: ${trimTo(f.title, 80)}`,
  video: (n, f) => n === 1 ? `${f.author} subió un video: ${trimTo(f.title, 60)}` : `${n} videos nuevos, entre ellos ${trimTo(f.title, 50)} (${f.author})`,
  podcast: (n, f) => n === 1 ? `salió un episodio de ${f.author}: ${trimTo(f.title, 60)}` : `${n} episodios nuevos de podcasts`,
  match: (n, f) => {
    const x = f.extra as any;
    if (x?.status === 'final') return `${f.title}`;
    if (x?.status === 'live') return `se está jugando ${f.title}`;
    return n === 1 ? `próximo: ${f.title}` : `tenés ${n} partidos o peleas en agenda; el primero: ${f.title}`;
  },
  game: (n, f) => {
    const x = f.extra as any;
    if (x?.discount) return `${f.title} está con ${x.discount}% de descuento`;
    if (x?.release) return `${f.title} sale ${x.release}`;
    return n === 1 ? `novedad: ${trimTo(f.title, 60)}` : `${n} novedades de juegos`;
  },
  show: (n, f) => {
    const x = f.extra as any;
    if (x?.episode) return `sale ${x.episode} de ${f.title}`;
    return n === 1 ? `estreno: ${trimTo(f.title, 60)}` : `${n} estrenos de series y películas`;
  },
  music: (n, f) => n === 1 ? `${f.author} lanzó ${trimTo(f.title, 50)}` : `${n} lanzamientos nuevos de música`,
  crypto: (n, f) => {
    const x = f.extra as any;
    const ch = typeof x?.change24h === 'number' ? ` (${x.change24h > 0 ? '+' : ''}${x.change24h.toFixed(1).replace('.', ',')}% hoy)` : '';
    return `${f.title} ${x?.priceText ?? ''}${ch}`.trim();
  },
};

function trimTo(s: string, n: number): string {
  const t = (s ?? '').replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n - 1).trimEnd() + '…' : t;
}

/**
 * Resumen del día para la tarjeta de Nova: toma lo de las últimas 24 h, una línea por tipo,
 * priorizando lo que al usuario más le interesa. Devuelve null si no hay nada.
 */
export function feedSummary(items: FeedItem[], weights: Record<string, number>, opts: { name: string; spoilerFree: boolean; now?: Date } = { name: 'Nova', spoilerFree: false }): FeedSummary | null {
  const now = opts.now ?? new Date();
  const since = now.getTime() - 26 * 3600_000;
  const fresh = items.filter((it) => !it.hidden && new Date(it.publishedAt).getTime() >= since && !(opts.spoilerFree && it.spoiler));
  if (!fresh.length) return null;
  const byKind = new Map<FeedKind, FeedItem[]>();
  for (const it of rankFeed(fresh, weights, now)) {
    const arr = byKind.get(it.kind) ?? [];
    arr.push(it);
    byKind.set(it.kind, arr);
  }
  // Tipos ordenados por interés (peso) y cantidad
  const kinds = [...byKind.entries()].sort((a, b) => ((weights[`kind:${b[0]}`] ?? 0) - (weights[`kind:${a[0]}`] ?? 0)) || b[1].length - a[1].length).slice(0, 4);
  const parts: string[] = [];
  const ids: number[] = [];
  for (const [kind, arr] of kinds) {
    parts.push(KIND_PHRASE[kind](arr.length, arr[0]));
    ids.push(arr[0].id);
  }
  const hour = now.getHours();
  const greet = hour < 12 ? 'Buen día' : hour < 19 ? 'Buenas' : 'Buenas noches';
  const text = `${greet}. ${capitalize(parts[0])}${parts.length > 1 ? '. ' + parts.slice(1).map(capitalize).join('. ') : ''}.`;
  return { text: text.replace(/\.\./g, '.'), itemIds: ids };
}

function capitalize(s: string): string {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

/** Búsqueda simple dentro del feed (título, texto, autor, tema). */
export function filterFeed(items: FeedItem[], query: string): FeedItem[] {
  const q = normalizeText(query.trim());
  if (!q) return items;
  return items.filter((it) => normalizeText(`${it.title} ${it.text} ${it.author} ${it.authorHandle} ${it.topic}`).includes(q));
}
