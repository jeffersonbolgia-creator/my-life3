// Apple (iTunes Search API, sin clave): podcasts y lanzamientos de música.
//  - Buscar podcast:   GET https://itunes.apple.com/search?media=podcast&term={texto}&country=AR&limit=10
//  - Episodios:        el RSS de cada podcast (feedUrl de la búsqueda)
//  - Buscar artista:   GET https://itunes.apple.com/search?entity=musicArtist&term={texto}&country=AR&limit=10
//  - Lanzamientos:     GET https://itunes.apple.com/lookup?id={artistId}&entity=album&limit=12&sort=recent&country=AR

import type { FeedItemInput } from '../../db/repos';
import { attr, entries, isHttp, isoDate, stripHtml, tag } from '../xml';

export function searchPodcastsUrl(term: string): string {
  return `https://itunes.apple.com/search?media=podcast&term=${encodeURIComponent(term)}&country=AR&limit=10`;
}
export function searchArtistsUrl(term: string): string {
  return `https://itunes.apple.com/search?entity=musicArtist&attribute=artistTerm&term=${encodeURIComponent(term)}&country=AR&limit=10`;
}
export function artistReleasesUrl(artistId: string): string {
  return `https://itunes.apple.com/lookup?id=${encodeURIComponent(artistId)}&entity=album&limit=12&sort=recent&country=AR`;
}

export interface PodcastHit { id: string; name: string; author: string; image: string | null; feedUrl: string; genre: string }
export interface ArtistHit { id: string; name: string; genre: string }

/** Portadas más grandes: Apple devuelve 100x100 pero acepta cualquier tamaño en la URL. */
export function bigArtwork(url: unknown): string | null {
  if (!isHttp(url)) return null;
  return url.replace(/\/\d+x\d+bb\./, '/600x600bb.');
}

export function parsePodcastSearch(json: unknown): PodcastHit[] {
  const results = (json as any)?.results;
  if (!Array.isArray(results)) return [];
  return results
    .filter((r) => r && isHttp(r.feedUrl) && (r.collectionName || r.trackName))
    .map((r) => ({ id: String(r.collectionId ?? r.trackId ?? r.feedUrl), name: String(r.collectionName ?? r.trackName), author: String(r.artistName ?? ''), image: bigArtwork(r.artworkUrl600 ?? r.artworkUrl100), feedUrl: r.feedUrl, genre: String(r.primaryGenreName ?? '') }));
}

export function parseArtistSearch(json: unknown): ArtistHit[] {
  const results = (json as any)?.results;
  if (!Array.isArray(results)) return [];
  return results.filter((r) => r && r.artistId && r.artistName).map((r) => ({ id: String(r.artistId), name: String(r.artistName), genre: String(r.primaryGenreName ?? '') }));
}

/** Episodios del RSS de un podcast (los que tienen audio). */
export function parsePodcastRss(xml: string, podcast: { id: string; name: string; image: string | null }): FeedItemInput[] {
  const out: FeedItemInput[] = [];
  const channelImage = attr(xml.split('<item')[0] ?? '', 'itunes:image', 'href') ?? podcast.image;
  for (const e of entries(xml).slice(0, 20)) {
    const title = stripHtml(tag(e, 'title') ?? '');
    const audio = attr(e, 'enclosure', 'url');
    if (!title || !isHttp(audio)) continue;
    const guid = stripHtml(tag(e, 'guid') ?? '') || audio;
    const link = tag(e, 'link');
    const dur = stripHtml(tag(e, 'itunes:duration') ?? '');
    const image = attr(e, 'itunes:image', 'href') ?? channelImage;
    out.push({
      kind: 'podcast', topic: podcast.name, externalId: `pod:${podcast.id}:${guid}`, title, text: stripHtml(tag(e, 'description') ?? tag(e, 'itunes:summary') ?? '').slice(0, 400),
      url: isHttp(link) ? link : audio, author: podcast.name, authorHandle: '', authorAvatar: isHttp(channelImage) ? channelImage : null, imageUrl: isHttp(image) ? image : null,
      publishedAt: isoDate(tag(e, 'pubDate')), likes: null, extra: { audio, duration: durationLabel(dur), podcastId: podcast.id },
    });
  }
  return out;
}

/** "3600" o "1:00:00" → "1 h", "45:12" → "45 min". */
export function durationLabel(raw: string): string {
  if (!raw) return '';
  let secs = 0;
  if (/^\d+$/.test(raw)) secs = Number(raw);
  else {
    const parts = raw.split(':').map(Number);
    if (parts.some((n) => !Number.isFinite(n))) return '';
    secs = parts.reduce((a, n) => a * 60 + n, 0);
  }
  const m = Math.round(secs / 60);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  const rest = m % 60;
  return rest ? `${h} h ${rest} min` : `${h} h`;
}

/** Álbumes/singles de un artista (lookup). El primer resultado es el artista, se omite. */
export function parseArtistReleases(json: unknown, artist: { id: string; name: string }): FeedItemInput[] {
  const results = (json as any)?.results;
  if (!Array.isArray(results)) return [];
  const out: FeedItemInput[] = [];
  for (const r of results) {
    if (!r || r.wrapperType !== 'collection' || !r.collectionId || !r.collectionName) continue;
    const date = typeof r.releaseDate === 'string' ? r.releaseDate : '';
    out.push({
      kind: 'music', topic: artist.name, externalId: `music:${r.collectionId}`, title: String(r.collectionName), text: `${r.trackCount ? `${r.trackCount} ${r.trackCount === 1 ? 'tema' : 'temas'}` : ''}${r.primaryGenreName ? ` · ${r.primaryGenreName}` : ''}`.replace(/^ · /, ''),
      url: isHttp(r.collectionViewUrl) ? r.collectionViewUrl : '', author: String(r.artistName ?? artist.name), authorHandle: '', authorAvatar: null, imageUrl: bigArtwork(r.artworkUrl100),
      publishedAt: isoDate(date), likes: null, extra: { artistId: artist.id, releaseDate: date.slice(0, 10), tracks: r.trackCount ?? null },
    });
  }
  return out;
}
