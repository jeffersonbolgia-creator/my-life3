// Deportes vía la API no oficial de ESPN (sin clave; puede cambiar sin aviso).
//  GET https://site.api.espn.com/apis/site/v2/sports/{deporte}/{liga}/scoreboard?dates=YYYYMMDD-YYYYMMDD
//  GET https://site.api.espn.com/apis/site/v2/sports/{deporte}/{liga}/teams
// Ojo: con un User-Agent de navegador copiado devolvió 403 en pruebas ajenas; se pide sin ese encabezado.

import type { FeedItemInput } from '../../db/repos';
import { isHttp } from '../xml';

export interface LeagueDef { id: string; label: string; short: string; sport: 'soccer' | 'mma' | 'basketball' | 'football' | 'tennis' | 'racing'; teams: boolean }

export const LEAGUES: LeagueDef[] = [
  { id: 'soccer/arg.1', label: 'Liga Profesional (Argentina)', short: 'Liga Argentina', sport: 'soccer', teams: true },
  { id: 'soccer/arg.copa_lpf', label: 'Copa de la Liga', short: 'Copa de la Liga', sport: 'soccer', teams: true },
  { id: 'soccer/conmebol.libertadores', label: 'Copa Libertadores', short: 'Libertadores', sport: 'soccer', teams: true },
  { id: 'soccer/conmebol.sudamericana', label: 'Copa Sudamericana', short: 'Sudamericana', sport: 'soccer', teams: true },
  { id: 'soccer/fifa.world', label: 'Mundial', short: 'Mundial', sport: 'soccer', teams: true },
  { id: 'soccer/conmebol.america', label: 'Copa América', short: 'Copa América', sport: 'soccer', teams: true },
  { id: 'soccer/eng.1', label: 'Premier League', short: 'Premier', sport: 'soccer', teams: true },
  { id: 'soccer/esp.1', label: 'La Liga (España)', short: 'La Liga', sport: 'soccer', teams: true },
  { id: 'soccer/ita.1', label: 'Serie A (Italia)', short: 'Serie A', sport: 'soccer', teams: true },
  { id: 'soccer/ger.1', label: 'Bundesliga', short: 'Bundesliga', sport: 'soccer', teams: true },
  { id: 'soccer/fra.1', label: 'Ligue 1', short: 'Ligue 1', sport: 'soccer', teams: true },
  { id: 'soccer/uefa.champions', label: 'Champions League', short: 'Champions', sport: 'soccer', teams: true },
  { id: 'soccer/usa.1', label: 'MLS', short: 'MLS', sport: 'soccer', teams: true },
  { id: 'mma/ufc', label: 'UFC', short: 'UFC', sport: 'mma', teams: false },
  { id: 'basketball/nba', label: 'NBA', short: 'NBA', sport: 'basketball', teams: true },
  { id: 'football/nfl', label: 'NFL', short: 'NFL', sport: 'football', teams: true },
  { id: 'racing/f1', label: 'Fórmula 1', short: 'F1', sport: 'racing', teams: false },
];

export function leagueDef(id: string): LeagueDef | null {
  return LEAGUES.find((l) => l.id === id) ?? null;
}

const yyyymmdd = (d: string) => d.replace(/-/g, '');

export function scoreboardUrl(leagueId: string, from: string, to: string): string {
  return `https://site.api.espn.com/apis/site/v2/sports/${leagueId}/scoreboard?dates=${yyyymmdd(from)}-${yyyymmdd(to)}&limit=100`;
}
export function teamsUrl(leagueId: string): string {
  return `https://site.api.espn.com/apis/site/v2/sports/${leagueId}/teams?limit=200`;
}

export interface TeamHit { id: string; name: string; short: string; logo: string | null; leagueId: string }

/** Equipos de una liga: { sports: [{ leagues: [{ teams: [{ team }] }] }] }. */
export function parseTeams(json: unknown, leagueId: string): TeamHit[] {
  const teams = (json as any)?.sports?.[0]?.leagues?.[0]?.teams;
  if (!Array.isArray(teams)) return [];
  return teams
    .map((t) => t?.team)
    .filter((t) => t && t.id && (t.displayName || t.name))
    .map((t) => ({ id: String(t.id), name: String(t.displayName ?? t.name), short: String(t.abbreviation ?? t.shortDisplayName ?? ''), logo: isHttp(t.logos?.[0]?.href) ? t.logos[0].href : null, leagueId }));
}

export type MatchStatus = 'pre' | 'live' | 'final';

export interface MatchExtra {
  leagueId: string;
  league: string;
  status: MatchStatus;
  detail: string;
  home: { id: string; name: string; short: string; logo: string | null; score: string | null; winner: boolean } | null;
  away: { id: string; name: string; short: string; logo: string | null; score: string | null; winner: boolean } | null;
  start: string; // ISO
  venue: string;
}

function side(c: any) {
  const team = c?.team ?? c?.athlete ?? {};
  return {
    id: String(team.id ?? c?.id ?? ''),
    name: String(team.displayName ?? team.fullName ?? team.name ?? ''),
    short: String(team.abbreviation ?? team.shortName ?? team.shortDisplayName ?? '').slice(0, 5),
    logo: isHttp(team.logo) ? team.logo : isHttp(team.logos?.[0]?.href) ? team.logos[0].href : isHttp(c?.athlete?.flag?.href) ? c.athlete.flag.href : null,
    score: c?.score != null && c.score !== '' ? String(typeof c.score === 'object' ? c.score.displayValue ?? c.score.value ?? '' : c.score) : null,
    winner: c?.winner === true,
  };
}

function statusOf(st: any): { status: MatchStatus; detail: string } {
  const state = String(st?.type?.state ?? '');
  const detail = String(st?.type?.shortDetail ?? st?.type?.detail ?? st?.type?.description ?? '');
  return { status: state === 'in' ? 'live' : state === 'post' ? 'final' : 'pre', detail };
}

/**
 * Partidos de un scoreboard: { events: [{ id, date, name, shortName, status, competitions: [{ competitors, venue }] }] }.
 * En MMA cada evento (cartelera) trae varias peleas en `competitions`.
 * Si se pasa `teamIds`, sólo quedan los partidos de esos equipos.
 */
export function parseScoreboard(json: unknown, league: LeagueDef, teamIds: string[] | null = null): FeedItemInput[] {
  const events = (json as any)?.events;
  if (!Array.isArray(events)) return [];
  const out: FeedItemInput[] = [];
  const want = teamIds ? new Set(teamIds) : null;
  for (const ev of events) {
    const comps: any[] = Array.isArray(ev?.competitions) ? ev.competitions : [];
    const evStatus = statusOf(ev?.status);
    for (const comp of comps.length ? comps : [null]) {
      const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
      const home = competitors.find((c) => c?.homeAway === 'home') ?? competitors[0] ?? null;
      const away = competitors.find((c) => c?.homeAway === 'away') ?? competitors[1] ?? null;
      const h = home ? side(home) : null;
      const a = away ? side(away) : null;
      if (want && !(h && want.has(h.id)) && !(a && want.has(a.id))) continue;
      const st = comp?.status ? statusOf(comp.status) : evStatus;
      const start = typeof comp?.date === 'string' ? comp.date : typeof ev?.date === 'string' ? ev.date : new Date().toISOString();
      const startIso = Number.isNaN(new Date(start).getTime()) ? new Date().toISOString() : new Date(start).toISOString();
      const names = h && a ? `${h.name} vs ${a.name}` : String(ev?.name ?? comp?.name ?? league.label);
      let title = names;
      if (st.status === 'final' && h && a && h.score != null && a.score != null) title = `${h.name} ${h.score} - ${a.score} ${a.name}`;
      else if (st.status === 'live' && h && a) title = `${h.name} ${h.score ?? ''} - ${a.score ?? ''} ${a.name}`.replace(/\s+-\s+/, ' - ');
      const extra: MatchExtra = { leagueId: league.id, league: league.short, status: st.status, detail: st.detail, home: h, away: a, start: startIso, venue: String(comp?.venue?.fullName ?? '') };
      const card = league.sport === 'mma' && typeof ev?.name === 'string' ? ev.name : '';
      out.push({
        kind: 'match', topic: league.short, externalId: `espn:${league.id}:${comp?.id ?? ev?.id}`, title, text: card || st.detail,
        url: isHttp(ev?.links?.[0]?.href) ? ev.links[0].href : `https://www.espn.com.ar`, author: league.label, authorHandle: '', authorAvatar: null,
        imageUrl: null, publishedAt: st.status === 'pre' ? startIso : startIso, likes: null, extra: extra as unknown as Record<string, unknown>, spoiler: st.status !== 'pre',
      });
    }
  }
  return out;
}
