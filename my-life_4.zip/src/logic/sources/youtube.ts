// YouTube por RSS (sin clave): GET https://www.youtube.com/feeds/videos.xml?channel_id={id}
// Anda intermitente en 2026 (a veces demora o devuelve 404): se trata como normal.

import type { FeedItemInput } from '../../db/repos';
import { attr, decodeEntities, entries, isoDate, stripHtml, tag } from '../xml';

export function channelFeedUrl(channelId: string): string {
  return `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`;
}

/** Página del canal para averiguar su id a partir del nombre de usuario (@canal). */
export function channelPageUrl(input: string): string {
  const h = normalizeChannelInput(input);
  if (h.startsWith('UC')) return `https://www.youtube.com/channel/${h}`;
  return `https://www.youtube.com/@${h.replace(/^@/, '')}`;
}

/** "@canal", "youtube.com/@canal", "youtube.com/channel/UC...", "UC..." → "@canal" o "UC...". */
export function normalizeChannelInput(input: string): string {
  let s = input.trim();
  let m = s.match(/channel\/(UC[\w-]{20,})/i);
  if (m) return m[1];
  m = s.match(/youtube\.com\/@([^/?#\s]+)/i);
  if (m) return m[1];
  m = s.match(/^(UC[\w-]{20,})$/);
  if (m) return m[1];
  return s.replace(/^@/, '').replace(/\s+/g, '');
}

/** Busca el id del canal en el HTML de su página. */
export function channelIdFromHtml(html: string): string | null {
  const m = html.match(/"channelId":"(UC[\w-]{20,})"/) ?? html.match(/channel_id=(UC[\w-]{20,})/) ?? html.match(/youtube\.com\/channel\/(UC[\w-]{20,})/);
  return m ? m[1] : null;
}

export function channelNameFromHtml(html: string): string | null {
  const m = html.match(/<meta property="og:title" content="([^"]+)"/) ?? html.match(/<title>([^<]+)<\/title>/);
  return m ? decodeEntities(m[1]).replace(/\s*-\s*YouTube\s*$/, '').trim() : null;
}

export function looksLikeShort(title: string, link: string): boolean {
  return /#shorts?\b/i.test(title) || /\/shorts\//i.test(link);
}

/** Interpreta el feed Atom del canal. `channelName` se usa si el feed no lo trae. */
export function parseChannelFeed(xml: string, channelId: string, channelName = ''): FeedItemInput[] {
  const out: FeedItemInput[] = [];
  const feedTitle = stripHtml(tag(xml.split('<entry')[0] ?? '', 'title') ?? '') || channelName;
  for (const e of entries(xml)) {
    const videoId = tag(e, 'yt:videoId');
    const title = stripHtml(tag(e, 'title') ?? '');
    if (!videoId || !title) continue;
    const link = attr(e, 'link', 'href') ?? `https://www.youtube.com/watch?v=${videoId}`;
    if (looksLikeShort(title, link)) continue;
    const author = stripHtml(tag(tag(e, 'author') ?? '', 'name') ?? '') || feedTitle || channelName;
    const thumb = attr(e, 'media:thumbnail', 'url') ?? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
    const desc = stripHtml(tag(e, 'media:description') ?? '').slice(0, 300);
    out.push({
      kind: 'video', topic: author || channelId, externalId: `yt:${videoId}`, title, text: desc, url: link, author, authorHandle: '', authorAvatar: null,
      imageUrl: thumb, publishedAt: isoDate(tag(e, 'published')), likes: null, extra: { channelId, videoId },
    });
  }
  return out;
}
