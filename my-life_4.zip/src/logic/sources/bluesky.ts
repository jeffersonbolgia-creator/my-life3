// Bluesky (API pública AT Protocol, sin clave). Sólo lectura.
//  - Cuenta:   GET https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed?actor={handle}&limit=30&filter=posts_no_replies
//  - Tema:     GET https://public.api.bsky.app/xrpc/app.bsky.feed.searchPosts?q={tema}&limit=25&sort=top&lang=es   (puede devolver 403 por carga)
//  - Buscar:   GET https://public.api.bsky.app/xrpc/app.bsky.actor.searchActorsTypeahead?q={texto}&limit=8
// Nada de esto se pudo probar en vivo al escribirlo: si algo cambia, el parser devuelve lista vacía.

import type { FeedItemInput } from '../../db/repos';
import { isHttp } from '../xml';

const BASE = 'https://public.api.bsky.app/xrpc';

export function authorFeedUrl(handle: string, limit = 30): string {
  return `${BASE}/app.bsky.feed.getAuthorFeed?actor=${encodeURIComponent(handle)}&limit=${limit}&filter=posts_no_replies`;
}
export function searchPostsUrl(q: string, limit = 25): string {
  return `${BASE}/app.bsky.feed.searchPosts?q=${encodeURIComponent(q)}&limit=${limit}&sort=top&lang=es`;
}
export function searchActorsUrl(q: string, limit = 8): string {
  return `${BASE}/app.bsky.actor.searchActorsTypeahead?q=${encodeURIComponent(q)}&limit=${limit}`;
}

export interface BskyActor { did: string; handle: string; displayName: string; avatar: string | null; description: string }

/** Normaliza lo que escribe el usuario: "@pepe.bsky.social", "pepe", "bsky.app/profile/pepe.bsky.social". */
export function normalizeHandle(input: string): string {
  let h = input.trim().replace(/^@/, '');
  const m = h.match(/bsky\.app\/profile\/([^/?#\s]+)/i);
  if (m) h = m[1];
  h = h.toLowerCase();
  if (h && !h.includes('.') && !h.startsWith('did:')) h = `${h}.bsky.social`;
  return h;
}

export function postUrl(handle: string, uri: string): string {
  const rkey = uri.split('/').pop() ?? '';
  return `https://bsky.app/profile/${handle}/post/${rkey}`;
}

function imageFromEmbed(embed: any): string | null {
  if (!embed || typeof embed !== 'object') return null;
  const type = String(embed.$type ?? '');
  if (type.startsWith('app.bsky.embed.images') && Array.isArray(embed.images) && embed.images[0]) {
    const img = embed.images[0];
    return isHttp(img.thumb) ? img.thumb : isHttp(img.fullsize) ? img.fullsize : null;
  }
  if (type.startsWith('app.bsky.embed.external') && embed.external) return isHttp(embed.external.thumb) ? embed.external.thumb : null;
  if (type.startsWith('app.bsky.embed.recordWithMedia')) return imageFromEmbed(embed.media);
  if (type.startsWith('app.bsky.embed.video')) return isHttp(embed.thumbnail) ? embed.thumbnail : null;
  return null;
}

function parsePost(post: any, topic: string): FeedItemInput | null {
  if (!post || typeof post !== 'object' || typeof post.uri !== 'string') return null;
  const author = post.author ?? {};
  const record = post.record ?? {};
  const handle = typeof author.handle === 'string' ? author.handle : '';
  const text = typeof record.text === 'string' ? record.text.trim() : '';
  if (!handle || !text) return null;
  const created = typeof record.createdAt === 'string' ? new Date(record.createdAt) : new Date(NaN);
  const publishedAt = Number.isNaN(created.getTime()) ? new Date().toISOString() : created.toISOString();
  const firstLine = text.split('\n')[0].trim();
  return {
    kind: 'post',
    topic,
    externalId: `bsky:${post.uri}`,
    title: firstLine.length > 140 ? firstLine.slice(0, 139) + '…' : firstLine,
    text,
    url: postUrl(handle, post.uri),
    author: typeof author.displayName === 'string' && author.displayName.trim() ? author.displayName.trim() : handle,
    authorHandle: `@${handle}`,
    authorAvatar: isHttp(author.avatar) ? author.avatar : null,
    imageUrl: imageFromEmbed(post.embed),
    publishedAt,
    likes: typeof post.likeCount === 'number' ? post.likeCount : null,
    extra: { reposts: typeof post.repostCount === 'number' ? post.repostCount : 0, replies: typeof post.replyCount === 'number' ? post.replyCount : 0 },
  };
}

/** Respuesta de getAuthorFeed: { feed: [{ post, reason? }] }. Se saltan los reposts. */
export function parseAuthorFeed(json: unknown, topic: string): FeedItemInput[] {
  const feed = (json as any)?.feed;
  if (!Array.isArray(feed)) return [];
  const out: FeedItemInput[] = [];
  for (const f of feed) {
    if (!f || f.reason) continue;
    const p = parsePost(f.post, topic);
    if (p) out.push(p);
  }
  return out;
}

/** Respuesta de searchPosts: { posts: [post] }. */
export function parseSearchPosts(json: unknown, topic: string): FeedItemInput[] {
  const posts = (json as any)?.posts;
  if (!Array.isArray(posts)) return [];
  return posts.map((p) => parsePost(p, topic)).filter((x): x is FeedItemInput => !!x);
}

/** Respuesta de searchActorsTypeahead: { actors: [{ did, handle, displayName, avatar }] }. */
export function parseActors(json: unknown): BskyActor[] {
  const actors = (json as any)?.actors;
  if (!Array.isArray(actors)) return [];
  return actors
    .filter((a) => a && typeof a.handle === 'string')
    .map((a) => ({ did: String(a.did ?? ''), handle: a.handle, displayName: typeof a.displayName === 'string' && a.displayName.trim() ? a.displayName.trim() : a.handle, avatar: isHttp(a.avatar) ? a.avatar : null, description: typeof a.description === 'string' ? a.description.slice(0, 120) : '' }));
}
