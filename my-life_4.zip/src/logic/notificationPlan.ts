// Calcula (sin efectos secundarios) la lista de notificaciones a programar para un perfil.
// La capa de notificaciones de Android toma este plan y lo programa en el sistema.

import type { CalendarEvent, Countdown, Goal, Habit, NotificationSettings, Reminder, Routine, Subscription, Task } from '../types';
import { addDays, addMonths, combineDateTime, isValidTime, toISODate, timeToMinutes } from '../lib/dates';
import { occurrencesInRange } from './calendar';
import { formatMoney } from '../lib/money';

export type ChannelId = 'tasks' | 'events' | 'habits' | 'payments' | 'reminders' | 'goals' | 'summary' | 'countdowns' | 'routines' | 'dollar' | 'subscriptions';

export type PlannedTrigger =
  | { kind: 'date'; date: Date }
  | { kind: 'daily'; hour: number; minute: number }
  | { kind: 'weekly'; weekday: number; hour: number; minute: number }; // weekday: 1 = domingo ... 7 = sábado (formato Android/Expo)

export interface PlannedNotification {
  id: string;
  channel: ChannelId;
  title: string;
  body: string;
  trigger: PlannedTrigger;
  data: { profileId: number; route?: string };
}

export interface PlanInput {
  profileId: number;
  profileName: string;
  settings: NotificationSettings;
  tasks: Task[];
  events: CalendarEvent[];
  habits: Habit[];
  reminders: Reminder[];
  goals: Goal[];
  countdowns?: Countdown[];
  routines?: Routine[];
  subscriptions?: Subscription[];
  now: Date;
  horizonDays?: number;
  maxOneShot?: number;
}

const EVENT_LABEL: Record<string, string> = {
  event: 'Evento',
  appointment: 'Cita',
  birthday: 'Cumpleaños',
  important: 'Fecha importante',
  schedule: 'Horario',
};

function splitTime(t: string): { hour: number; minute: number } {
  const m = timeToMinutes(t);
  return { hour: Math.floor(m / 60), minute: m % 60 };
}

function offsetLabel(min: number): string {
  if (min <= 0) return 'ahora';
  if (min < 60) return `en ${min} min`;
  if (min < 1440) return `en ${Math.round(min / 60)} h`;
  const d = Math.round(min / 1440);
  return d === 1 ? 'mañana' : `en ${d} días`;
}

export function buildNotificationPlan(input: PlanInput): PlannedNotification[] {
  const { profileId: pid, settings: s, now } = input;
  if (!s.enabled) return [];
  const horizon = input.horizonDays ?? 45;
  const maxOneShot = input.maxOneShot ?? 100;
  const today = toISODate(now);
  const until = addDays(today, horizon);
  const defaultTime = isValidTime(s.defaultTime) ? s.defaultTime : '09:00';
  const oneShot: PlannedNotification[] = [];
  const repeating: PlannedNotification[] = [];
  const pfx = `p${pid}:`;
  const data = (route?: string) => ({ profileId: pid, route });

  const pushDate = (n: Omit<PlannedNotification, 'trigger'>, at: Date) => {
    if (at.getTime() <= now.getTime() + 5000) return;
    if (toISODate(at) > until) return;
    oneShot.push({ ...n, trigger: { kind: 'date', date: at } });
  };

  // Tareas
  if (s.tasks) {
    for (const t of input.tasks) {
      if (t.completedAt || !t.dueDate || t.remindMinutes == null) continue;
      const base = combineDateTime(t.dueDate, isValidTime(t.dueTime) ? t.dueTime : defaultTime);
      const at = new Date(base.getTime() - t.remindMinutes * 60000);
      pushDate(
        {
          id: `${pfx}task:${t.id}`,
          channel: 'tasks',
          title: t.remindMinutes > 0 ? `Tarea ${offsetLabel(t.remindMinutes)}` : 'Tarea pendiente',
          body: t.title + (t.dueTime ? ` · ${t.dueTime}` : ''),
          data: data('Tasks'),
        },
        at,
      );
    }
  }

  // Eventos del calendario
  if (s.events) {
    const occ = occurrencesInRange(input.events.filter((e) => e.remindMinutes != null), today, until);
    for (const o of occ) {
      const e = o.event;
      const time = !e.allDay && isValidTime(e.startTime) ? e.startTime : defaultTime;
      const base = combineDateTime(o.date, time);
      const mins = e.allDay ? 0 : e.remindMinutes ?? 0;
      const at = new Date(base.getTime() - mins * 60000);
      const label = EVENT_LABEL[e.type] ?? 'Evento';
      pushDate(
        {
          id: `${pfx}event:${e.id}:${o.date}`,
          channel: 'events',
          title: e.type === 'birthday' ? `Hoy es el cumpleaños de ${e.title}` : `${label}${mins > 0 ? ' ' + offsetLabel(mins) : ''}`,
          body: e.type === 'birthday' ? 'No te olvides de saludar.' : `${e.title}${!e.allDay && e.startTime ? ' · ' + e.startTime : ''}${e.location ? ' · ' + e.location : ''}`,
          data: data('Calendar'),
        },
        at,
      );
    }
  }

  // Recordatorios generales y de pagos
  for (const r of input.reminders) {
    if (r.done) continue;
    const isPay = r.kind === 'payment';
    if (isPay ? !s.payments : !s.reminders) continue;
    if (!isValidTime(r.time)) continue;
    const base = {
      channel: (isPay ? 'payments' : 'reminders') as ChannelId,
      title: isPay ? 'Recordatorio de pago' : 'Recordatorio',
      body: r.title + (isPay && r.amount ? ` · ${formatMoney(r.amount)}` : ''),
      data: data('Reminders'),
    };
    if (r.repeat === 'daily') {
      repeating.push({ ...base, id: `${pfx}rem:${r.id}`, trigger: { kind: 'daily', ...splitTime(r.time) } });
    } else if (r.repeat === 'weekly') {
      const wd = new Date(combineDateTime(r.date, r.time)).getDay();
      repeating.push({ ...base, id: `${pfx}rem:${r.id}`, trigger: { kind: 'weekly', weekday: wd + 1, ...splitTime(r.time) } });
    } else if (r.repeat === 'monthly') {
      let d = r.date;
      let i = 0;
      while (d <= until && i < 60) {
        if (d >= today) pushDate({ ...base, id: `${pfx}rem:${r.id}:${d}` }, combineDateTime(d, r.time));
        i++;
        d = addMonths(r.date, i);
      }
    } else {
      pushDate({ ...base, id: `${pfx}rem:${r.id}` }, combineDateTime(r.date, r.time));
    }
  }

  // Hábitos
  if (s.habits) {
    for (const h of input.habits) {
      if (h.archived || !isValidTime(h.reminderTime)) continue;
      const t = splitTime(h.reminderTime);
      const base = { channel: 'habits' as ChannelId, title: 'Hábito', body: `Es momento de: ${h.title}`, data: data('Habits') };
      const days = h.frequency === 'daily' && h.weekdays.length && h.weekdays.length < 7 ? h.weekdays : null;
      if (!days) repeating.push({ ...base, id: `${pfx}habit:${h.id}`, trigger: { kind: 'daily', ...t } });
      else for (const wd of days) repeating.push({ ...base, id: `${pfx}habit:${h.id}:${wd}`, trigger: { kind: 'weekly', weekday: wd + 1, ...t } });
    }
  }

  // Objetivos: aviso 3 días antes y el día límite
  if (s.goals) {
    for (const g of input.goals) {
      if (g.completedAt || !g.targetDate) continue;
      const before = addDays(g.targetDate, -3);
      pushDate(
        { id: `${pfx}goal:${g.id}:pre`, channel: 'goals', title: 'Objetivo: faltan 3 días', body: `${g.title} · ${g.progress}% completado`, data: data('Goals') },
        combineDateTime(before, defaultTime),
      );
      pushDate(
        { id: `${pfx}goal:${g.id}:due`, channel: 'goals', title: 'Hoy vence tu objetivo', body: `${g.title} · ${g.progress}% completado`, data: data('Goals') },
        combineDateTime(g.targetDate, defaultTime),
      );
    }
  }

  // Cuentas regresivas: aviso N días antes (a la hora por defecto) y el mismo día
  if (s.reminders) {
    for (const c of input.countdowns ?? []) {
      if (c.remindDaysBefore == null) continue;
      const time = isValidTime(c.time) ? c.time : defaultTime;
      if (c.remindDaysBefore > 0) {
        pushDate(
          { id: `${pfx}cd:${c.id}:pre`, channel: 'countdowns', title: `Faltan ${c.remindDaysBefore} ${c.remindDaysBefore === 1 ? 'día' : 'días'}`, body: c.title, data: data('Countdowns') },
          combineDateTime(addDays(c.date, -c.remindDaysBefore), defaultTime),
        );
      }
      pushDate(
        { id: `${pfx}cd:${c.id}:day`, channel: 'countdowns', title: '¡Es hoy!', body: c.title, data: data('Countdowns') },
        combineDateTime(c.date, time),
      );
    }
  }

  // Rutinas: aviso diario (o por día de semana) a la hora de inicio
  if (s.habits) {
    for (const r of input.routines ?? []) {
      if (r.archived || !r.remind || !isValidTime(r.startTime) || !r.steps.length) continue;
      const t = splitTime(r.startTime);
      const base = { channel: 'routines' as ChannelId, title: r.title, body: `Arrancá con: ${r.steps[0].title}`, data: data('Routines') };
      const days = r.weekdays.length && r.weekdays.length < 7 ? r.weekdays : null;
      if (!days) repeating.push({ ...base, id: `${pfx}routine:${r.id}`, trigger: { kind: 'daily', ...t } });
      else for (const wd of days) repeating.push({ ...base, id: `${pfx}routine:${r.id}:${wd}`, trigger: { kind: 'weekly', weekday: wd + 1, ...t } });
    }
  }

  // Suscripciones: aviso N días antes del cobro y el mismo día (usa el canal de pagos del perfil)
  if (s.payments) {
    for (const sub of input.subscriptions ?? []) {
      if (!sub.active || sub.remindDaysBefore == null) continue;
      const amount = sub.currency === 'USD' ? `US$ ${(sub.amount / 100).toFixed(2).replace('.', ',')}` : formatMoney(sub.amount);
      if (sub.remindDaysBefore > 0) {
        pushDate(
          { id: `${pfx}sub:${sub.id}:pre`, channel: 'subscriptions', title: `En ${sub.remindDaysBefore} ${sub.remindDaysBefore === 1 ? 'día' : 'días'} se cobra ${sub.name}`, body: amount, data: data('Subscriptions') },
          combineDateTime(addDays(sub.nextDate, -sub.remindDaysBefore), defaultTime),
        );
      }
      pushDate(
        { id: `${pfx}sub:${sub.id}:day`, channel: 'subscriptions', title: `Hoy se cobra ${sub.name}`, body: amount, data: data('Subscriptions') },
        combineDateTime(sub.nextDate, defaultTime),
      );
    }
  }

  // Resumen diario
  if (s.dailySummary && isValidTime(s.dailySummaryTime)) {
    repeating.push({
      id: `${pfx}summary`,
      channel: 'summary',
      title: `Tu día, ${input.profileName}`,
      body: 'Revisá tus tareas, eventos y hábitos de hoy.',
      data: data('Home'),
      trigger: { kind: 'daily', ...splitTime(s.dailySummaryTime) },
    });
  }

  oneShot.sort((a, b) => (a.trigger as { date: Date }).date.getTime() - (b.trigger as { date: Date }).date.getTime());
  let plan = [...repeating, ...oneShot.slice(0, maxOneShot)];

  if (s.discreet) {
    plan = plan.map((n) => ({ ...n, title: 'MY LIFE', body: `Tenés un aviso nuevo, ${input.profileName}.` }));
  }
  return plan;
}
