// Pendientes y "qué ver": sugerencias según los gustos de cada usuario, sin IA externa.

import type { WatchItem, WatchKind } from '../types';
import { normalizeText } from '../lib/text';

export const WATCH_KIND_LABELS: Record<WatchKind, { one: string; many: string; icon: string; color: string }> = {
  game: { one: 'Juego', many: 'Juegos', icon: 'Gamepad2', color: '#3B82F6' },
  show: { one: 'Serie', many: 'Series', icon: 'Tv', color: '#E11D48' },
  movie: { one: 'Película', many: 'Películas', icon: 'Clapperboard', color: '#F43F5E' },
};

export const STATUS_LABELS = { pending: 'Pendiente', current: 'En curso', done: 'Terminado' } as const;

/** Géneros que se reconocen en la frase ("algo de acción", "una comedia corta"). */
const GENRE_WORDS: Record<string, string[]> = {
  'Acción': ['accion', 'peleas', 'tiros', 'adrenalina'],
  'Comedia': ['comedia', 'reir', 'reirme', 'gracioso', 'divertido', 'liviano', 'liviana'],
  'Terror': ['terror', 'miedo', 'horror', 'susto'],
  'Drama': ['drama', 'llorar', 'profundo', 'profunda', 'serio', 'seria'],
  'Ciencia ficción': ['ciencia ficcion', 'sci fi', 'scifi', 'espacio', 'futurista'],
  'Fantasía': ['fantasia', 'magia', 'dragones'],
  'Suspenso': ['suspenso', 'thriller', 'misterio', 'intriga', 'policial'],
  'Romance': ['romance', 'romantica', 'romantico', 'amor'],
  'Animación': ['animacion', 'anime', 'animada', 'dibujos'],
  'Documental': ['documental', 'real', 'historia real'],
  'Aventura': ['aventura', 'aventuras', 'explorar'],
  'Crimen': ['crimen', 'mafia', 'narcos'],
  'Familia': ['familia', 'familiar', 'niños', 'ninos', 'chicos'],
  'Deportes': ['deporte', 'deportes', 'futbol', 'ufc'],
  'RPG': ['rpg', 'rol'],
  'Estrategia': ['estrategia'],
  'Shooter': ['shooter', 'fps'],
};

export interface WatchQuery {
  kind: WatchKind | null;
  genres: string[];
  short: boolean;
  text: string;
}

export function parseWatchQuery(raw: string): WatchQuery {
  const t = normalizeText(raw);
  const kind: WatchKind | null = /\b(serie|series|capitulo|temporada)\b/.test(t) ? 'show' : /\b(pelicula|peli|pelis|film)\b/.test(t) ? 'movie' : /\b(juego|jugar|videojuego|play|steam)\b/.test(t) ? 'game' : null;
  const genres = Object.entries(GENRE_WORDS).filter(([, ws]) => ws.some((w) => new RegExp(`\\b${w}\\b`).test(t))).map(([g]) => g);
  return { kind, genres, short: /\b(corto|corta|rapido|rapida|poco tiempo|una hora|un rato)\b/.test(t), text: raw };
}

export interface Suggestion { item: WatchItem; score: number; reason: string }

/**
 * Sugiere qué ver/jugar de los pendientes:
 *  - coincide con el tipo y los géneros pedidos
 *  - géneros que el usuario puntuó alto en lo ya terminado pesan más
 *  - lo "en curso" va primero (para terminar lo empezado)
 *  - si pidió algo corto, prefiere películas a series
 */
export function suggest(items: WatchItem[], q: WatchQuery, feedTopics: string[] = []): Suggestion[] {
  const candidates = items.filter((i) => i.status !== 'done' && (!q.kind || i.kind === q.kind));
  if (!candidates.length) return [];
  // Gustos: promedio de puntaje por género en lo terminado
  const taste = new Map<string, { sum: number; n: number }>();
  for (const d of items) {
    if (d.status !== 'done' || !d.rating) continue;
    for (const g of d.genres) {
      const k = normalizeText(g);
      const cur = taste.get(k) ?? { sum: 0, n: 0 };
      taste.set(k, { sum: cur.sum + d.rating, n: cur.n + 1 });
    }
  }
  const topicSet = new Set(feedTopics.map(normalizeText));
  const out: Suggestion[] = candidates.map((item) => {
    let score = 0;
    const reasons: string[] = [];
    const gs = item.genres.map(normalizeText);
    const askedHit = q.genres.filter((g) => gs.includes(normalizeText(g)));
    if (q.genres.length) {
      if (askedHit.length) { score += 5 * askedHit.length; reasons.push(`es de ${askedHit.join(' y ').toLowerCase()}`); }
      else score -= 2;
    }
    for (const g of gs) {
      const tst = taste.get(g);
      if (tst && tst.n) {
        const avg = tst.sum / tst.n;
        score += (avg - 3) * 1.2;
        if (avg >= 4 && !reasons.length) reasons.push(`te gustó lo de ${item.genres[gs.indexOf(g)].toLowerCase()} que viste`);
      }
      if (topicSet.has(g)) score += 0.8;
    }
    if (item.status === 'current') { score += 2.5; reasons.push('ya lo empezaste'); }
    if (q.short) { if (item.kind === 'movie') score += 2; if (item.kind === 'show') score -= 1; }
    if (item.rating) score += (item.rating - 3) * 0.5;
    // Lo agregado hace poco pesa un poco más
    const ageDays = Math.max(0, (Date.now() - new Date(item.createdAt.replace(' ', 'T')).getTime()) / 86400_000);
    score += Math.max(0, 1 - ageDays / 60);
    return { item, score, reason: reasons[0] ?? (item.kind === 'game' ? 'lo tenés pendiente' : 'está en tu lista') };
  });
  return out.sort((a, b) => b.score - a.score).slice(0, 3);
}

/** Texto para la respuesta de Nova. */
export function suggestionText(s: Suggestion[], q: WatchQuery): string {
  if (!s.length) {
    if (q.kind) return `No tenés ${q.kind === 'game' ? 'juegos' : q.kind === 'show' ? 'series' : 'películas'} pendientes. Agregá alguno en Más → Pendientes y te sugiero.`;
    return 'Tu lista de pendientes está vacía. Cargá series, películas o juegos en Más → Pendientes y te recomiendo según tus gustos.';
  }
  const first = s[0];
  const label = first.item.kind === 'game' ? 'Jugá' : 'Mirá';
  const rest = s.slice(1).map((x) => `${x.item.title} (${x.reason})`).join(' o ');
  return `${label} ${first.item.title}: ${first.reason}.${rest ? ` Si no, ${rest}.` : ''}`;
}
