// Feriados y fines de semana largos (sin red).

import type { Holiday } from '../types';
import { addDays, diffDays, weekday } from '../lib/dates';

export interface LongWeekend {
  from: string;
  to: string;
  days: number;
  holidays: Holiday[];
}

/** Próximo feriado desde hoy (inclusive). */
export function nextHoliday(holidays: Holiday[], today: string): Holiday | null {
  return [...holidays].filter((h) => h.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0] ?? null;
}

/** Días hasta una fecha (0 = hoy). */
export function daysUntil(date: string, today: string): number {
  return diffDays(date, today);
}

const isWeekend = (d: string) => { const w = weekday(d); return w === 0 || w === 6; };

/**
 * Fines de semana largos: tramos de 3 o más días libres seguidos (sábado, domingo y feriados).
 * Se consideran los feriados "inamovibles", "trasladables" y "puentes"; no los días no laborables optativos.
 */
export function longWeekends(holidays: Holiday[], from: string, to: string): LongWeekend[] {
  const set = new Map<string, Holiday>();
  for (const h of holidays) if (h.date >= addDays(from, -7) && h.date <= addDays(to, 7) && !/no laborable/i.test(h.type)) set.set(h.date, h);
  const out: LongWeekend[] = [];
  let d = addDays(from, -7);
  const end = addDays(to, 7);
  let runStart: string | null = null;
  let runHols: Holiday[] = [];
  const close = (last: string) => {
    if (runStart) {
      const days = diffDays(last, runStart) + 1;
      if (days >= 3 && runHols.length) out.push({ from: runStart, to: last, days, holidays: runHols });
    }
    runStart = null;
    runHols = [];
  };
  while (d <= end) {
    const h = set.get(d);
    if (isWeekend(d) || h) {
      if (!runStart) runStart = d;
      if (h) runHols.push(h);
    } else close(addDays(d, -1));
    d = addDays(d, 1);
  }
  close(end);
  return out.filter((lw) => lw.to >= from && lw.from <= to);
}

export function nextLongWeekend(holidays: Holiday[], today: string): LongWeekend | null {
  return longWeekends(holidays, today, addDays(today, 400)).find((lw) => lw.to >= today) ?? null;
}

export function holidayLabel(h: Holiday): string {
  const t = h.type.toLowerCase();
  if (t.includes('inamovible')) return 'Inamovible';
  if (t.includes('trasladable')) return 'Trasladable';
  if (t.includes('puente')) return 'Puente';
  if (t.includes('no laborable')) return 'No laborable';
  return h.type ? h.type.charAt(0).toUpperCase() + h.type.slice(1) : '';
}
