// Lógica del dólar: interpretación de las respuestas de las APIs, series para el gráfico y alertas.
// Sin efectos secundarios (testeable). La red está en services/dollarService.ts.

import type { DollarAlert, DollarCasa, DollarRate } from '../types';
import { addDays, diffDays, toISODate } from '../lib/dates';

export const CASA_LABELS: Record<DollarCasa, { short: string; long: string }> = {
  blue: { short: 'Blue', long: 'Dólar blue' },
  oficial: { short: 'Oficial', long: 'Dólar oficial' },
  bolsa: { short: 'MEP', long: 'Dólar MEP (bolsa)' },
  contadoconliqui: { short: 'CCL', long: 'Contado con liqui' },
  tarjeta: { short: 'Tarjeta', long: 'Dólar tarjeta' },
  mayorista: { short: 'Mayorista', long: 'Dólar mayorista' },
  cripto: { short: 'Cripto', long: 'Dólar cripto' },
  eur: { short: 'Euro', long: 'Euro' },
  brl: { short: 'Real', long: 'Real brasileño' },
  clp: { short: 'Chileno', long: 'Peso chileno' },
  uyu: { short: 'Uruguayo', long: 'Peso uruguayo' },
};

export const CASA_ORDER: DollarCasa[] = ['blue', 'oficial', 'bolsa', 'contadoconliqui', 'tarjeta', 'mayorista', 'cripto', 'eur', 'brl', 'clp', 'uyu'];

/** Las "casas" que no son dólar: otras monedas (cotización oficial). */
export const CURRENCY_CASAS: DollarCasa[] = ['eur', 'brl', 'clp', 'uyu'];
export const isCurrencyCasa = (c: DollarCasa) => CURRENCY_CASAS.includes(c);

/** Símbolo para mostrar junto al precio de cada cotización. */
export const CASA_SYMBOL: Partial<Record<DollarCasa, string>> = { eur: '€', brl: 'R$', clp: 'CLP', uyu: '$U' };

/** Qué moneda devuelve DolarAPI en /v1/cotizaciones y a qué clave la mapeamos. */
const MONEDA_TO_CASA: Record<string, DollarCasa> = { EUR: 'eur', BRL: 'brl', CLP: 'clp', UYU: 'uyu' };

export function isCasa(v: unknown): v is DollarCasa {
  return typeof v === 'string' && (CASA_ORDER as string[]).includes(v);
}

const num = (v: unknown): number | null => {
  const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v.replace(',', '.')) : NaN;
  return Number.isFinite(n) && n > 0 ? n : null;
};

/**
 * Interpreta la respuesta de DolarAPI (`GET https://dolarapi.com/v1/dolares`):
 * [{ moneda, casa, nombre, compra, venta, fechaActualizacion }]
 */
export function parseDolarApi(json: unknown, now: Date = new Date()): DollarRate[] {
  if (!Array.isArray(json)) return [];
  const out: DollarRate[] = [];
  for (const r of json) {
    if (!r || typeof r !== 'object') continue;
    const casa = (r as any).casa;
    if (!isCasa(casa)) continue;
    const sell = num((r as any).venta);
    const buy = num((r as any).compra) ?? sell;
    if (!sell || !buy) continue;
    const upd = typeof (r as any).fechaActualizacion === 'string' ? new Date((r as any).fechaActualizacion) : now;
    const when = Number.isNaN(upd.getTime()) ? now : upd;
    out.push({ casa, date: toISODate(when), buy, sell, updatedAt: when.toISOString() });
  }
  return out;
}

/**
 * Interpreta la respuesta de DolarAPI para otras monedas (`GET https://dolarapi.com/v1/cotizaciones`):
 * [{ moneda: "EUR", casa: "oficial", nombre, compra, venta, fechaActualizacion }]. El dólar (USD) se ignora acá.
 */
export function parseCotizaciones(json: unknown, now: Date = new Date()): DollarRate[] {
  if (!Array.isArray(json)) return [];
  const out: DollarRate[] = [];
  for (const r of json) {
    if (!r || typeof r !== 'object') continue;
    const casa = MONEDA_TO_CASA[String((r as any).moneda ?? '').toUpperCase()];
    if (!casa) continue;
    const sell = num((r as any).venta);
    const buy = num((r as any).compra) ?? sell;
    if (!sell || !buy) continue;
    const upd = typeof (r as any).fechaActualizacion === 'string' ? new Date((r as any).fechaActualizacion) : now;
    const when = Number.isNaN(upd.getTime()) ? now : upd;
    out.push({ casa, date: toISODate(when), buy, sell, updatedAt: when.toISOString() });
  }
  return out;
}

/**
 * Interpreta el histórico de ArgentinaDatos (`GET https://api.argentinadatos.com/v1/cotizaciones/dolares/{casa}`):
 * [{ casa, compra, venta, fecha }] con fecha YYYY-MM-DD.
 * Para otras monedas (`/v1/cotizaciones/eur`) las filas dicen casa "oficial": se pasa `forceCasa` para etiquetarlas bien.
 */
export function parseArgentinaDatos(json: unknown, casaHint?: DollarCasa, forceCasa = false): DollarRate[] {
  if (!Array.isArray(json)) return [];
  const out: DollarRate[] = [];
  for (const r of json) {
    if (!r || typeof r !== 'object') continue;
    const casa = forceCasa && casaHint ? casaHint : isCasa((r as any).casa) ? (r as any).casa : casaHint;
    const date = (r as any).fecha;
    if (!casa || typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) continue;
    const sell = num((r as any).venta);
    const buy = num((r as any).compra) ?? sell;
    if (!sell || !buy) continue;
    out.push({ casa, date, buy, sell, updatedAt: `${date}T12:00:00.000Z` });
  }
  return out;
}

export type Period = 7 | 30 | 90;

/** Puntos para el gráfico: un valor (venta) por día en los últimos `days` días. */
export function seriesFor(rates: DollarRate[], days: Period, now: Date = new Date()): { date: string; value: number }[] {
  const to = toISODate(now);
  const from = addDays(to, -(days - 1));
  return rates
    .filter((r) => r.date >= from && r.date <= to)
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((r) => ({ date: r.date, value: r.sell }));
}

/** Variación contra el día anterior disponible: { abs, pct } o null si no hay con qué comparar. */
export function variation(rates: DollarRate[], casa: DollarCasa): { abs: number; pct: number; prevDate: string } | null {
  const mine = rates.filter((r) => r.casa === casa).sort((a, b) => b.date.localeCompare(a.date));
  if (mine.length < 2) return null;
  const [cur, prev] = mine;
  const abs = cur.sell - prev.sell;
  return { abs, pct: prev.sell ? (abs / prev.sell) * 100 : 0, prevDate: prev.date };
}

/** Precio de una cotización: el peso chileno vale ~1,6 pesos, así que las monedas chicas siempre llevan decimales. */
export function formatRate(v: number, casa?: DollarCasa): string {
  if (casa === 'clp' || v < 50) {
    const s = (Math.round(v * 100) / 100).toFixed(2).replace('.', ',');
    return `$ ${s}`;
  }
  return formatPesos(v);
}

/** "$ 1.485" sin decimales si es entero, o con 2 decimales. */
export function formatPesos(v: number): string {
  const rounded = Math.round(v * 100) / 100;
  const int = Math.floor(rounded);
  const dec = Math.round((rounded - int) * 100);
  const body = String(int).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return dec ? `$ ${body},${dec < 10 ? '0' + dec : dec}` : `$ ${body}`;
}

export function formatPct(p: number): string {
  const s = (Math.round(Math.abs(p) * 10) / 10).toFixed(1).replace('.', ',');
  return `${p > 0 ? '+' : p < 0 ? '-' : ''}${s}%`;
}

/** Convierte un monto en centavos de USD a centavos de ARS con la cotización (venta) dada. */
export function usdToArsCents(usdCents: number, sell: number): number {
  return Math.round(usdCents * sell);
}

export interface AlertHit {
  alert: DollarAlert;
  rate: DollarRate;
  title: string;
  body: string;
}

/**
 * Qué alertas se disparan con las cotizaciones actuales.
 * - above/below: comparan la venta con el umbral. Se vuelven a disparar sólo si pasaron 12 h desde la última.
 * - change: variación absoluta del día (contra el día anterior) mayor o igual al porcentaje.
 */
export function evaluateAlerts(alerts: DollarAlert[], rates: DollarRate[], now: Date = new Date()): AlertHit[] {
  const hits: AlertHit[] = [];
  for (const a of alerts) {
    if (!a.enabled) continue;
    const mine = rates.filter((r) => r.casa === a.casa).sort((x, y) => y.date.localeCompare(x.date));
    const cur = mine[0];
    if (!cur) continue;
    if (a.lastFiredAt) {
      const last = new Date(a.lastFiredAt.replace(' ', 'T')).getTime();
      if (Number.isFinite(last) && now.getTime() - last < 12 * 3600_000) continue;
    }
    const label = CASA_LABELS[a.casa].long;
    if (a.kind === 'above' && cur.sell >= a.value) {
      hits.push({ alert: a, rate: cur, title: `${label} pasó de ${formatPesos(a.value)}`, body: `Está a ${formatPesos(cur.sell)}.` });
    } else if (a.kind === 'below' && cur.sell <= a.value) {
      hits.push({ alert: a, rate: cur, title: `${label} bajó de ${formatPesos(a.value)}`, body: `Está a ${formatPesos(cur.sell)}.` });
    } else if (a.kind === 'change') {
      const v = variation(rates, a.casa);
      if (v && Math.abs(v.pct) >= a.value) {
        hits.push({ alert: a, rate: cur, title: `${label} ${v.abs > 0 ? 'subió' : 'bajó'} ${formatPct(Math.abs(v.pct))}`, body: `Está a ${formatPesos(cur.sell)} (${v.abs > 0 ? '+' : ''}${formatPesos(v.abs)} desde el ${v.prevDate.slice(8)}/${v.prevDate.slice(5, 7)}).` });
      }
    }
  }
  return hits;
}

export function describeAlert(a: Pick<DollarAlert, 'casa' | 'kind' | 'value'>): string {
  const label = CASA_LABELS[a.casa].short;
  if (a.kind === 'above') return `${label} pasa de ${formatPesos(a.value)}`;
  if (a.kind === 'below') return `${label} baja de ${formatPesos(a.value)}`;
  return `${label} sube o baja más de ${formatPct(a.value).replace('+', '')} en el día`;
}

/** ¿Hace cuánto se actualizó? "hace 5 min", "hace 3 h", "ayer", "hace 4 días". */
export function freshness(updatedAt: string, now: Date = new Date()): string {
  const t = new Date(updatedAt).getTime();
  if (!Number.isFinite(t)) return '';
  const mins = Math.round((now.getTime() - t) / 60000);
  if (mins < 1) return 'recién';
  if (mins < 60) return `hace ${mins} min`;
  const h = Math.round(mins / 60);
  if (h < 24) return `hace ${h} h`;
  const d = diffDays(toISODate(now), toISODate(new Date(t)));
  return d === 1 ? 'ayer' : `hace ${d} días`;
}
