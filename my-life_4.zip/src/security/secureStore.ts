import * as SecureStore from 'expo-secure-store';
import * as Crypto from 'expo-crypto';
import { configureSecurity } from './pin';

export function initSecurity() {
  configureSecurity(
    {
      get: (k) => SecureStore.getItemAsync(k),
      set: (k, v) => SecureStore.setItemAsync(k, v),
      del: (k) => SecureStore.deleteItemAsync(k),
    },
    (n) => Crypto.getRandomBytes(n),
  );
}
