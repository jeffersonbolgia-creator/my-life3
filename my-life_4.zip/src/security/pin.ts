// Gestión de PIN y respuesta de recuperación.
// Se guardan como hash PBKDF2-SHA256 con sal aleatoria dentro del almacenamiento
// cifrado del sistema (Android Keystore vía expo-secure-store).

import { hashSecret, verifySecret, toHex } from '../lib/crypto';
import { normalizeText } from '../lib/text';

export interface KeyStore {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  del(key: string): Promise<void>;
}

let store: KeyStore | null = null;
let randomBytes: (n: number) => Uint8Array = (n) => {
  const out = new Uint8Array(n);
  for (let i = 0; i < n; i++) out[i] = Math.floor(Math.random() * 256);
  return out;
};

export function configureSecurity(s: KeyStore, rng?: (n: number) => Uint8Array) {
  store = s;
  if (rng) randomBytes = rng;
}

function ks(): KeyStore {
  if (!store) throw new Error('Almacenamiento seguro no configurado');
  return store;
}

const pinKey = (pid: number) => `mylife_pin_${pid}`;
const recKey = (pid: number) => `mylife_recovery_${pid}`;
const prefixKey = (pid: number) => `mylife_pinprefix_${pid}`;
const LOCK_KEY = 'mylife_lock_state';

export function isValidPin(pin: string, length?: 4 | 6): boolean {
  if (!/^\d+$/.test(pin)) return false;
  return length ? pin.length === length : pin.length === 4 || pin.length === 6;
}

/** Rechaza PIN demasiado obvios: 0000, 1111, 1234, 123456, 4321... */
export function isWeakPin(pin: string): boolean {
  if (/^(\d)\1+$/.test(pin)) return true;
  const asc = '01234567890';
  const desc = '09876543210';
  return asc.includes(pin) || desc.includes(pin);
}

function newSalt(): string {
  return toHex(randomBytes(16));
}

export async function setPin(pid: number, pin: string): Promise<void> {
  if (!isValidPin(pin)) throw new Error('El PIN debe tener 4 o 6 números');
  await ks().set(pinKey(pid), hashSecret(pin, newSalt()));
  // Para PIN de 6 dígitos se guarda también el hash de los primeros 4, así se evita
  // que el PIN de 4 dígitos de otra persona coincida con el comienzo de este.
  if (pin.length === 6) await ks().set(prefixKey(pid), hashSecret(pin.slice(0, 4), newSalt()));
  else await ks().del(prefixKey(pid));
}

export async function hasPin(pid: number): Promise<boolean> {
  return !!(await ks().get(pinKey(pid)));
}

export async function checkPin(pid: number, pin: string): Promise<boolean> {
  const stored = await ks().get(pinKey(pid));
  return !!stored && verifySecret(pin, stored);
}

/** Busca qué perfil corresponde al PIN ingresado. */
export async function identifyByPin(profileIds: number[], pin: string): Promise<number | null> {
  for (const id of profileIds) {
    if (await checkPin(id, pin)) return id;
  }
  return null;
}

/**
 * ¿El PIN choca con el de otro perfil? Los PIN deben ser distintos para identificar a cada persona,
 * y un PIN de 4 dígitos no puede ser el comienzo de un PIN de 6 de otra persona (ni al revés).
 */
export async function pinInUse(profileIds: number[], pin: string, exceptId?: number): Promise<boolean> {
  const others = profileIds.filter((id) => id !== exceptId);
  for (const id of others) {
    if (await checkPin(id, pin)) return true;
    if (pin.length === 6 && (await checkPin(id, pin.slice(0, 4)))) return true;
    if (pin.length === 4) {
      const pref = await ks().get(prefixKey(id));
      if (pref && verifySecret(pin, pref)) return true;
    }
  }
  return false;
}

export async function setRecoveryAnswer(pid: number, answer: string): Promise<void> {
  const norm = normalizeText(answer);
  if (norm.length < 2) throw new Error('La respuesta es muy corta');
  await ks().set(recKey(pid), hashSecret(norm, newSalt()));
}

export async function checkRecoveryAnswer(pid: number, answer: string): Promise<boolean> {
  const stored = await ks().get(recKey(pid));
  return !!stored && verifySecret(normalizeText(answer), stored);
}

export async function deleteSecrets(pid: number): Promise<void> {
  await ks().del(pinKey(pid));
  await ks().del(recKey(pid));
  await ks().del(prefixKey(pid));
}

// ---------- Protección contra intentos incorrectos ----------

export interface LockState {
  failures: number;
  lockedUntil: number; // epoch ms
}

/** Cada 5 intentos fallidos se bloquea: 30 s, 1 min, 2 min, 4 min... hasta 15 min. */
export function lockoutDuration(failures: number): number {
  if (failures < 5 || failures % 5 !== 0) return 0;
  const step = failures / 5 - 1;
  return Math.min(30_000 * Math.pow(2, step), 15 * 60_000);
}

export async function getLockState(): Promise<LockState> {
  const raw = await ks().get(LOCK_KEY);
  if (!raw) return { failures: 0, lockedUntil: 0 };
  try {
    const p = JSON.parse(raw);
    return { failures: Number(p.failures) || 0, lockedUntil: Number(p.lockedUntil) || 0 };
  } catch {
    return { failures: 0, lockedUntil: 0 };
  }
}

export async function registerFailure(now = Date.now()): Promise<LockState> {
  const s = await getLockState();
  const failures = s.failures + 1;
  const dur = lockoutDuration(failures);
  const next = { failures, lockedUntil: dur ? now + dur : s.lockedUntil };
  await ks().set(LOCK_KEY, JSON.stringify(next));
  return next;
}

export async function resetFailures(): Promise<void> {
  await ks().set(LOCK_KEY, JSON.stringify({ failures: 0, lockedUntil: 0 }));
}

export const SECURITY_QUESTIONS = [
  '¿Cómo se llamaba tu primera mascota?',
  '¿Cuál es el nombre de tu mejor amigo de la infancia?',
  '¿En qué calle vivías de chico?',
  '¿Cuál es tu comida favorita?',
  '¿Cómo se llama tu escuela primaria?',
  '¿Cuál es el segundo nombre de tu mamá?',
];
