// Dinero: se guarda siempre en centavos (enteros) para evitar errores de redondeo.

export type CurrencyCode = 'ARS' | 'USD' | 'EUR';

const SYMBOLS: Record<CurrencyCode, string> = { ARS: '$', USD: 'US$', EUR: '€' };

function groupThousands(intStr: string): string {
  return intStr.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

/** 600000 -> "$ 6.000"; 600050 -> "$ 6.000,50" */
export function formatMoney(cents: number, currency: CurrencyCode = 'ARS', opts?: { forceDecimals?: boolean; sign?: boolean }): string {
  const safe = Number.isFinite(cents) ? Math.round(cents) : 0;
  const neg = safe < 0;
  const abs = Math.abs(safe);
  const units = Math.floor(abs / 100);
  const dec = abs % 100;
  let body = groupThousands(String(units));
  if (dec !== 0 || opts?.forceDecimals) body += ',' + (dec < 10 ? '0' + dec : String(dec));
  const prefix = neg ? '-' : opts?.sign && safe > 0 ? '+' : '';
  return `${prefix}${SYMBOLS[currency] ?? '$'} ${body}`;
}

/** Versión compacta para gráficos: "$ 1,2 M", "$ 350 k" */
export function formatMoneyCompact(cents: number, currency: CurrencyCode = 'ARS'): string {
  const v = Math.abs(cents) / 100;
  const sign = cents < 0 ? '-' : '';
  const sym = SYMBOLS[currency] ?? '$';
  if (v >= 1_000_000) return `${sign}${sym} ${(v / 1_000_000).toFixed(1).replace('.', ',').replace(',0', '')} M`;
  if (v >= 10_000) return `${sign}${sym} ${Math.round(v / 1000)} k`;
  return formatMoney(cents, currency);
}

/**
 * Interpreta lo que escribe el usuario en formato argentino.
 * "2.000" -> 200000, "2000,50" -> 200050, "1.234.567,8" -> 123456780, "2.5" -> 250
 * Devuelve null si no es un número válido.
 */
export function parseAmount(input: string): number | null {
  if (input == null) return null;
  let s = String(input).replace(/[\s$€]|US/g, '').trim();
  if (!s) return null;
  if (!/^-?[\d.,]+$/.test(s)) return null;
  const neg = s.startsWith('-');
  if (neg) s = s.slice(1);
  let intPart = s;
  let decPart = '';
  const lastComma = s.lastIndexOf(',');
  if (lastComma >= 0) {
    intPart = s.slice(0, lastComma).replace(/\./g, '');
    decPart = s.slice(lastComma + 1);
    if (decPart.includes('.')) return null;
  } else {
    const dots = s.split('.');
    if (dots.length > 1) {
      const last = dots[dots.length - 1];
      if (dots.length === 2 && last.length > 0 && last.length <= 2) {
        intPart = dots[0];
        decPart = last;
      } else {
        // puntos como separadores de miles: cada grupo después del primero debe tener 3 dígitos
        if (dots.slice(1).some((g) => g.length !== 3)) return null;
        intPart = dots.join('');
      }
    }
  }
  if (intPart === '' && decPart === '') return null;
  if (!/^\d*$/.test(intPart) || !/^\d*$/.test(decPart)) return null;
  if (decPart.length > 2) decPart = decPart.slice(0, 2);
  const cents = Number(intPart || '0') * 100 + Number((decPart + '00').slice(0, 2));
  if (!Number.isFinite(cents) || cents > 1e15) return null;
  return neg ? -cents : cents;
}

/** Cantidad de unidades (admite decimales, ej. 1,5 kg). */
export function parseQuantity(input: string): number | null {
  const s = String(input ?? '').trim().replace(',', '.');
  if (!s || !/^\d+(\.\d+)?$/.test(s)) return null;
  const n = Number(s);
  return n > 0 && n < 1e7 ? n : null;
}

export function multiplyAmount(quantity: number, unitCents: number): number {
  return Math.round(quantity * unitCents);
}

/** Convierte centavos a texto editable "6000" o "6000,50". */
export function centsToInput(cents: number | null | undefined): string {
  if (cents == null) return '';
  const abs = Math.abs(Math.round(cents));
  const units = Math.floor(abs / 100);
  const dec = abs % 100;
  const body = dec ? `${units},${dec < 10 ? '0' + dec : dec}` : String(units);
  return (cents < 0 ? '-' : '') + body;
}

export function formatQuantity(q: number): string {
  return Number.isInteger(q) ? String(q) : String(Math.round(q * 1000) / 1000).replace('.', ',');
}
