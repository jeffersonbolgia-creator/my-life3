// Claves gratuitas que el dueño de la app pega una sola vez. Los usuarios no configuran nada.
// Si una clave está vacía, la pestaña correspondiente muestra "Próximamente" sin errores.
//
//  - TMDB (series y películas): cuenta gratis en themoviedb.org → Settings → API → "API Key" (la corta, 32 caracteres).
//    Uso no comercial, con atribución visible ("Datos de TMDB"), que la app ya muestra.
//  - RAWG (lanzamientos de juegos): cuenta gratis en rawg.io/apidocs → "Get API Key".

export const TMDB_API_KEY = '';
export const RAWG_API_KEY = '';

export const hasTmdb = () => TMDB_API_KEY.trim().length > 0;
export const hasRawg = () => RAWG_API_KEY.trim().length > 0;
