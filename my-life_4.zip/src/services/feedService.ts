// Trae lo nuevo de cada pestaña del Feed y lo guarda en el celular. Una fuente que falla
// devuelve lista vacía: nunca rompe la pantalla ni frena a las demás.
// Sólo se envía lo que se busca (un tema, una cuenta, un equipo); nunca datos del usuario.

import { feedRepo, feedSourcesRepo, profilesRepo, watchlistRepo, type FeedItemInput } from '../db/repos';
import { kindDef } from '../logic/feed';
import { newsFeedUrl, parseRss, splitSourceFromTitle, topicDef } from '../logic/discover';
import * as bsky from '../logic/sources/bluesky';
import * as yt from '../logic/sources/youtube';
import * as itunes from '../logic/sources/itunes';
import * as espn from '../logic/sources/espn';
import * as steam from '../logic/sources/steam';
import * as rawg from '../logic/sources/rawg';
import * as tmdb from '../logic/sources/tmdb';
import * as cg from '../logic/sources/coingecko';
import { RAWG_API_KEY, TMDB_API_KEY, hasRawg, hasTmdb } from './keys';
import { cachedJson, fetchJson, fetchText } from './http';
import { addDays, todayISO } from '../lib/dates';
import { notifyQuiet } from '../notifications/notifications';
import type { FeedKind, FeedSource, Profile } from '../types';

export interface KindResult { kind: FeedKind; ok: boolean; added: number; error?: string }
export interface FeedRefresh { results: KindResult[]; added: number; failed: FeedKind[] }

/** Bluesky: 403 a propósito por carga → se anota y no se insiste durante un rato. */
let bskySearchBlockedUntil = 0;

const PER_SOURCE = 12;

async function newsFor(profile: Profile): Promise<FeedItemInput[]> {
  const out: FeedItemInput[] = [];
  for (const topic of profile.settings.discover.topics) {
    const def = topicDef(topic);
    try {
      const items = parseRss(await fetchText(newsFeedUrl(def.query))).slice(0, PER_SOURCE);
      for (const it of items) {
        const { title, source } = splitSourceFromTitle(it.title, it.source);
        out.push({ kind: 'news', topic, externalId: `news:${it.link}`, title, text: it.summary, url: it.link, author: source, imageUrl: it.imageUrl, publishedAt: it.publishedAt, likes: null, extra: {} });
      }
    } catch {}
  }
  return out;
}

async function postsFor(profile: Profile, sources: FeedSource[]): Promise<FeedItemInput[]> {
  const out: FeedItemInput[] = [];
  for (const s of sources.filter((x) => x.kind === 'bluesky' && !x.muted)) {
    try {
      out.push(...bsky.parseAuthorFeed(await fetchJson(bsky.authorFeedUrl(s.externalId)), s.name).slice(0, PER_SOURCE));
    } catch {}
  }
  // Extra: búsqueda por tema. Si responde 403 (bloqueo por carga), se deja de intentar por 6 horas.
  if (Date.now() >= bskySearchBlockedUntil) {
    for (const topic of profile.settings.discover.topics.slice(0, 4)) {
      try {
        out.push(...bsky.parseSearchPosts(await fetchJson(bsky.searchPostsUrl(topicDef(topic).query)), topic).slice(0, 8));
      } catch (e: any) {
        if (/HTTP 4\d\d/.test(String(e?.message))) {
          bskySearchBlockedUntil = Date.now() + 6 * 3600_000;
          break;
        }
      }
    }
  }
  return out;
}

async function videosFor(sources: FeedSource[]): Promise<FeedItemInput[]> {
  const out: FeedItemInput[] = [];
  for (const s of sources.filter((x) => x.kind === 'youtube' && !x.muted)) {
    try {
      out.push(...yt.parseChannelFeed(await fetchText(yt.channelFeedUrl(s.externalId)), s.externalId, s.name).slice(0, PER_SOURCE));
    } catch {}
  }
  return out;
}

async function podcastsFor(sources: FeedSource[]): Promise<FeedItemInput[]> {
  const out: FeedItemInput[] = [];
  for (const s of sources.filter((x) => x.kind === 'podcast' && !x.muted)) {
    const feedUrl = typeof s.extra.feedUrl === 'string' ? s.extra.feedUrl : null;
    if (!feedUrl) continue;
    try {
      out.push(...itunes.parsePodcastRss(await fetchText(feedUrl, 15000), { id: s.externalId, name: s.name, image: s.imageUrl }).slice(0, 8));
    } catch {}
  }
  return out;
}

async function matchesFor(sources: FeedSource[]): Promise<FeedItemInput[]> {
  const out: FeedItemInput[] = [];
  const teams = sources.filter((x) => x.kind === 'team' && !x.muted);
  // Agrupar por liga: un pedido por liga, filtrando los equipos seguidos (o toda la liga si se sigue la liga entera)
  const byLeague = new Map<string, { all: boolean; teamIds: string[] }>();
  for (const t of teams) {
    const leagueId = typeof t.extra.leagueId === 'string' ? t.extra.leagueId : t.externalId;
    const cur = byLeague.get(leagueId) ?? { all: false, teamIds: [] };
    if (t.externalId === leagueId || t.extra.whole === true) cur.all = true;
    else cur.teamIds.push(t.externalId);
    byLeague.set(leagueId, cur);
  }
  const today = todayISO();
  for (const [leagueId, sel] of byLeague) {
    const league = espn.leagueDef(leagueId);
    if (!league) continue;
    try {
      // Sin encabezado User-Agent de navegador (ESPN devolvió 403 con uno copiado).
      const json = await fetchJson(espn.scoreboardUrl(leagueId, addDays(today, -3), addDays(today, 10)), 15000);
      out.push(...espn.parseScoreboard(json, league, sel.all ? null : sel.teamIds));
    } catch {}
  }
  return out;
}

async function gamesFor(profile: Profile, sources: FeedSource[]): Promise<FeedItemInput[]> {
  const out: FeedItemInput[] = [];
  const games = sources.filter((x) => x.kind === 'game' && !x.muted);
  const steamIds = games.filter((g) => g.externalId.startsWith('steam:')).map((g) => g.externalId.slice(6));
  if (steamIds.length) {
    try {
      const prices = steam.parseAppDetails(await fetchJson(steam.appDetailsUrl(steamIds), 15000));
      for (const p of prices) {
        const g = games.find((x) => x.externalId === `steam:${p.appId}`);
        if (g) out.push(steam.priceItem({ id: p.appId, name: g.name, image: g.imageUrl }, p));
      }
    } catch {}
  }
  // Ofertas destacadas de Steam (para que la pestaña tenga algo aunque no sigas juegos)
  try {
    const specials = steam.parseFeatured(await cachedJson(steam.featuredUrl(), 3 * 3600_000, 15000)) as any[];
    for (const sp of specials.slice(0, 8)) out.push({ ...steam.priceItem({ id: sp.appId, name: sp.name, image: sp.image }, sp), topic: 'Ofertas de Steam', externalId: `steam:${sp.appId}:featured` });
  } catch {}
  if (hasRawg()) {
    const today = todayISO();
    try {
      const upcoming = rawg.parseGames(await cachedJson(rawg.upcomingUrl(RAWG_API_KEY, today, addDays(today, 60)), 6 * 3600_000, 15000));
      for (const g of upcoming.slice(0, 10)) {
        const it = rawg.releaseItem(g, 'Lanzamientos');
        if (it) out.push(it);
      }
    } catch {}
    for (const g of games.filter((x) => x.externalId.startsWith('rawg:'))) {
      try {
        const det = rawg.parseGame(await cachedJson(rawg.gameUrl(RAWG_API_KEY, g.externalId.slice(5)), 12 * 3600_000, 15000));
        const it = rawg.releaseItem(det, g.name);
        if (it) out.push(it);
      } catch {}
    }
  }
  return out;
}

async function showsFor(profile: Profile, sources: FeedSource[]): Promise<FeedItemInput[]> {
  if (!hasTmdb()) return [];
  const out: FeedItemInput[] = [];
  const today = todayISO();
  for (const s of sources.filter((x) => x.kind === 'show' && !x.muted)) {
    const [, type, id] = s.externalId.split(':'); // "tmdb:tv:123"
    if ((type !== 'tv' && type !== 'movie') || !id) continue;
    try {
      const det = tmdb.parseDetail(await cachedJson(tmdb.detailUrl(TMDB_API_KEY, type, id), 6 * 3600_000, 15000), type);
      if (det) {
        out.push(...tmdb.showItems(det, today));
        // Mantener al día la lista de pendientes con la fecha del próximo episodio o estreno
        const w = await watchlistRepo.findByExternal(profile.id, `tmdb:${type}:${id}`).catch(() => null);
        const nextDate = det.nextEpisode?.date ?? (det.type === 'movie' && det.releaseDate && det.releaseDate >= today ? det.releaseDate : null);
        if (w && (w.nextDate ?? null) !== nextDate) await watchlistRepo.update(profile.id, w.id, { nextDate, imageUrl: w.imageUrl ?? det.image, genres: w.genres.length ? w.genres : det.genres }).catch(() => {});
      }
    } catch {}
  }
  try {
    out.push(...tmdb.listItems(await cachedJson(tmdb.upcomingMoviesUrl(TMDB_API_KEY), 12 * 3600_000, 15000), 'movie', 'Estrenos de cine'));
  } catch {}
  try {
    out.push(...tmdb.listItems(await cachedJson(tmdb.onTheAirUrl(TMDB_API_KEY), 12 * 3600_000, 15000), 'tv', 'Series en emisión').slice(0, 8));
  } catch {}
  return out;
}

async function musicFor(sources: FeedSource[]): Promise<FeedItemInput[]> {
  const out: FeedItemInput[] = [];
  for (const s of sources.filter((x) => x.kind === 'artist' && !x.muted)) {
    try {
      out.push(...itunes.parseArtistReleases(await fetchJson(itunes.artistReleasesUrl(s.externalId), 15000), { id: s.externalId, name: s.name }).slice(0, 6));
    } catch {}
  }
  return out;
}

async function cryptoFor(sources: FeedSource[]): Promise<FeedItemInput[]> {
  const coins = sources.filter((x) => x.kind === 'coin' && !x.muted).map((x) => x.externalId);
  const ids = coins.length ? coins : cg.DEFAULT_COINS.map((c) => c.id);
  try {
    // Una sola consulta (CoinGecko permite pocas por minuto); se comparte entre perfiles durante 10 minutos.
    return cg.parseMarkets(await cachedJson(cg.marketsUrl([...new Set(ids)].sort()), 10 * 60_000, 15000));
  } catch {
    return [];
  }
}

/** Qué pestañas tiene activas el perfil. */
export function activeKinds(profile: Profile): FeedKind[] {
  const tabs = profile.settings.feed.tabs;
  return (Object.keys(tabs) as FeedKind[]).filter((k) => tabs[k]);
}

async function refreshKind(profile: Profile, kind: FeedKind, sources: FeedSource[]): Promise<KindResult> {
  let items: FeedItemInput[] = [];
  try {
    switch (kind) {
      case 'news': items = await newsFor(profile); break;
      case 'post': items = await postsFor(profile, sources); break;
      case 'video': items = await videosFor(sources); break;
      case 'podcast': items = await podcastsFor(sources); break;
      case 'match': items = await matchesFor(sources); break;
      case 'game': items = await gamesFor(profile, sources); break;
      case 'show': items = await showsFor(profile, sources); break;
      case 'music': items = await musicFor(sources); break;
      case 'crypto': items = await cryptoFor(sources); break;
    }
  } catch (e: any) {
    return { kind, ok: false, added: 0, error: String(e?.message ?? e) };
  }
  lastAttempt.set(`${profile.id}:${kind}`, Date.now());
  if (!items.length) {
    // Sin nada que seguir no es un error: la pestaña queda vacía con su explicación.
    const def = kindDef(kind);
    const follows = def.source ? sources.some((s) => s.kind === def.source && !s.muted) : profile.settings.discover.topics.length > 0;
    return follows ? { kind, ok: false, added: 0, error: 'sin datos' } : { kind, ok: true, added: 0 };
  }
  const added = await feedRepo.addMany(profile.id, items);
  // Limpiar lo que ya no se sigue (cripto y deportes se reemplazan enteros para no acumular viejos)
  if (kind === 'crypto') await feedRepo.pruneTopics(profile.id, kind, items.map((i) => i.topic));
  await feedRepo.prune(profile.id, kind, kindDef(kind).keep);
  return { kind, ok: true, added };
}

/** Actualiza las pestañas activas (o sólo una). */
export async function refreshFeed(pid: number, only?: FeedKind): Promise<FeedRefresh> {
  const profile = await profilesRepo.get(pid);
  if (!profile) return { results: [], added: 0, failed: [] };
  const kinds = only ? [only] : activeKinds(profile);
  const sources = await feedSourcesRepo.list(pid);
  const results: KindResult[] = [];
  for (const k of kinds) results.push(await refreshKind(profile, k, sources));
  const added = results.reduce((a, r) => a + r.added, 0);
  if (!only) await notifyEpisodes(profile).catch(() => {});
  return { results, added, failed: results.filter((r) => !r.ok).map((r) => r.kind) };
}

const lastAttempt = new Map<string, number>();

/** ¿Pasaron más de `hours` horas desde la última actualización (o el último intento)? */
export async function isStale(pid: number, hours = 1, kind?: FeedKind): Promise<boolean> {
  const attempts = [...lastAttempt.entries()].filter(([k]) => k.startsWith(`${pid}:`) && (!kind || k.endsWith(`:${kind}`))).map(([, v]) => v);
  if (attempts.length && Date.now() - Math.max(...attempts) < hours * 3600_000) return false;
  const last = await feedRepo.lastFetch(pid, kind);
  if (!last) return true;
  const t = new Date(last.replace(' ', 'T')).getTime();
  return !Number.isFinite(t) || Date.now() - t > hours * 3600_000;
}

/** Aviso silencioso cuando sale hoy un episodio de una serie seguida (uno por día como máximo). */
const episodeNotifiedOn = new Map<number, string>();
async function notifyEpisodes(profile: Profile): Promise<void> {
  if (!profile.settings.notifications.enabled || !profile.settings.notifications.episodes) return;
  const today = todayISO();
  if (episodeNotifiedOn.get(profile.id) === today) return;
  const list = await watchlistRepo.list(profile.id);
  const todays = list.filter((w) => w.status !== 'done' && w.nextDate === today);
  if (!todays.length) return;
  episodeNotifiedOn.set(profile.id, today);
  const names = todays.map((w) => w.title);
  const body = names.length === 1 ? `Hoy sale ${names[0]}.` : `Hoy salen ${names.slice(0, 3).join(', ')}${names.length > 3 ? ' y más' : ''}.`;
  await notifyQuiet(profile.id, 'Episodio nuevo', body, 'Watchlist', `ep:${today}`);
}

// ---------- Búsquedas para seguir cosas ----------

export interface SearchHit { externalId: string; name: string; subtitle: string; image: string | null; extra?: Record<string, unknown> }

export async function searchBluesky(q: string): Promise<SearchHit[]> {
  const handle = bsky.normalizeHandle(q);
  let hits: SearchHit[] = [];
  try {
    hits = bsky.parseActors(await fetchJson(bsky.searchActorsUrl(q.replace(/^@/, '')))).map((a) => ({ externalId: a.handle, name: a.displayName, subtitle: `@${a.handle}${a.description ? ' · ' + a.description : ''}`, image: a.avatar }));
  } catch {}
  if (!hits.length && handle.includes('.')) hits.push({ externalId: handle, name: handle, subtitle: `@${handle}`, image: null });
  return hits;
}

export async function searchYouTube(q: string): Promise<SearchHit[]> {
  const input = yt.normalizeChannelInput(q);
  if (!input) return [];
  if (input.startsWith('UC')) return [{ externalId: input, name: q.trim(), subtitle: 'Canal de YouTube', image: null }];
  try {
    const html = await fetchText(yt.channelPageUrl(input), 15000);
    const id = yt.channelIdFromHtml(html);
    if (!id) return [];
    return [{ externalId: id, name: yt.channelNameFromHtml(html) ?? `@${input}`, subtitle: `@${input}`, image: null }];
  } catch {
    return [];
  }
}

export async function searchPodcasts(q: string): Promise<SearchHit[]> {
  try {
    return itunes.parsePodcastSearch(await fetchJson(itunes.searchPodcastsUrl(q))).map((p) => ({ externalId: p.id, name: p.name, subtitle: `${p.author}${p.genre ? ' · ' + p.genre : ''}`, image: p.image, extra: { feedUrl: p.feedUrl } }));
  } catch {
    return [];
  }
}

export async function searchArtists(q: string): Promise<SearchHit[]> {
  try {
    return itunes.parseArtistSearch(await fetchJson(itunes.searchArtistsUrl(q))).map((a) => ({ externalId: a.id, name: a.name, subtitle: a.genre || 'Artista', image: null }));
  } catch {
    return [];
  }
}

export async function searchTeams(leagueId: string): Promise<SearchHit[]> {
  const league = espn.leagueDef(leagueId);
  if (!league) return [];
  if (!league.teams) return [{ externalId: leagueId, name: league.label, subtitle: 'Toda la liga o cartelera', image: null, extra: { leagueId, whole: true } }];
  try {
    const teams = espn.parseTeams(await cachedJson(espn.teamsUrl(leagueId), 24 * 3600_000, 15000), leagueId);
    return [{ externalId: leagueId, name: `Toda la ${league.short}`, subtitle: 'Todos los partidos', image: null, extra: { leagueId, whole: true } }, ...teams.map((t) => ({ externalId: t.id, name: t.name, subtitle: league.short, image: t.logo, extra: { leagueId } }))];
  } catch {
    return [{ externalId: leagueId, name: `Toda la ${league.short}`, subtitle: 'Todos los partidos', image: null, extra: { leagueId, whole: true } }];
  }
}

export async function searchGames(q: string): Promise<SearchHit[]> {
  const out: SearchHit[] = [];
  try {
    out.push(...steam.parseStoreSearch(await fetchJson(steam.storeSearchUrl(q))).slice(0, 8).map((g) => ({ externalId: `steam:${g.id}`, name: g.name, subtitle: `Steam${g.priceText ? ' · ' + g.priceText : ''}`, image: g.image })));
  } catch {}
  if (hasRawg()) {
    try {
      out.push(...rawg.parseGames(await fetchJson(rawg.searchUrl(RAWG_API_KEY, q))).slice(0, 6).map((g) => ({ externalId: `rawg:${g.id}`, name: g.name, subtitle: `${g.released ? 'Sale ' + g.released.slice(8, 10) + '/' + g.released.slice(5, 7) + '/' + g.released.slice(0, 4) : 'Sin fecha'}${g.platforms.length ? ' · ' + g.platforms.slice(0, 2).join(', ') : ''}`, image: g.image, extra: { genres: g.genres, released: g.released } })));
    } catch {}
  }
  return out;
}

export async function searchShows(q: string): Promise<SearchHit[]> {
  if (!hasTmdb()) return [];
  try {
    return tmdb.parseSearch(await fetchJson(tmdb.searchUrl(TMDB_API_KEY, q))).slice(0, 10).map((h) => ({ externalId: `tmdb:${h.type}:${h.id}`, name: h.title, subtitle: `${h.type === 'tv' ? 'Serie' : 'Película'}${h.date ? ' · ' + h.date.slice(0, 4) : ''}${h.genres.length ? ' · ' + h.genres.slice(0, 2).join(', ') : ''}`, image: h.image, extra: { type: h.type, genres: h.genres, date: h.date } }));
  } catch {
    return [];
  }
}

export async function searchCoins(q: string): Promise<SearchHit[]> {
  try {
    return cg.parseSearch(await fetchJson(cg.searchUrl(q))).map((c) => ({ externalId: c.id, name: c.name, subtitle: `${c.symbol}${c.rank ? ' · #' + c.rank : ''}`, image: c.image }));
  } catch {
    return [];
  }
}
