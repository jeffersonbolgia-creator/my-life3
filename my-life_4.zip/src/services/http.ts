// Pedidos HTTP con tiempo límite. Nunca se envían datos del usuario: sólo lo que se busca.

export async function fetchJson(url: string, timeoutMs = 12000, headers: Record<string, string> = {}): Promise<unknown> {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(url, { signal: ctrl?.signal, headers: { Accept: 'application/json', ...headers } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function fetchText(url: string, timeoutMs = 12000, headers: Record<string, string> = {}): Promise<string> {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(url, { signal: ctrl?.signal, headers: { Accept: 'application/rss+xml, application/xml, text/xml, text/html, */*', ...headers } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    if (timer) clearTimeout(timer);
  }
}

/** Memoria corta por URL para no repetir pedidos iguales (p. ej. CoinGecko permite pocos por minuto). */
const cache = new Map<string, { at: number; value: unknown }>();
export async function cachedJson(url: string, ttlMs: number, timeoutMs = 12000): Promise<unknown> {
  const hit = cache.get(url);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value;
  const value = await fetchJson(url, timeoutMs);
  cache.set(url, { at: Date.now(), value });
  return value;
}
