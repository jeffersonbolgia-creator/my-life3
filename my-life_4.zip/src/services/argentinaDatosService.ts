// Inflación mensual y feriados (ArgentinaDatos, sin clave). Se guardan en el celular, compartidos entre perfiles.

import { holidaysRepo, inflationRepo } from '../db/repos';
import { holidaysUrl, inflationUrl, parseHolidays, parseInflation } from '../logic/sources/argentinadatos';
import { fetchJson } from './http';

let inflationAt = 0;
let holidaysAt = 0;

/** Trae la inflación (una vez por día como máximo). Devuelve si hay datos. */
export async function refreshInflation(force = false): Promise<boolean> {
  if (!force && Date.now() - inflationAt < 12 * 3600_000 && (await inflationRepo.count()) > 0) return true;
  try {
    const rows = parseInflation(await fetchJson(inflationUrl(), 15000));
    if (rows.length) {
      await inflationRepo.upsertMany(rows);
      inflationAt = Date.now();
      return true;
    }
  } catch {}
  return (await inflationRepo.count()) > 0;
}

/** Trae los feriados del año actual y el siguiente (una vez por semana como máximo). */
export async function refreshHolidays(force = false, now: Date = new Date()): Promise<boolean> {
  const year = now.getFullYear();
  const have = (await holidaysRepo.countYear(year)) > 0;
  if (!force && have && Date.now() - holidaysAt < 7 * 86400_000) return true;
  let ok = false;
  for (const y of [year, year + 1]) {
    try {
      const rows = parseHolidays(await fetchJson(holidaysUrl(y), 15000));
      if (rows.length) {
        await holidaysRepo.upsertMany(rows);
        ok = true;
      }
    } catch {}
  }
  if (ok) holidaysAt = Date.now();
  return ok || have;
}
