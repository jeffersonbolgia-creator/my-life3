// Exportar e importar archivos (copias de seguridad y CSV).
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
import { Platform } from 'react-native';
import { exportProfile, restoreProfile, transactionsToCsv, validateBackup } from '../db/backup';
import type { Transaction } from '../types';
import { todayISO } from '../lib/dates';
import { normalizeText } from '../lib/text';

async function writeTemp(name: string, content: string): Promise<string> {
  const uri = `${FileSystem.cacheDirectory}${name}`;
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  return uri;
}

async function share(uri: string, mimeType: string, title: string): Promise<boolean> {
  if (!(await Sharing.isAvailableAsync())) return false;
  await Sharing.shareAsync(uri, { mimeType, dialogTitle: title, UTI: mimeType === 'application/json' ? 'public.json' : 'public.comma-separated-values-text' });
  return true;
}

/** Guarda un archivo en una carpeta que elija el usuario (Android). */
async function saveToFolder(fileName: string, content: string, mime: string): Promise<'saved' | 'cancelled'> {
  const SAF = FileSystem.StorageAccessFramework;
  const perm = await SAF.requestDirectoryPermissionsAsync();
  if (!perm.granted) return 'cancelled';
  const base = fileName.replace(/\.[^.]+$/, '');
  const uri = await SAF.createFileAsync(perm.directoryUri, base, mime);
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  return 'saved';
}

export function backupFileName(profileName: string): string {
  const slug = normalizeText(profileName).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  return `mylife-${slug || 'perfil'}-${todayISO()}.json`;
}

export async function backupAndShare(pid: number, profileName: string): Promise<boolean> {
  const data = await exportProfile(pid);
  const uri = await writeTemp(backupFileName(profileName), JSON.stringify(data));
  return share(uri, 'application/json', 'Guardar copia de MY LIFE');
}

export async function backupToFolder(pid: number, profileName: string): Promise<'saved' | 'cancelled' | 'unsupported'> {
  if (Platform.OS !== 'android') return 'unsupported';
  const data = await exportProfile(pid);
  return saveToFolder(backupFileName(profileName), JSON.stringify(data, null, 1), 'application/json');
}

export async function exportFinanceCsv(txs: Transaction[], name: string): Promise<boolean> {
  const uri = await writeTemp(`${name}.csv`, transactionsToCsv(txs));
  return share(uri, 'text/csv', 'Exportar movimientos');
}

export async function pickAndRestore(pid: number, restoreSettings: boolean): Promise<{ total: number } | null> {
  const res = await DocumentPicker.getDocumentAsync({ type: ['application/json', 'text/plain', '*/*'], copyToCacheDirectory: true, multiple: false });
  if (res.canceled || !res.assets?.length) return null;
  const text = await FileSystem.readAsStringAsync(res.assets[0].uri, { encoding: FileSystem.EncodingType.UTF8 });
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('El archivo elegido no es una copia de MY LIFE.');
  }
  if (!validateBackup(data)) throw new Error('El archivo elegido no es una copia de MY LIFE o es de una versión más nueva.');
  return restoreProfile(pid, data, { restoreSettings });
}
