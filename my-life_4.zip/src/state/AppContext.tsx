import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, useColorScheme } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import type { Profile, ProfileSettings } from '../types';
import { profilesRepo } from '../db/repos';
import { buildTheme, type Theme } from '../theme/theme';
import { scheduleSync } from '../notifications/notifications';

const LAST_KEY = 'mylife_last_profile';

interface AppCtx {
  profiles: Profile[];
  profile: Profile | null;
  /** Último perfil activo (se mantiene durante la animación de salida al bloquear). */
  sessionProfile: Profile | null;
  lastProfileId: number | null;
  dataVersion: number;
  theme: Theme;
  refreshProfiles: () => Promise<Profile[]>;
  unlock: (pid: number) => Promise<void>;
  lock: () => void;
  updateSettings: (patch: Partial<ProfileSettings>) => Promise<void>;
  updateProfile: (patch: Partial<Omit<Profile, 'id' | 'createdAt'>>) => Promise<void>;
  bump: () => void;
  suspendAutoLock: (ms?: number) => void;
}

const Ctx = createContext<AppCtx | null>(null);

export function useApp(): AppCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp fuera de AppProvider');
  return v;
}

export function useTheme(): Theme {
  return useApp().theme;
}

/** Perfil activo (sólo se usa en pantallas protegidas). */
export function useProfile(): Profile {
  const { profile, sessionProfile } = useApp();
  const p = profile ?? sessionProfile;
  if (!p) throw new Error('No hay sesión activa');
  return p;
}

export function AppProvider({ initialProfiles, children }: { initialProfiles: Profile[]; children: React.ReactNode }) {
  const [profiles, setProfiles] = useState<Profile[]>(initialProfiles);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [lastProfileId, setLastProfileId] = useState<number | null>(null);
  const [dataVersion, setDataVersion] = useState(0);
  const system = useColorScheme();
  const bgAt = useRef<number | null>(null);
  const suspendedUntil = useRef(0);
  const profileRef = useRef<Profile | null>(null);
  profileRef.current = profile;
  const sessionRef = useRef<Profile | null>(null);
  if (profile) sessionRef.current = profile;

  useEffect(() => {
    SecureStore.getItemAsync(LAST_KEY)
      .then((v) => {
        const n = v ? Number(v) : NaN;
        if (Number.isFinite(n)) setLastProfileId(n);
      })
      .catch(() => {});
  }, []);

  const refreshProfiles = useCallback(async () => {
    const list = await profilesRepo.list();
    setProfiles(list);
    const cur = profileRef.current;
    if (cur) setProfile(list.find((p) => p.id === cur.id) ?? null);
    return list;
  }, []);

  const unlock = useCallback(async (pid: number) => {
    const p = await profilesRepo.get(pid);
    if (!p) return;
    setProfile(p);
    setLastProfileId(pid);
    SecureStore.setItemAsync(LAST_KEY, String(pid)).catch(() => {});
    profilesRepo.touch(pid).catch(() => {});
    scheduleSync(pid, 2500);
  }, []);

  const lock = useCallback(() => {
    setProfile(null);
  }, []);

  const updateSettings = useCallback(async (patch: Partial<ProfileSettings>) => {
    const cur = profileRef.current;
    if (!cur) return;
    const settings = await profilesRepo.updateSettings(cur.id, patch);
    if (settings) {
      const next = { ...cur, settings };
      setProfile(next);
      setProfiles((ps) => ps.map((p) => (p.id === cur.id ? next : p)));
      if (patch.notifications) scheduleSync(cur.id);
    }
  }, []);

  const updateProfile = useCallback(async (patch: Partial<Omit<Profile, 'id' | 'createdAt'>>) => {
    const cur = profileRef.current;
    if (!cur) return;
    await profilesRepo.update(cur.id, patch);
    const fresh = await profilesRepo.get(cur.id);
    if (fresh) {
      setProfile(fresh);
      setProfiles((ps) => ps.map((p) => (p.id === cur.id ? fresh : p)));
    }
  }, []);

  const bump = useCallback(() => {
    setDataVersion((v) => v + 1);
    const cur = profileRef.current;
    if (cur) scheduleSync(cur.id);
  }, []);

  const suspendAutoLock = useCallback((ms = 120_000) => {
    suspendedUntil.current = Date.now() + ms;
  }, []);

  // Bloqueo automático al volver a la app
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      const cur = profileRef.current;
      if (state === 'background') {
        bgAt.current = Date.now();
        return;
      }
      if (state === 'active') {
        const since = bgAt.current;
        bgAt.current = null;
        if (!cur || since == null) return;
        if (Date.now() < suspendedUntil.current) {
          suspendedUntil.current = 0;
          return;
        }
        const mins = cur.settings.autoLockMinutes;
        if (mins < 0) return;
        if (Date.now() - since >= mins * 60_000) setProfile(null);
        else setDataVersion((v) => v + 1); // refresca datos (ej. cambio de día)
      }
    });
    return () => sub.remove();
  }, []);

  const theme = useMemo(() => {
    if (!profile) return buildTheme(true, 'violet', true, false);
    const s = profile.settings;
    const dark = s.themeMode === 'system' ? system !== 'light' : s.themeMode === 'dark';
    return buildTheme(dark, s.accent, { gradients: s.gradients, compact: s.compact, fontScale: s.fontScale, radiusStyle: s.radiusStyle, glow: s.glow, bgStyle: s.bgStyle });
  }, [profile, system]);

  const value = useMemo<AppCtx>(
    () => ({ profiles, profile, sessionProfile: sessionRef.current, lastProfileId, dataVersion, theme, refreshProfiles, unlock, lock, updateSettings, updateProfile, bump, suspendAutoLock }),
    [profiles, profile, lastProfileId, dataVersion, theme, refreshProfiles, unlock, lock, updateSettings, updateProfile, bump, suspendAutoLock],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
