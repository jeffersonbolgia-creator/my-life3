// El "cerebro" del amigo: toma una intención y arma la respuesta con los datos reales del perfil.
// Queda detrás de `respond()` para poder cambiar el motor más adelante sin tocar la pantalla.

import type { Intent, Period } from './intents';
import { parseIntent, guessCategory } from './intents';
import type { AssistantPersonality, CalendarEvent, Countdown, DollarRate, FeedItem, Goal, Habit, Holiday, InflationRate, Profile, Reminder, Routine, RoutineLog, Salary, Subscription, Task, Transaction, WatchItem } from '../types';
import {
  countdownsRepo, dollarRepo, eventsRepo, feedRepo, financeRepo, goalsRepo, habitsRepo, holidaysRepo, inflationRepo, remindersRepo, routinesRepo, salariesRepo, subscriptionsRepo, tasksRepo, notesRepo, watchlistRepo,
} from '../db/repos';
import { feedSummary } from '../logic/feed';
import { parseWatchQuery, suggest, suggestionText } from '../logic/watchlist';
import { buildSalaryRows, monthLabel, salaryVerdict } from '../logic/salary';
import { daysUntil, nextHoliday, nextLongWeekend } from '../logic/holidays';
import { addDays, formatRelativeDay, monthKey, startOfWeek, todayISO, addMonthsToKey } from '../lib/dates';
import { formatMoney } from '../lib/money';
import { availableBalance, categoryBreakdown } from '../logic/finance';
import { currentStreak, isScheduledOn } from '../logic/habits';
import { occurrencesInRange } from '../logic/calendar';
import { CASA_LABELS, formatRate, freshness, variation } from '../logic/dollar';
import { daysLabel as cdDaysLabel, daysLeft, sortCountdowns } from '../logic/countdown';
import { daysLabel as subDaysLabel, sortByNext } from '../logic/subscriptions';
import { currentStep, routineProgress, routinesForDay, routineStreak } from '../logic/routines';
import { normalizeText, firstName } from '../lib/text';

export interface AssistantData {
  profile: Profile;
  tasks: Task[];
  events: CalendarEvent[];
  habits: Habit[];
  habitLogs: Map<number, Set<string>>;
  goals: Goal[];
  txs: Transaction[];
  reminders: Reminder[];
  countdowns: Countdown[];
  routines: Routine[];
  routineLogs: Map<number, Map<string, RoutineLog>>;
  subscriptions: Subscription[];
  rates: DollarRate[];
  notesCount: number;
  feed: FeedItem[];
  watchlist: WatchItem[];
  salaries: Salary[];
  inflation: InflationRate[];
  holidays: Holiday[];
}

export async function loadAssistantData(profile: Profile): Promise<AssistantData> {
  const pid = profile.id;
  const today = todayISO();
  const [tasks, events, habits, habitLogs, goals, txs, reminders, countdowns, routines, routineLogs, subscriptions, rates, notes, feed, watchlist, salaries, inflation, holidays, rateHist] = await Promise.all([
    tasksRepo.list(pid), eventsRepo.list(pid), habitsRepo.list(pid), habitsRepo.logs(pid), goalsRepo.list(pid), financeRepo.list(pid), remindersRepo.list(pid),
    countdownsRepo.list(pid), routinesRepo.list(pid), routinesRepo.logs(pid), subscriptionsRepo.list(pid, false), dollarRepo.latest(), notesRepo.list(pid),
    feedRepo.list(pid, { limit: 150 }), watchlistRepo.list(pid), salariesRepo.list(pid), inflationRepo.list(), holidaysRepo.list(today, addDays(today, 400)),
    dollarRepo.series(profile.settings.dollarCasa, addDays(today, -400), today),
  ]);
  return { profile, tasks, events, habits, habitLogs, goals, txs, reminders, countdowns, routines, routineLogs, subscriptions, rates: [...rateHist, ...rates], notesCount: notes.length, feed, watchlist, salaries, inflation, holidays };
}

/** Lo que la pantalla muestra además del texto. */
export type ReplyPayload =
  | { kind: 'confirm'; action: 'add_expense' | 'add_income' | 'add_task' | 'add_reminder' | 'add_note'; data: Record<string, unknown>; status: 'pending' | 'done' | 'cancelled' }
  | { kind: 'bars'; items: { label: string; value: number; display: string; color?: string }[] }
  | { kind: 'chips'; items: string[] }
  | { kind: 'settings'; name?: string; personality?: AssistantPersonality; clear?: boolean };

export interface Reply {
  text: string;
  payload?: ReplyPayload;
}

function periodRange(p: Period, today: string): { from: string; to: string; label: string } {
  if (p === 'today') return { from: today, to: today, label: 'hoy' };
  if (p === 'yesterday') { const y = addDays(today, -1); return { from: y, to: y, label: 'ayer' }; }
  if (p === 'week') return { from: startOfWeek(today), to: today, label: 'esta semana' };
  if (p === 'lastMonth') { const k = addMonthsToKey(monthKey(today), -1); return { from: k + '-01', to: addDays(monthKey(today) + '-01', -1), label: 'el mes pasado' }; }
  return { from: monthKey(today) + '-01', to: today, label: 'este mes' };
}

const pick = <T,>(arr: T[], seed: number): T => arr[Math.abs(seed) % arr.length];

/** Tono según la personalidad elegida. */
function tone(p: AssistantPersonality, name: string, seed: number) {
  const fn = firstName(name);
  return {
    hi: p === 'direct' ? `Hola, ${fn}.` : p === 'fun' ? pick([`¡Ey, ${fn}!`, `¡Buenas, ${fn}!`, `¡${fn}! Acá estoy.`], seed) : pick([`Hola, ${fn}.`, `¡Hola, ${fn}! Qué bueno verte.`], seed),
    ok: p === 'direct' ? 'Listo.' : p === 'fun' ? pick(['¡Hecho!', '¡Listo el pollo!', '¡Anotadísimo!'], seed) : pick(['Listo, quedó guardado.', 'Perfecto, ya está.'], seed),
    empty: p === 'direct' ? 'No tengo registros de eso.' : p === 'fun' ? 'Mmm, de eso no tengo nada anotado todavía.' : 'Todavía no tengo nada anotado sobre eso.',
    cheer: p === 'direct' ? '' : p === 'fun' ? pick([' ¡Vamos que se puede!', ' ¡A full!', ' ¡Seguí así!'], seed) : pick([' Vas muy bien.', ' Seguí así.', ' Buen ritmo.'], seed),
  };
}

const money = (c: number) => formatMoney(c);

function spendingReply(d: AssistantData, p: Period, category: string | null, today: string, t: ReturnType<typeof tone>): Reply {
  const r = periodRange(p, today);
  const inRange = d.txs.filter((x) => x.date >= r.from && x.date <= r.to && x.kind === 'expense');
  const filtered = category ? inRange.filter((x) => normalizeText(x.category) === normalizeText(category)) : inRange;
  const total = filtered.reduce((a, x) => a + x.amount, 0);
  if (!filtered.length) return { text: category ? `No tenés gastos en ${category} ${r.label}.` : `No tenés gastos anotados ${r.label}.` };
  if (category) {
    const top = filtered.slice(0, 3).map((x) => `${x.name} (${money(x.amount)})`).join(', ');
    return { text: `${r.label === 'hoy' ? 'Hoy' : r.label.charAt(0).toUpperCase() + r.label.slice(1)} gastaste ${money(total)} en ${category}: ${top}${filtered.length > 3 ? ' y más' : ''}.` };
  }
  const cats = categoryBreakdown(filtered, null).slice(0, 5);
  // Comparación con el período anterior
  let cmp = '';
  if (p === 'week' || p === 'month') {
    const prevFrom = p === 'week' ? addDays(r.from, -7) : addMonthsToKey(monthKey(today), -1) + '-01';
    const prevTo = p === 'week' ? addDays(r.from, -1) : addDays(r.from, -1);
    const prev = d.txs.filter((x) => x.date >= prevFrom && x.date <= prevTo && x.kind === 'expense').reduce((a, x) => a + x.amount, 0);
    if (prev > 0) {
      const diff = total - prev;
      cmp = diff > 0 ? ` Es ${money(diff)} más que ${p === 'week' ? 'la semana pasada' : 'el mes pasado a esta altura'}.` : diff < 0 ? ` Es ${money(-diff)} menos que ${p === 'week' ? 'la semana pasada' : 'el mes pasado'}.` : '';
    }
  }
  const lead = cats[0] ? ` Lo que más pesó: ${cats[0].category} (${cats[0].percent}%).` : '';
  return {
    text: `${r.label.charAt(0).toUpperCase() + r.label.slice(1)} gastaste ${money(total)} en ${filtered.length} ${filtered.length === 1 ? 'movimiento' : 'movimientos'}.${lead}${cmp}`,
    payload: { kind: 'bars', items: cats.map((c) => ({ label: c.category, value: c.total, display: money(c.total) })) },
  };
}

function summaryReply(d: AssistantData, p: Period, today: string, t: ReturnType<typeof tone>): Reply {
  const r = periodRange(p, today);
  const doneTasks = d.tasks.filter((x) => x.completedAt && x.completedAt.slice(0, 10) >= r.from && x.completedAt.slice(0, 10) <= r.to);
  const habitsDone = d.habits.reduce((n, h) => { const logs = d.habitLogs.get(h.id); if (!logs) return n; let c = 0; for (const dt of logs) if (dt >= r.from && dt <= r.to) c++; return n + c; }, 0);
  const spent = d.txs.filter((x) => x.kind === 'expense' && x.date >= r.from && x.date <= r.to).reduce((a, x) => a + x.amount, 0);
  const routinesDone = d.routines.reduce((n, rt) => { const logs = d.routineLogs.get(rt.id); if (!logs) return n; let c = 0; for (const [dt, l] of logs) if (dt >= r.from && dt <= r.to && l.completed) c++; return n + c; }, 0);
  const parts: string[] = [];
  if (doneTasks.length) parts.push(`completaste ${doneTasks.length} ${doneTasks.length === 1 ? 'tarea' : 'tareas'}${doneTasks.length <= 3 ? ` (${doneTasks.map((x) => x.title).join(', ')})` : ''}`);
  if (habitsDone) parts.push(`cumpliste ${habitsDone} ${habitsDone === 1 ? 'hábito' : 'hábitos'}`);
  if (routinesDone) parts.push(`terminaste ${routinesDone} ${routinesDone === 1 ? 'rutina' : 'rutinas'}`);
  if (spent) parts.push(`gastaste ${money(spent)}`);
  if (!parts.length) return { text: p === 'today' ? 'Todavía no anotaste nada hoy. ¿Arrancamos con algo?' : `No hay registros ${r.label}.` };
  const pendingToday = d.tasks.filter((x) => !x.completedAt && x.dueDate && x.dueDate <= today).length;
  const tail = p === 'today' && pendingToday ? ` Te quedan ${pendingToday} ${pendingToday === 1 ? 'tarea pendiente' : 'tareas pendientes'}.` : t.cheer;
  return { text: `${r.label.charAt(0).toUpperCase() + r.label.slice(1)} ${parts.join(', ')}.${tail}` };
}

function pendingReply(d: AssistantData, date: string, label: string, today: string): Reply {
  const tasks = d.tasks.filter((x) => !x.completedAt && x.dueDate && (date === today ? x.dueDate <= date : x.dueDate === date));
  const events = occurrencesInRange(d.events, date, date);
  const reminders = d.reminders.filter((x) => !x.done && (x.date === date || (x.repeat === 'daily') || (x.repeat === 'weekly' && new Date(x.date.replace(/-/g, '/')).getDay() === new Date(date.replace(/-/g, '/')).getDay())));
  const subs = d.subscriptions.filter((s) => s.active && s.nextDate === date);
  const cds = d.countdowns.filter((c) => c.date === date);
  const lines: string[] = [];
  for (const e of events) lines.push(`${e.event.allDay || !e.event.startTime ? '' : e.event.startTime + ' · '}${e.event.type === 'birthday' ? 'Cumpleaños de ' : ''}${e.event.title}`);
  for (const x of tasks) lines.push(`${x.dueTime ? x.dueTime + ' · ' : ''}${x.title}${x.dueDate! < today ? ' (atrasada)' : ''}`);
  for (const x of reminders) lines.push(`${x.time} · ${x.title}`);
  for (const s of subs) lines.push(`Se cobra ${s.name}`);
  for (const c of cds) lines.push(`¡Es el día de ${c.title}!`);
  const when = label || formatRelativeDay(date).toLowerCase();
  if (!lines.length) return { text: `No tenés nada pendiente para ${when}. ${date === today ? '¿Querés que te anote algo?' : ''}`.trim() };
  return { text: `Para ${when} tenés ${lines.length} ${lines.length === 1 ? 'cosa' : 'cosas'}:\n• ${lines.slice(0, 8).join('\n• ')}${lines.length > 8 ? `\n…y ${lines.length - 8} más.` : ''}` };
}

function goalsReply(d: AssistantData, t: ReturnType<typeof tone>): Reply {
  const active = d.goals.filter((g) => !g.completedAt);
  if (!active.length) return { text: d.goals.length ? `No tenés objetivos en curso. Alcanzaste ${d.goals.length}. ${t.cheer}`.trim() : 'Todavía no definiste objetivos. Cuando quieras los armamos en Más → Objetivos.' };
  const items = active.slice(0, 6).map((g) => ({ label: g.title, value: g.progress, display: g.savingTarget ? `${g.progress}% · ${g.savingCurrency === 'USD' ? `US$ ${(g.savingSaved / 100).toFixed(0)}` : money(g.savingSaved)}` : `${g.progress}%` }));
  const avg = Math.round(active.reduce((a, g) => a + g.progress, 0) / active.length);
  const best = [...active].sort((a, b) => b.progress - a.progress)[0];
  return { text: `Tenés ${active.length} ${active.length === 1 ? 'objetivo' : 'objetivos'} en curso, con un avance promedio del ${avg}%. El que mejor va es "${best.title}" (${best.progress}%).${t.cheer}`, payload: { kind: 'bars', items } };
}

function habitsReply(d: AssistantData, today: string, t: ReturnType<typeof tone>): Reply {
  if (!d.habits.length) return { text: 'No tenés hábitos cargados. Los podés crear en Más → Hábitos.' };
  const rows = d.habits.map((h) => ({ h, streak: currentStreak(h, d.habitLogs.get(h.id) ?? new Set(), today), today: isScheduledOn(h, today) || h.frequency === 'weekly', done: !!d.habitLogs.get(h.id)?.has(today) }));
  const todays = rows.filter((r) => r.today);
  const done = todays.filter((r) => r.done).length;
  const best = [...rows].sort((a, b) => b.streak - a.streak)[0];
  const pend = todays.filter((r) => !r.done).map((r) => r.h.title);
  return {
    text: `Hoy llevás ${done} de ${todays.length} hábitos.${pend.length ? ` Te falta: ${pend.join(', ')}.` : ' ¡Todos hechos!'}${best.streak ? ` Tu mejor racha es ${best.h.title}: ${best.streak} ${best.streak === 1 ? 'día' : 'días'} seguidos.` : ''}${t.cheer}`,
    payload: { kind: 'bars', items: rows.slice(0, 6).map((r) => ({ label: r.h.title, value: r.streak, display: `${r.streak} d`, color: r.h.color })) },
  };
}

function dollarReply(d: AssistantData, casa: string | null): Reply {
  if (!d.profile.settings.modules.dollar) return { text: 'El módulo "Dólar hoy" está apagado. Lo activás en Más → Módulos y te cuento la cotización.' };
  const c = (casa ?? d.profile.settings.dollarCasa) as keyof typeof CASA_LABELS;
  const r = [...d.rates].filter((x) => x.casa === c).sort((a, b) => b.date.localeCompare(a.date))[0];
  if (!r) return { text: 'Todavía no tengo cotizaciones guardadas. Abrí "Dólar hoy" con internet y después me preguntás.' };
  const v = variation(d.rates, c);
  const latestOf = (casa: string) => [...d.rates].filter((x) => x.casa === casa).sort((a, b) => b.date.localeCompare(a.date))[0];
  const others = ['blue', 'oficial', 'bolsa'].filter((x) => x !== c).map((x) => latestOf(x)).filter(Boolean).map((x) => `${CASA_LABELS[x.casa].short} ${formatRate(x.sell, x.casa)}`).join(' · ');
  return { text: `${CASA_LABELS[c].long}: ${formatRate(r.sell, c)} para la venta (compra ${formatRate(r.buy, c)}), actualizado ${freshness(r.updatedAt)}.${v ? ` ${v.abs >= 0 ? 'Subió' : 'Bajó'} ${formatRate(Math.abs(v.abs), c)} desde el último dato.` : ''}${others ? `\n${others}` : ''}` };
}

function subsReply(d: AssistantData, name: string | null, usd: number | null): Reply {
  if (!d.profile.settings.modules.subscriptions) return { text: 'El módulo "Suscripciones" está apagado. Lo activás en Más → Módulos.' };
  const list = sortByNext(d.subscriptions.filter((s) => s.active));
  if (!list.length) return { text: 'No tenés suscripciones cargadas. Las agregás en Más → Suscripciones.' };
  if (name) {
    const n = normalizeText(name);
    const s = list.find((x) => normalizeText(x.name).includes(n) || n.includes(normalizeText(x.name)));
    if (s) return { text: `${s.name}: ${subDaysLabel(s).toLowerCase()} (${formatRelativeDay(s.nextDate)}). Son ${s.currency === 'USD' ? `US$ ${(s.amount / 100).toFixed(0)}` : money(s.amount)}.` };
  }
  const total = list.reduce((a, s) => a + (s.currency === 'USD' ? (usd ? Math.round(s.amount * usd) : 0) : s.amount), 0);
  const next = list[0];
  return {
    text: `Tenés ${list.length} ${list.length === 1 ? 'suscripción activa' : 'suscripciones activas'}${total ? `, unos ${money(total)} por mes` : ''}. La próxima es ${next.name}: ${subDaysLabel(next).toLowerCase()}.`,
    payload: { kind: 'bars', items: list.slice(0, 6).map((s) => ({ label: s.name, value: Math.max(1, 60 - daysLeftSub(s)), display: subDaysLabel(s).replace('Faltan ', ''), color: s.color })) },
  };
}
const daysLeftSub = (s: Subscription) => Math.max(0, Math.round((new Date(s.nextDate.replace(/-/g, '/')).getTime() - Date.now()) / 86400000));

function countdownReply(d: AssistantData, name: string | null): Reply {
  if (!d.countdowns.length) return { text: 'No tenés cuentas regresivas. Creá una en Más → Cuenta regresiva y te digo cuánto falta.' };
  const list = sortCountdowns(d.countdowns);
  if (name) {
    const n = normalizeText(name);
    const c = list.find((x) => normalizeText(x.title).includes(n) || n.includes(normalizeText(x.title)));
    if (c) return { text: `${c.title}: ${cdDaysLabel(c).toLowerCase()} (${formatRelativeDay(c.date).toLowerCase()}).` };
  }
  const up = list.filter((c) => daysLeft(c) >= 0).slice(0, 4);
  if (!up.length) return { text: 'Todas tus cuentas regresivas ya pasaron.' };
  return { text: `${up.map((c) => `${c.title}: ${cdDaysLabel(c).toLowerCase()}`).join('\n')}` };
}

function routineReply(d: AssistantData, today: string): Reply {
  const todays = routinesForDay(d.routines, today);
  if (!todays.length) return { text: d.routines.length ? 'No tenés rutinas programadas para hoy.' : 'No tenés rutinas. Armá una en Más → Rutinas.' };
  const lines = todays.map((r) => {
    const log = d.routineLogs.get(r.id)?.get(today);
    const p = routineProgress(r, log);
    const next = currentStep(r, log);
    const streak = routineStreak(r, d.routineLogs.get(r.id), today);
    return `${r.title}: ${p.done}/${p.total}${next ? ` · sigue "${next.title}"` : ' · completa'}${streak ? ` · ${streak} días seguidos` : ''}`;
  });
  return { text: lines.join('\n') };
}

function balanceReply(d: AssistantData, today: string): Reply {
  const s = d.profile.settings;
  const bal = availableBalance(d.txs, s.initialBalance, s.initialBalanceDate);
  const m = monthKey(today);
  const spent = d.txs.filter((x) => x.kind === 'expense' && monthKey(x.date) === m).reduce((a, x) => a + x.amount, 0);
  return { text: `Tu saldo disponible es ${money(bal)}. Este mes llevás gastados ${money(spent)}.${bal < 0 ? ' Ojo: estás en negativo.' : ''}` };
}

function feedReply(d: AssistantData, now: Date): Reply {
  if (!d.profile.settings.modules.feed) return { text: 'El Feed está apagado. Lo activás en Más → Módulos y te cuento las novedades de tus temas.' };
  const sum = feedSummary(d.feed, d.profile.settings.discover.weights, { name: d.profile.settings.assistant.name, spoilerFree: d.profile.settings.feed.spoilerFree, now });
  if (!sum) return { text: d.feed.length ? 'No hay nada nuevo en tu Feed en las últimas 24 horas. Abrilo y deslizá hacia abajo para actualizar.' : 'Tu Feed todavía está vacío. Elegí temas, cuentas o equipos en Más → Feed y después te resumo lo nuevo.' };
  return { text: sum.text.replace(/^(Buen día|Buenas|Buenas noches)\. /, '') + ' Lo tenés todo en el Feed.' };
}

function watchReply(d: AssistantData, query: string): Reply {
  if (!d.profile.settings.modules.watchlist) return { text: 'Para recomendarte necesito tu lista de pendientes. Activá "Pendientes" en Más → Módulos y cargá lo que querés ver o jugar.' };
  const q = parseWatchQuery(query);
  const s = suggest(d.watchlist, q, d.profile.settings.discover.topics);
  return { text: suggestionText(s, q), payload: s.length ? { kind: 'chips', items: ['Algo corto', 'Algo de acción', 'Una comedia', 'Un juego'] } : undefined };
}

function salaryReply(d: AssistantData): Reply {
  if (!d.profile.settings.modules.salary) return { text: 'El módulo "Sueldo e inflación" está apagado. Lo activás en Más → Módulos.' };
  const rows = buildSalaryRows(d.salaries, d.rates, d.inflation);
  if (!rows.length) return { text: 'Todavía no cargaste ningún sueldo. Lo hacés en Más → Sueldo e inflación, un número por mes.' };
  const last = rows[rows.length - 1];
  const infl = d.inflation[d.inflation.length - 1];
  const parts = [`Tu sueldo de ${monthLabel(last.month)} es ${money(last.amount)}${last.usd != null ? `, unos US$ ${last.usd.toFixed(0)}` : ''}.`];
  const v = salaryVerdict(rows);
  if (v) parts.push(v);
  if (infl) parts.push(`La última inflación mensual publicada es ${String(infl.value).replace('.', ',')}% (${monthLabel(infl.month)}).`);
  return { text: parts.join(' '), payload: rows.length > 1 ? { kind: 'bars', items: rows.slice(-6).map((r) => ({ label: monthLabel(r.month), value: r.usd ?? 0, display: r.usd != null ? `US$ ${r.usd.toFixed(0)}` : '—' })) } : undefined };
}

function holidayReply(d: AssistantData, today: string): Reply {
  const next = nextHoliday(d.holidays, today);
  if (!next) return { text: d.profile.settings.modules.holidays ? 'No tengo feriados cargados todavía. Abrí Más → Feriados con internet.' : 'Activá "Feriados" en Más → Módulos y te digo cuánto falta para el próximo.' };
  const n = daysUntil(next.date, today);
  const lw = nextLongWeekend(d.holidays, today);
  const first = n === 0 ? `¡Hoy es feriado: ${next.name}!` : n === 1 ? `Mañana es feriado: ${next.name}.` : `El próximo feriado es en ${n} días: ${next.name} (${next.date.slice(8, 10)}/${next.date.slice(5, 7)}).`;
  const second = lw ? ` El próximo finde largo es de ${lw.days} días, del ${lw.from.slice(8, 10)}/${lw.from.slice(5, 7)} al ${lw.to.slice(8, 10)}/${lw.to.slice(5, 7)}.` : '';
  return { text: first + second };
}

function helpReply(d: AssistantData): Reply {
  return {
    text: `Puedo contarte cosas con tus propios datos y anotar por vos. Probá con:`,
    payload: { kind: 'chips', items: ['¿Qué hice hoy?', '¿Cuánto gasté este mes?', '¿Qué tengo pendiente mañana?', '¿Qué hay de nuevo?', '¿Qué puedo ver hoy?', '¿A cuánto está el dólar?', '¿Cuándo es el próximo feriado?', 'Gasté 2500 en nafta', 'Recordame llamar al médico mañana a las 10'] },
  };
}

/** Respuesta a partir de la frase. Nunca guarda nada: las acciones vuelven como tarjeta de confirmación. */
export function respond(text: string, d: AssistantData, now: Date = new Date()): Reply {
  const today = todayISO(now);
  const intent: Intent = parseIntent(text, { today });
  return respondIntent(intent, d, now);
}

export function respondIntent(intent: Intent, d: AssistantData, now: Date = new Date()): Reply {
  const today = todayISO(now);
  const s = d.profile.settings.assistant;
  const t = tone(s.personality, d.profile.name, now.getMinutes() + now.getSeconds());
  const usd = d.rates.find((r) => r.casa === 'tarjeta')?.sell ?? d.rates.find((r) => r.casa === 'blue')?.sell ?? null;
  switch (intent.type) {
    case 'greet': {
      const pend = d.tasks.filter((x) => !x.completedAt && x.dueDate && x.dueDate <= today).length;
      return { text: `${t.hi} ${pend ? `Tenés ${pend} ${pend === 1 ? 'tarea pendiente' : 'tareas pendientes'} para hoy.` : 'Por ahora no tenés nada pendiente para hoy.'} ¿En qué te ayudo?`, payload: { kind: 'chips', items: ['¿Qué hice hoy?', 'Pendientes de mañana', '¿Cuánto gasté esta semana?'] } };
    }
    case 'thanks': return { text: s.personality === 'fun' ? '¡De nada! Para eso estoy.' : s.personality === 'direct' ? 'De nada.' : 'De nada, cuando quieras.' };
    case 'help': return helpReply(d);
    case 'who': return { text: `Soy ${s.name}, tu amigo dentro de MY LIFE. No uso internet ni inteligencia artificial: respondo con lo que vos anotás en la app, y nada sale de tu celular.` };
    case 'summary': return summaryReply(d, intent.period, today, t);
    case 'spending': return spendingReply(d, intent.period, intent.category, today, t);
    case 'income': {
      const r = periodRange(intent.period, today);
      const inc = d.txs.filter((x) => x.kind === 'income' && x.date >= r.from && x.date <= r.to);
      const total = inc.reduce((a, x) => a + x.amount, 0);
      return { text: inc.length ? `${r.label.charAt(0).toUpperCase() + r.label.slice(1)} ingresaron ${money(total)} (${inc.slice(0, 3).map((x) => x.name).join(', ')}${inc.length > 3 ? ' y más' : ''}).` : `No tenés ingresos anotados ${r.label}.` };
    }
    case 'balance': return balanceReply(d, today);
    case 'pending': return pendingReply(d, intent.date, intent.label, today);
    case 'goals': return goalsReply(d, t);
    case 'habits': return habitsReply(d, today, t);
    case 'dollar': return dollarReply(d, intent.casa);
    case 'subscriptions': return subsReply(d, intent.name, usd);
    case 'countdown': return countdownReply(d, intent.name);
    case 'routine': return routineReply(d, today);
    case 'feed': return feedReply(d, now);
    case 'what_to_watch': return watchReply(d, intent.query);
    case 'salary': return salaryReply(d);
    case 'holiday': return holidayReply(d, today);
    case 'add_expense': {
      const category = guessCategory(intent.name) ?? 'Otros';
      return { text: `Anoto un gasto de ${money(intent.amount)} en "${intent.name}" (${category}, ${formatRelativeDay(intent.date).toLowerCase()}). ¿Lo guardo?`, payload: { kind: 'confirm', action: 'add_expense', status: 'pending', data: { amount: intent.amount, name: intent.name, category, date: intent.date } } };
    }
    case 'add_income': return { text: `Anoto un ingreso de ${money(intent.amount)}: "${intent.name}" (${formatRelativeDay(intent.date).toLowerCase()}). ¿Lo guardo?`, payload: { kind: 'confirm', action: 'add_income', status: 'pending', data: { amount: intent.amount, name: intent.name, category: 'Ingresos', date: intent.date } } };
    case 'add_task': return { text: `Creo la tarea "${intent.title}"${intent.date ? ` para ${formatRelativeDay(intent.date).toLowerCase()}` : ''}${intent.time ? ` a las ${intent.time}` : ''}. ¿La guardo?`, payload: { kind: 'confirm', action: 'add_task', status: 'pending', data: { title: intent.title, date: intent.date, time: intent.time } } };
    case 'add_reminder': return { text: `Te recuerdo "${intent.title}" ${formatRelativeDay(intent.date).toLowerCase()}${intent.time ? ` a las ${intent.time}` : ' a las 09:00'}. ¿Lo guardo?`, payload: { kind: 'confirm', action: 'add_reminder', status: 'pending', data: { title: intent.title, date: intent.date, time: intent.time ?? '09:00' } } };
    case 'add_note': return { text: `Guardo esta nota: "${intent.text}". ¿Dale?`, payload: { kind: 'confirm', action: 'add_note', status: 'pending', data: { text: intent.text } } };
    case 'rename': return { text: `Dale, desde ahora me llamo ${intent.name}.`, payload: { kind: 'settings', name: intent.name } };
    case 'personality': return { text: intent.value === 'direct' ? 'Ok. Más directo.' : intent.value === 'fun' ? '¡Jaja, me encanta! Modo divertido activado.' : 'Claro, con más calidez entonces.', payload: { kind: 'settings', personality: intent.value } };
    case 'clear': return { text: '¿Borro todo nuestro historial de chat? Tus datos de la app no se tocan.', payload: { kind: 'settings', clear: true } };
    default:
      return {
        text: s.personality === 'direct' ? 'No entendí. Puedo ayudarte con esto:' : s.personality === 'fun' ? 'Uy, esa no la tengo. Pero puedo con estas:' : 'No llegué a entenderte. Probá con alguna de estas:',
        payload: { kind: 'chips', items: ['¿Qué hice hoy?', '¿Cuánto gasté esta semana?', 'Pendientes de mañana', '¿Cómo voy con mis objetivos?', 'Gasté 3500 en el súper', 'Ayuda'] },
      };
  }
}

/** Mensaje del día (lo manda el amigo al abrir el chat por primera vez cada día, si está activado). */
export function dailyMessage(d: AssistantData, now: Date = new Date()): string | null {
  const today = todayISO(now);
  const s = d.profile.settings.assistant;
  const t = tone(s.personality, d.profile.name, now.getDate());
  const bits: string[] = [];
  const pend = d.tasks.filter((x) => !x.completedAt && x.dueDate && x.dueDate <= today);
  if (pend.length) bits.push(`${pend.length} ${pend.length === 1 ? 'tarea' : 'tareas'} para hoy`);
  const ev = occurrencesInRange(d.events, today, today);
  if (ev.length) bits.push(`${ev.length} ${ev.length === 1 ? 'evento' : 'eventos'}`);
  const best = d.habits.map((h) => ({ h, s: currentStreak(h, d.habitLogs.get(h.id) ?? new Set(), today) })).sort((a, b) => b.s - a.s)[0];
  const cd = sortCountdowns(d.countdowns).find((c) => daysLeft(c) >= 0);
  const subSoon = sortByNext(d.subscriptions.filter((x) => x.active)).find((x) => daysLeftSub(x) <= 2);
  const lines: string[] = [];
  lines.push(`${t.hi}${bits.length ? ` Hoy tenés ${bits.join(' y ')}.` : ' Hoy no tenés nada agendado.'}`);
  if (best && best.s >= 3) lines.push(`Llevás ${best.s} días seguidos con "${best.h.title}".${t.cheer}`);
  if (cd && daysLeft(cd) <= 14) lines.push(`${cd.title}: ${cdDaysLabel(cd).toLowerCase()}.`);
  if (subSoon) lines.push(`Acordate: ${subSoon.name} ${subDaysLabel(subSoon).toLowerCase()}.`);
  const hol = nextHoliday(d.holidays, today);
  if (hol && daysUntil(hol.date, today) <= 3) lines.push(daysUntil(hol.date, today) === 0 ? `Hoy es feriado (${hol.name}).` : `${daysUntil(hol.date, today) === 1 ? 'Mañana' : `En ${daysUntil(hol.date, today)} días`} es feriado: ${hol.name}.`);
  const ep = d.watchlist.find((w) => w.status !== 'done' && w.nextDate === today);
  if (ep) lines.push(`Hoy sale ${ep.title}.`);
  return lines.join(' ');
}
