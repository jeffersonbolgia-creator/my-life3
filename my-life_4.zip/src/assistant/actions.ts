// Ejecuta las acciones confirmadas por el usuario en el chat (y sólo esas).

import { financeRepo, notesRepo, remindersRepo, tasksRepo } from '../db/repos';
import type { ReplyPayload } from './engine';

type Confirm = Extract<ReplyPayload, { kind: 'confirm' }>;

export async function applyConfirm(pid: number, c: Confirm): Promise<string> {
  const d = c.data as any;
  switch (c.action) {
    case 'add_expense':
    case 'add_income': {
      await financeRepo.create(pid, {
        kind: c.action === 'add_expense' ? 'expense' : 'income', name: String(d.name || (c.action === 'add_expense' ? 'Gasto' : 'Ingreso')), emoji: '',
        category: String(d.category || 'Otros'), quantity: 1, unitPrice: null, amount: Number(d.amount), date: String(d.date), description: 'Anotado desde el chat',
      });
      return c.action === 'add_expense' ? 'Gasto guardado' : 'Ingreso guardado';
    }
    case 'add_task':
      await tasksRepo.create(pid, { title: String(d.title), description: '', dueDate: d.date ?? null, dueTime: d.time ?? null, priority: 1, category: '', remindMinutes: d.date ? 0 : null });
      return 'Tarea creada';
    case 'add_reminder':
      await remindersRepo.create(pid, { title: String(d.title), kind: 'general', date: String(d.date), time: String(d.time || '09:00'), repeat: 'none', amount: null, notes: 'Creado desde el chat' });
      return 'Recordatorio creado';
    case 'add_note':
      await notesRepo.create(pid, { title: '', body: String(d.text), category: 'General', isList: false, items: [], favorite: false });
      return 'Nota guardada';
  }
  return 'Listo';
}

/** A qué pantalla ir para "cambiar" antes de guardar. */
export function editRoute(c: Confirm): { route: string; params: any } {
  const d = c.data as any;
  switch (c.action) {
    case 'add_expense': return { route: 'TxForm', params: { kind: 'expense', prefill: { name: d.name, amount: d.amount, category: d.category, date: d.date } } };
    case 'add_income': return { route: 'TxForm', params: { kind: 'income', prefill: { name: d.name, amount: d.amount, category: d.category, date: d.date } } };
    case 'add_task': return { route: 'TaskForm', params: { prefill: { title: d.title, date: d.date, time: d.time } } };
    case 'add_reminder': return { route: 'ReminderForm', params: { prefill: { title: d.title, date: d.date, time: d.time } } };
    case 'add_note': return { route: 'NoteEditor', params: { prefill: { body: d.text } } };
  }
}
