import React from 'react';
import { Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, IconButton, Screen, SectionHeader, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { CASA_LABELS, CASA_ORDER, isCurrencyCasa } from '../../logic/dollar';
import { tap } from '../../ui/haptics';
import type { DollarCasa } from '../../types';

const HINTS: Partial<Record<DollarCasa, string>> = {
  blue: 'El informal, el que se ve en la calle', oficial: 'Bancos, sin impuestos', bolsa: 'MEP, el que se compra legalmente en el banco', contadoconliqui: 'Para sacar dólares afuera',
  tarjeta: 'Compras con tarjeta en dólares y suscripciones', mayorista: 'Entre bancos y empresas', cripto: 'Vía stablecoins',
  eur: 'Cotización oficial del euro', brl: 'Real brasileño, cotización oficial', clp: 'Peso chileno, cotización oficial', uyu: 'Peso uruguayo, cotización oficial',
};

export default function DollarSettingsScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const chosen = profile.settings.dollarCasas;
  const fav = profile.settings.dollarCasa;

  const toggle = (c: DollarCasa) => {
    tap();
    if (chosen.includes(c)) {
      if (chosen.length === 1) return;
      const next = chosen.filter((x) => x !== c);
      updateSettings({ dollarCasas: next, ...(fav === c ? { dollarCasa: next[0] } : {}) });
    } else updateSettings({ dollarCasas: [...chosen, c] });
  };
  const move = (c: DollarCasa, dir: -1 | 1) => {
    const i = chosen.indexOf(c);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= chosen.length) return;
    tap();
    const next = [...chosen];
    [next[i], next[j]] = [next[j], next[i]];
    updateSettings({ dollarCasas: next });
  };

  const row = (c: DollarCasa, i: number) => {
    const on = chosen.includes(c);
    return (
      <View key={c} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, paddingHorizontal: 6 }}>
        <Pressable onPress={() => toggle(c)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 }} accessibilityRole="checkbox" accessibilityState={{ checked: on }}>
          <View style={{ width: 26, height: 26, borderRadius: 8, borderWidth: 2, borderColor: on ? t.accent.base : t.c.borderStrong, backgroundColor: on ? t.accent.base : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
            {on ? <Icon name="Check" size={16} color="#fff" /> : null}
          </View>
          <View style={{ flex: 1 }}>
            <T variant="bodyStrong">{CASA_LABELS[c].long}</T>
            <T variant="small" muted>{HINTS[c] ?? ''}</T>
          </View>
        </Pressable>
        {on ? (
          <>
            <Pressable onPress={() => updateSettings({ dollarCasa: c })} hitSlop={8} accessibilityLabel="Favorita">
              <Icon name="Star" size={20} color={fav === c ? t.c.warning : t.c.textMuted} />
            </Pressable>
            <IconButton icon="ChevronUp" label="Subir" size={32} onPress={() => move(c, -1)} />
            <IconButton icon="ChevronDown" label="Bajar" size={32} onPress={() => move(c, 1)} />
          </>
        ) : null}
      </View>
    );
  };

  const ordered = [...chosen, ...CASA_ORDER.filter((c) => !chosen.includes(c))];
  return (
    <Screen title="Cotizaciones" subtitle="Qué ver y en qué orden" back>
      <T secondary>Marcá las que te interesan. La estrella es la que aparece en el inicio. Cada perfil tiene su propia lista.</T>
      <SectionHeader title="Dólar" />
      <Card padding={6}>{ordered.filter((c) => !isCurrencyCasa(c)).map(row)}</Card>
      <SectionHeader title="Otras monedas" />
      <Card padding={6}>{ordered.filter(isCurrencyCasa).map(row)}</Card>
      <T variant="small" muted>El oro no tiene una fuente gratuita confiable en pesos, por eso no está. Cripto (Bitcoin, Ethereum) lo tenés en el Feed.</T>
    </Screen>
  );
}
