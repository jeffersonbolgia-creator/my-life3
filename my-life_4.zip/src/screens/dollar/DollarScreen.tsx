import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, RefreshControl, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, Chip, Field, IconButton, Screen, SectionHeader, Segmented, Sheet, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { LineChart } from '../../ui/charts';
import { dollarAlertsRepo, dollarRepo } from '../../db/repos';
import { CASA_LABELS, CASA_ORDER, CASA_SYMBOL, describeAlert, formatPct, formatPesos, formatRate, freshness, isCurrencyCasa, seriesFor, variation, type Period } from '../../logic/dollar';
import { ensureHistory, refreshDollar } from '../../services/dollarService';
import { notifyDollarHits } from '../../notifications/notifications';
import { addDays, todayISO } from '../../lib/dates';
import { parseAmount } from '../../lib/money';
import { success, toast } from '../../ui/haptics';
import type { DollarAlert, DollarAlertKind, DollarCasa, DollarRate } from '../../types';

export function useDollar() {
  const { dataVersion } = useApp();
  const [latest, setLatest] = useState<DollarRate[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(async () => {
    setLatest(await dollarRepo.latest());
  }, []);
  const refresh = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    const r = await refreshDollar();
    setError(r.ok ? null : r.error ?? 'Sin conexión');
    if (r.hits.length) notifyDollarHits(r.hits).catch(() => {});
    await load();
    setLoading(false);
  }, [load]);
  useEffect(() => { load(); }, [load, dataVersion]);
  return { latest, loading, error, refresh, load };
}

export default function DollarScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings, bump } = useApp();
  const { latest, loading, error, refresh } = useDollar();
  const casa = profile.settings.dollarCasa;
  // Cotizaciones elegidas en Ajustes (la actual siempre se muestra)
  const shown = useMemo(() => (profile.settings.dollarCasas.includes(casa) ? profile.settings.dollarCasas : [casa, ...profile.settings.dollarCasas]), [profile.settings.dollarCasas, casa]);
  const fmt = (v: number, c: DollarCasa = casa) => formatRate(v, c);
  const [period, setPeriod] = useState<Period>(30);
  const [series, setSeries] = useState<DollarRate[]>([]);
  const [alerts, setAlerts] = useState<DollarAlert[]>([]);
  const [sheet, setSheet] = useState<{ open: boolean; id?: number; kind: DollarAlertKind; value: string; casa: DollarCasa }>({ open: false, kind: 'above', value: '', casa });

  const loadSeries = useCallback(async () => {
    setSeries(await dollarRepo.series(casa, addDays(todayISO(), -95), todayISO()));
  }, [casa]);
  const loadAlerts = useCallback(async () => setAlerts(await dollarAlertsRepo.list(profile.id)), [profile.id]);

  useEffect(() => {
    let alive = true;
    (async () => {
      await loadSeries();
      await loadAlerts();
      await refresh(true);
      const ok = await ensureHistory(casa);
      if (alive && ok) await loadSeries();
      if (alive) await loadSeries();
    })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [casa]);

  const cur = latest.find((r) => r.casa === casa) ?? null;
  const v = useMemo(() => variation(series.length ? series : latest, casa), [series, latest, casa]);
  const points = useMemo(() => seriesFor(series, period), [series, period]);

  const openNew = () => setSheet({ open: true, kind: 'above', value: cur ? String(Math.ceil(cur.sell / 10) * 10) : '', casa });
  const openEdit = (a: DollarAlert) => setSheet({ open: true, id: a.id, kind: a.kind, value: String(a.value).replace('.', ','), casa: a.casa });
  const saveAlert = async () => {
    const value = sheet.kind === 'change' ? Number(sheet.value.replace(',', '.')) : (parseAmount(sheet.value) ?? 0) / 100;
    if (!Number.isFinite(value) || value <= 0) return Alert.alert('Valor', sheet.kind === 'change' ? 'Escribí un porcentaje, por ejemplo 2.' : 'Escribí un valor en pesos, por ejemplo 1500.');
    try {
      const data = { casa: sheet.casa, kind: sheet.kind, value, enabled: true };
      if (sheet.id) await dollarAlertsRepo.update(profile.id, sheet.id, data);
      else await dollarAlertsRepo.create(profile.id, data);
      success();
      toast('Alerta guardada');
      setSheet((s) => ({ ...s, open: false }));
      await loadAlerts();
      bump();
    } catch (e: any) {
      Alert.alert('Error', String(e?.message ?? e));
    }
  };
  const removeAlert = async () => {
    if (!sheet.id) return;
    await dollarAlertsRepo.remove(profile.id, sheet.id);
    setSheet((s) => ({ ...s, open: false }));
    await loadAlerts();
    bump();
  };

  return (
    <Screen
      title="Dólar hoy"
      subtitle={cur ? `Actualizado ${freshness(cur.updatedAt)}` : error ? 'Sin conexión' : 'Cargando…'}
      back
      right={<View style={{ flexDirection: 'row', gap: 8 }}><IconButton icon="SlidersHorizontal" label="Elegir monedas" onPress={() => navigation.navigate('DollarSettings')} /><IconButton icon="RefreshCw" label="Actualizar" onPress={() => refresh()} /></View>}
      refreshControl={<RefreshControl refreshing={loading} onRefresh={() => refresh()} tintColor={t.accent.base} colors={[t.accent.base]} />}
    >
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {shown.map((c) => (
          <Chip key={c} label={CASA_LABELS[c].short} icon={isCurrencyCasa(c) ? 'Coins' : undefined} selected={c === casa} onPress={() => updateSettings({ dollarCasa: c })} />
        ))}
        <Chip label="Más" icon="Plus" onPress={() => navigation.navigate('DollarSettings')} />
      </View>

      <Card gradient accentBorder>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <View style={{ gap: 4 }}>
            <T variant="label" muted>{CASA_LABELS[casa].long} · venta{CASA_SYMBOL[casa] ? ` · 1 ${CASA_SYMBOL[casa]}` : ''}</T>
            <T variant="display" style={{ fontSize: 40, lineHeight: 46, letterSpacing: -1.2 }}>{cur ? fmt(cur.sell) : '—'}</T>
            <T variant="caption" secondary>{cur ? `Compra ${fmt(cur.buy)}` : error ? 'No se pudo conectar. Se muestra lo último guardado.' : ''}</T>
          </View>
          {v ? (
            <View style={{ alignItems: 'flex-end', gap: 4 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, backgroundColor: (v.abs >= 0 ? t.c.success : t.c.danger) + '22' }}>
                <Icon name={v.abs >= 0 ? 'TrendingUp' : 'TrendingDown'} size={14} color={v.abs >= 0 ? t.c.success : t.c.danger} />
                <T variant="caption" color={v.abs >= 0 ? t.c.success : t.c.danger}>{(v.abs >= 0 ? '+' : '') + fmt(v.abs)} · {formatPct(v.pct)}</T>
              </View>
              <T variant="small" muted>vs. {v.prevDate.slice(8)}/{v.prevDate.slice(5, 7)}</T>
            </View>
          ) : null}
        </View>
        <View style={{ marginTop: 16, gap: 12 }}>
          <Segmented<'7' | '30' | '90'> value={String(period) as any} onChange={(p) => setPeriod(Number(p) as Period)} options={[{ value: '7', label: '7 días' }, { value: '30', label: '30 días' }, { value: '90', label: '90 días' }]} />
          <LineChart points={points} color={t.accent.light} format={(x) => fmt(x)} />
          {points.length < 3 ? <T variant="small" muted>El gráfico se va completando con los días. Si tenés internet, intentamos traer el historial.</T> : null}
        </View>
      </Card>

      <SectionHeader title="Alertas" action="Nueva" onAction={openNew} />
      {alerts.length === 0 ? (
        <Card onPress={openNew}>
          <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
            <Icon name="BellPlus" size={20} color={t.accent.base} />
            <T secondary style={{ flex: 1 }}>Avisame si el blue pasa de un valor, o si sube o baja más de un porcentaje.</T>
          </View>
        </Card>
      ) : (
        <Card padding={6}>
          {alerts.map((a) => (
            <Pressable key={a.id} onPress={() => openEdit(a)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
              <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: (a.enabled ? t.accent.base : t.c.textMuted) + '22', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={a.kind === 'above' ? 'ArrowUp' : a.kind === 'below' ? 'ArrowDown' : 'Activity'} size={18} color={a.enabled ? t.accent.base : t.c.textMuted} />
              </View>
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" color={a.enabled ? undefined : t.c.textMuted}>{describeAlert(a)}</T>
                <T variant="small" muted>{a.lastFiredAt ? `Último aviso: ${freshness(a.lastFiredAt.replace(' ', 'T'))}` : 'Todavía no se disparó'}</T>
              </View>
              <ToggleSwitch value={a.enabled} onChange={async (v) => { await dollarAlertsRepo.setEnabled(profile.id, a.id, v); await loadAlerts(); }} />
            </Pressable>
          ))}
        </Card>
      )}
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-start', paddingHorizontal: 4 }}>
        <Icon name="Info" size={14} color={t.c.textMuted} />
        <T variant="small" muted style={{ flex: 1 }}>La app revisa el dólar cada tanto en segundo plano y cada vez que la abrís. Android decide cuándo, así que el aviso puede demorar unos minutos.</T>
      </View>

      <SectionHeader title="Tus cotizaciones" action="Elegir" onAction={() => navigation.navigate('DollarSettings')} />
      <Card padding={6}>
        {shown.map((c) => {
          const r = latest.find((x) => x.casa === c);
          const vv = variation(latest.length ? [...series.filter((s) => s.casa === c), ...latest.filter((x) => x.casa === c)] : [], c);
          return (
            <Pressable key={c} onPress={() => updateSettings({ dollarCasa: c })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
              <T variant="bodyStrong" style={{ flex: 1 }} color={c === casa ? t.accent.base : undefined}>{CASA_LABELS[c].long}</T>
              <View style={{ alignItems: 'flex-end' }}>
                <T variant="bodyStrong">{r ? formatRate(r.sell, c) : '—'}</T>
                {r ? <T variant="small" muted>compra {formatRate(r.buy, c)}{vv ? ` · ${formatPct(vv.pct)}` : ''}</T> : null}
              </View>
            </Pressable>
          );
        })}
      </Card>

      <Sheet visible={sheet.open} onClose={() => setSheet((s) => ({ ...s, open: false }))} title={sheet.id ? 'Editar alerta' : 'Nueva alerta'}>
        <View style={{ gap: 14 }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {CASA_ORDER.map((c) => <Chip key={c} label={CASA_LABELS[c].short} selected={c === sheet.casa} onPress={() => setSheet((s) => ({ ...s, casa: c }))} />)}
          </View>
          <Segmented<DollarAlertKind> value={sheet.kind} onChange={(k) => setSheet((s) => ({ ...s, kind: k, value: k === 'change' ? '2' : s.value }))} options={[{ value: 'above', label: 'Pasa de' }, { value: 'below', label: 'Baja de' }, { value: 'change', label: 'Varía más de' }]} />
          <Field
            label={sheet.kind === 'change' ? 'Porcentaje en el día' : 'Valor en pesos'}
            value={sheet.value}
            onChangeText={(v) => setSheet((s) => ({ ...s, value: v }))}
            keyboardType="decimal-pad"
            prefix={sheet.kind === 'change' ? '%' : '$'}
            placeholder={sheet.kind === 'change' ? '2' : '1500'}
          />
          <T variant="caption" secondary>{describeAlert({ casa: sheet.casa, kind: sheet.kind, value: sheet.kind === 'change' ? Number(sheet.value.replace(',', '.')) || 0 : (parseAmount(sheet.value) ?? 0) / 100 })}</T>
          <Button title="Guardar alerta" icon="Check" onPress={saveAlert} />
          {sheet.id ? <Button title="Eliminar" icon="Trash2" variant="ghost" onPress={removeAlert} /> : null}
        </View>
      </Sheet>
    </Screen>
  );
}

function ToggleSwitch({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  const t = useTheme();
  return (
    <Pressable onPress={() => onChange(!value)} hitSlop={8} accessibilityRole="switch" accessibilityState={{ checked: value }} style={{ width: 44, height: 26, borderRadius: 13, backgroundColor: value ? t.accent.base : t.c.surface3, justifyContent: 'center', padding: 3 }}>
      <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: '#fff', alignSelf: value ? 'flex-end' : 'flex-start' }} />
    </Pressable>
  );
}
