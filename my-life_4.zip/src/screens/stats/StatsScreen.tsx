import React, { useState } from 'react';
import { View } from 'react-native';
import { useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Card, Screen, SectionHeader, Segmented, T, Button } from '../../ui/kit';
import { GroupedBars, SimpleBars, Legend } from '../../ui/charts';
import { Icon } from '../../ui/Icon';
import { financeRepo, goalsRepo, habitsRepo, tasksRepo } from '../../db/repos';
import { completedPerDay, computePeriodStats, habitRatePerDay, periodRange, previousRange, type Period } from '../../logic/stats';
import { monthlySeries } from '../../logic/finance';
import { todayISO, parseISODate, monthKey, addMonthsToKey, MONTHS_SHORT, startOfMonth, endOfMonth } from '../../lib/dates';
import { formatMoney } from '../../lib/money';

function Metric({ icon, label, value, prev, color }: { icon: string; label: string; value: string; prev?: string; color: string }) {
  const t = useTheme();
  return (
    <Card style={{ flex: 1 }}>
      <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: color + (t.dark ? '24' : '18'), alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={17} color={color} />
      </View>
      <T variant="small" secondary style={{ marginTop: 10 }}>{label}</T>
      <T variant="heading" style={{ marginTop: 2 }} numberOfLines={1}>{value}</T>
      {prev ? <T variant="small" muted numberOfLines={1}>{prev}</T> : null}
    </Card>
  );
}

export default function StatsScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const s = profile.settings;
  const today = todayISO();
  const periods: { value: Period; label: string }[] = [
    { value: 'day', label: 'Hoy' },
    ...(s.showWeeklySummary ? [{ value: 'week' as Period, label: 'Semana' }] : []),
    ...(s.showMonthlySummary ? [{ value: 'month' as Period, label: 'Mes' }] : []),
  ];
  const [chosen, setPeriod] = useState<Period>(s.showWeeklySummary ? 'week' : 'day');
  const period: Period = periods.some((p) => p.value === chosen) ? chosen : 'day';
  const { data } = useData(
    async (pid) => {
      const [tasks, habits, habitLogs, goals, txs] = await Promise.all([tasksRepo.list(pid), habitsRepo.list(pid), habitsRepo.logs(pid), goalsRepo.list(pid), financeRepo.list(pid)]);
      return { tasks, habits, habitLogs, goals, txs };
    },
    null as any,
  );
  if (!data) return <Screen title="Estadísticas" back />;

  const cur = computePeriodStats(periodRange(period, today), today, data);
  const prev = computePeriodStats(previousRange(period, today), today, data);
  const prevLabel = period === 'day' ? 'ayer' : period === 'week' ? 'semana pasada' : 'mes pasado';
  const tasks14 = completedPerDay(data.tasks, today, 14);
  const habit14 = habitRatePerDay(data.habits, data.habitLogs, today, 14);
  const lbl = (d: string, i: number) => (i % 2 === 0 ? String(parseISODate(d).getDate()) : '');
  const months = Array.from({ length: 6 }, (_, i) => addMonthsToKey(monthKey(today), i - 5));
  const tasksByMonth = months.map((m) => computePeriodStats({ from: startOfMonth(m + '-01'), to: endOfMonth(m + '-01') }, today, data).tasksCompleted);
  const fin = monthlySeries(data.txs, monthKey(today), 6);

  return (
    <Screen title="Estadísticas" back>
      {periods.length > 1 ? <Segmented value={period} onChange={setPeriod} options={periods} /> : null}
      {(!s.showWeeklySummary || !s.showMonthlySummary) && (
        <T variant="small" muted>Algunos resúmenes están desactivados. Podés activarlos en Configuración › Resúmenes.</T>
      )}
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Metric icon="CircleCheck" label="Tareas completadas" value={String(cur.tasksCompleted)} prev={`${prev.tasksCompleted} ${prevLabel}`} color={t.accent.base} />
        <Metric icon="Repeat" label="Hábitos cumplidos" value={`${cur.habitRate}%`} prev={`${prev.habitRate}% ${prevLabel}`} color="#06B6D4" />
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Metric icon="Trophy" label="Objetivos alcanzados" value={String(cur.goalsAchieved)} prev={`${prev.goalsAchieved} ${prevLabel}`} color="#F59E0B" />
        <Metric icon="TriangleAlert" label="Tareas atrasadas" value={String(cur.tasksOverdue)} color={t.c.danger} />
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Metric icon="ArrowDownLeft" label="Ingresos" value={formatMoney(cur.income, s.currency)} prev={`${formatMoney(prev.income, s.currency)} ${prevLabel}`} color={t.c.success} />
        <Metric icon="ArrowUpRight" label="Gastos" value={formatMoney(cur.expense, s.currency)} prev={`${formatMoney(prev.expense, s.currency)} ${prevLabel}`} color={t.c.danger} />
      </View>

      <SectionHeader title="Tareas completadas · 14 días" />
      <Card>
        <SimpleBars values={tasks14.map((x) => x.count)} labels={tasks14.map((x, i) => lbl(x.date, i))} />
      </Card>

      <SectionHeader title="Cumplimiento de hábitos · 14 días" />
      <Card>
        {data.habits.length ? (
          <SimpleBars values={habit14.map((x) => x.rate)} labels={habit14.map((x, i) => lbl(x.date, i))} color="#06B6D4" />
        ) : (
          <T secondary>Creá hábitos para ver tu evolución.</T>
        )}
      </Card>

      <SectionHeader title="Evolución personal · 6 meses" />
      <Card>
        <T variant="caption" secondary style={{ marginBottom: 10 }}>Tareas completadas por mes</T>
        <SimpleBars values={tasksByMonth} labels={months.map((m) => MONTHS_SHORT[Number(m.slice(5)) - 1])} />
      </Card>
      <Card>
        <T variant="caption" secondary style={{ marginBottom: 10 }}>Ingresos y gastos por mes</T>
        <GroupedBars
          labels={fin.map((m) => MONTHS_SHORT[Number(m.month.slice(5)) - 1])}
          series={[{ name: 'Ingresos', color: t.c.success, values: fin.map((m) => m.income) }, { name: 'Gastos', color: t.c.danger, values: fin.map((m) => m.expense) }]}
        />
        <View style={{ marginTop: 10 }}>
          <Legend items={[{ color: t.c.success, label: 'Ingresos' }, { color: t.c.danger, label: 'Gastos' }]} />
        </View>
      </Card>
      <Button title="Configurar resúmenes" variant="ghost" size="sm" icon="SlidersHorizontal" onPress={() => navigation.navigate('DashboardSettings')} />
    </Screen>
  );
}
