import React from 'react';
import { Pressable, View } from 'react-native';
const RNPressable = Pressable;
import { useNavigation } from '@react-navigation/native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Avatar, Button, Card, Check, IconBox, IconButton, ProgressBar, ProgressRing, Screen, SectionHeader, Stat, T, Badge } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { tasksRepo, eventsRepo, remindersRepo, habitsRepo, goalsRepo, financeRepo, countdownsRepo, routinesRepo, dollarRepo, subscriptionsRepo, feedRepo, holidaysRepo } from '../../db/repos';
import { rankFeed, kindDef } from '../../logic/feed';
import { HolidayHero } from '../holidays/HolidaysScreen';
import { QuickExpenseSheet } from '../finance/QuickExpenseSheet';
import { CASA_LABELS, formatPesos, formatPct, formatRate, variation, seriesFor } from '../../logic/dollar';
import { daysLabel as subDaysLabel, daysUntilCharge, sortByNext } from '../../logic/subscriptions';
import { LineChart } from '../../ui/charts';
import { CARD_MODULE } from '../../db/defaults';
import { isModuleOn } from '../../modules/registry';
import { featured } from '../../logic/countdown';
import { routinesForDay, routineProgress } from '../../logic/routines';
import { CountdownHero, CountdownRow } from '../countdowns/CountdownCard';
import { RoutineSummary } from '../routines/RoutineCard';
import { todayISO, formatLongDate, greetingFor, addDays, formatRelativeDay, capitalize, monthKey } from '../../lib/dates';
import { occurrencesInRange } from '../../logic/calendar';
import { isScheduledOn, currentStreak } from '../../logic/habits';
import { availableBalance, monthSummary } from '../../logic/finance';
import { computePeriodStats, periodRange } from '../../logic/stats';
import { formatMoney } from '../../lib/money';
import { firstName } from '../../lib/text';
import { PRIORITY_COLORS } from '../agenda/shared';
import { tap } from '../../ui/haptics';

async function loadDashboard(pid: number) {
  const today = todayISO();
  const [tasks, events, reminders, habits, logs, goals, txs, countdowns, routines, routineLogs, rates, subs, feed, holidays] = await Promise.all([
    tasksRepo.list(pid), eventsRepo.list(pid), remindersRepo.list(pid), habitsRepo.list(pid), habitsRepo.logs(pid), goalsRepo.list(pid), financeRepo.list(pid),
    countdownsRepo.list(pid), routinesRepo.list(pid), routinesRepo.logs(pid), dollarRepo.latest(), subscriptionsRepo.list(pid, false), feedRepo.list(pid, { limit: 60 }), holidaysRepo.list(today, addDays(today, 400)),
  ]);
  return { today, tasks, events, reminders, habits, logs, goals, txs, countdowns, routines, routineLogs, rates, subs, feed, holidays };
}

type Dash = Awaited<ReturnType<typeof loadDashboard>>;

export default function HomeScreen() {
  const t = useTheme();
  const nav = useNavigation<any>();
  const profile = useProfile();
  const { bump } = useApp();
  const { data } = useData<Dash | null>(loadDashboard, null);
  const s = profile.settings;
  const today = todayISO();
  const [quick, setQuick] = React.useState(false);

  const header = (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
      <View style={{ flex: 1 }}>
        <T secondary variant="caption">{capitalize(formatLongDate(today))}</T>
        <T variant="display" style={{ marginTop: 4 }} numberOfLines={1}>{greetingFor()}, {firstName(profile.name)}</T>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <IconButton icon="Search" label="Buscar" size={42} onPress={() => nav.navigate('Search')} />
        <Pressable onPress={() => nav.navigate('Settings')} accessibilityLabel="Configuración" hitSlop={8}>
          <Avatar name={profile.name} color={profile.avatarColor} size={46} />
        </Pressable>
      </View>
    </View>
  );

  if (!data) return <Screen tabs hero>{header}</Screen>;

  const pending = data.tasks.filter((x) => !x.completedAt);
  const todayTasks = pending.filter((x) => x.dueDate && x.dueDate <= today);
  const doneToday = data.tasks.filter((x) => x.completedAt?.slice(0, 10) === today).length;
  const upcomingTasks = [...pending].sort((a, b) => (a.dueDate ?? '9999') .localeCompare(b.dueDate ?? '9999')).slice(0, 4);
  const occ = occurrencesInRange(data.events, today, addDays(today, 7));
  const todayEvents = occ.filter((o) => o.date === today);
  const todayHabits = data.habits.filter((h) => isScheduledOn(h, today) || h.frequency === 'weekly');
  const habitsDone = todayHabits.filter((h) => data.logs.get(h.id)?.has(today)).length;
  const activeGoals = data.goals.filter((g) => !g.completedAt).slice(0, 3);
  const upcomingRem = data.reminders.filter((r) => !r.done && (r.repeat !== 'none' || r.date >= today)).slice(0, 3);
  const month = monthKey(today);
  const fin = monthSummary(data.txs, month);
  const balance = availableBalance(data.txs, s.initialBalance, s.initialBalanceDate);
  const todayRoutines = routinesForDay(data.routines, today);
  const routinesDone = todayRoutines.filter((r) => routineProgress(r, data.routineLogs.get(r.id)?.get(today)).completed).length;
  const mainRoutine = todayRoutines.find((r) => !routineProgress(r, data.routineLogs.get(r.id)?.get(today)).completed) ?? todayRoutines[0] ?? null;
  const nextCountdown = featured(data.countdowns);
  const otherCountdowns = data.countdowns.filter((c) => c.id !== nextCountdown?.id && c.date >= today).slice(0, 2);
  const routinesOn = isModuleOn(s.modules, 'routines');
  const assistantOn = isModuleOn(s.modules, 'assistant');
  const rate = data.rates.find((r) => r.casa === s.dollarCasa) ?? null;
  const rateVar = rate ? variation(data.rates, s.dollarCasa) : null;
  const nextSubs = sortByNext(data.subs).slice(0, 3);
  const countdownOn = isModuleOn(s.modules, 'countdown');
  const dayTotal = todayTasks.length + doneToday + todayHabits.length + (routinesOn ? todayRoutines.length : 0);
  const dayDone = doneToday + habitsDone + (routinesOn ? routinesDone : 0);
  const dayPct = dayTotal ? Math.round((dayDone / dayTotal) * 100) : 0;

  const toggleTask = async (id: number, done: boolean) => {
    await tasksRepo.setCompleted(profile.id, id, done);
    bump();
  };
  const toggleHabit = async (id: number) => {
    await habitsRepo.toggle(profile.id, id, today);
    bump();
  };

  const cards: Record<string, React.ReactNode> = {
    today: (
      <Card gradient accentBorder key="today">
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 18 }}>
          <ProgressRing value={dayPct} size={78} stroke={8}>
            <T variant="heading">{dayPct}%</T>
          </ProgressRing>
          <View style={{ flex: 1, gap: 6 }}>
            <T variant="heading">Tu día</T>
            <T secondary variant="caption">
              {todayTasks.length ? `${todayTasks.length} tarea${todayTasks.length === 1 ? '' : 's'} pendiente${todayTasks.length === 1 ? '' : 's'}` : 'Sin tareas pendientes'}
              {' · '}
              {todayEvents.length ? `${todayEvents.length} evento${todayEvents.length === 1 ? '' : 's'}` : 'sin eventos'}
            </T>
            <T secondary variant="caption">
              {todayHabits.length ? `Hábitos: ${habitsDone} de ${todayHabits.length}` : 'Sin hábitos para hoy'}
              {routinesOn && todayRoutines.length ? ` · Rutina${todayRoutines.length > 1 ? 's' : ''} ${routinesDone}/${todayRoutines.length}` : ''}
            </T>
          </View>
        </View>
      </Card>
    ),
    routine: mainRoutine ? (
      <View key="routine" style={{ gap: 10 }}>
        <SectionHeader title="Tu rutina" action="Abrir" onAction={() => nav.navigate('Routines', { id: mainRoutine.id })} />
        <RoutineSummary r={mainRoutine} log={data.routineLogs.get(mainRoutine.id)?.get(today)} logs={data.routineLogs.get(mainRoutine.id)} today={today} onPress={() => nav.navigate('Routines', { id: mainRoutine.id })} />
      </View>
    ) : data.routines.length === 0 ? (
      <Card key="routine" onPress={() => nav.navigate('Routines')}>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Icon name="Sunrise" size={20} color={t.accent.base} />
          <T secondary style={{ flex: 1 }}>Armá tu rutina de mañana en un toque.</T>
          <Icon name="ChevronRight" size={18} color={t.c.textMuted} />
        </View>
      </Card>
    ) : null,
    countdown: nextCountdown ? (
      <View key="countdown" style={{ gap: 10 }}>
        <SectionHeader title="Cuenta regresiva" action="Ver todas" onAction={() => nav.navigate('Countdowns')} />
        <CountdownHero c={nextCountdown} onPress={() => nav.navigate('CountdownForm', { id: nextCountdown.id })} />
        {otherCountdowns.map((c) => <CountdownRow key={c.id} c={c} onPress={() => nav.navigate('CountdownForm', { id: c.id })} />)}
      </View>
    ) : data.countdowns.length === 0 ? (
      <Card key="countdown" onPress={() => nav.navigate('CountdownForm')}>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Icon name="Hourglass" size={20} color={t.accent.base} />
          <T secondary style={{ flex: 1 }}>¿Qué estás esperando? Creá una cuenta regresiva.</T>
          <Icon name="ChevronRight" size={18} color={t.c.textMuted} />
        </View>
      </Card>
    ) : null,
    dollar: (
      <View key="dollar" style={{ gap: 10 }}>
        <SectionHeader title="Dólar hoy" action="Abrir" onAction={() => nav.navigate('Dollar')} />
        <Card onPress={() => nav.navigate('Dollar')}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            <View style={{ flex: 1, gap: 2 }}>
              <T variant="small" secondary>{CASA_LABELS[s.dollarCasa].long} · venta</T>
              <T variant="number">{rate ? formatRate(rate.sell, s.dollarCasa) : '—'}</T>
              {rateVar ? <T variant="small" color={rateVar.abs >= 0 ? t.c.success : t.c.danger}>{(rateVar.abs >= 0 ? '+' : '') + formatPesos(rateVar.abs)} · {formatPct(rateVar.pct)}</T> : <T variant="small" muted>{rate ? 'Tocá para ver el gráfico' : 'Abrí con internet para traer la cotización'}</T>}
            </View>
            <View style={{ width: 120 }}>
              <DollarSpark casa={s.dollarCasa} color={rateVar && rateVar.abs < 0 ? t.c.danger : t.c.success} />
            </View>
          </View>
        </Card>
      </View>
    ),
    subscriptions: nextSubs.length ? (
      <View key="subscriptions" style={{ gap: 10 }}>
        <SectionHeader title="Próximos cobros" action="Ver todos" onAction={() => nav.navigate('Subscriptions')} />
        <Card padding={6}>
          {nextSubs.map((sub) => {
            const d = daysUntilCharge(sub);
            return (
              <Pressable key={sub.id} onPress={() => nav.navigate('SubscriptionForm', { id: sub.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                <IconBox icon={sub.icon} size={34} color={sub.color} />
                <View style={{ flex: 1 }}>
                  <T variant="bodyStrong" numberOfLines={1}>{sub.name}</T>
                  <T variant="small" color={d <= 3 ? t.c.warning : t.c.textMuted}>{subDaysLabel(sub)}</T>
                </View>
                <T variant="bodyStrong">{sub.currency === 'USD' ? `US$ ${(sub.amount / 100).toFixed(0)}` : formatMoney(sub.amount)}</T>
              </Pressable>
            );
          })}
        </Card>
      </View>
    ) : (
      <Card key="subscriptions" onPress={() => nav.navigate('Subscriptions')}>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Icon name="Repeat2" size={20} color={t.accent.base} />
          <T secondary style={{ flex: 1 }}>Cargá tus suscripciones y mirá cuánto falta para cada cobro.</T>
          <Icon name="ChevronRight" size={18} color={t.c.textMuted} />
        </View>
      </Card>
    ),
    feed: (
      <View key="feed" style={{ gap: 10 }}>
        <SectionHeader title="Feed" action="Ver más" onAction={() => nav.navigate('Feed')} />
        {data.feed.length ? (
          <Card padding={6}>
            {rankFeed(data.feed, s.discover.weights).slice(0, 3).map((it) => {
              const kd = kindDef(it.kind);
              return (
                <Pressable key={it.id} onPress={() => nav.navigate('Feed')} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                  <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: kd.color + '22', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={kd.icon} size={17} color={kd.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <T variant="small" color={kd.color} style={{ textTransform: 'uppercase', letterSpacing: 0.8 }} numberOfLines={1}>{it.topic}</T>
                    <T variant="bodyStrong" numberOfLines={2}>{s.feed.spoilerFree && it.spoiler ? 'Resultado oculto (sin spoilers)' : it.title}</T>
                  </View>
                </Pressable>
              );
            })}
          </Card>
        ) : (
          <Card onPress={() => nav.navigate('Feed')}>
            <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Icon name="Newspaper" size={20} color={t.accent.base} />
              <T secondary style={{ flex: 1 }}>Elegí tus intereses y cada día vas a tener publicaciones, noticias y videos nuevos.</T>
              <Icon name="ChevronRight" size={18} color={t.c.textMuted} />
            </View>
          </Card>
        )}
      </View>
    ),
    holidays: data.holidays.length ? (
      <Pressable key="holidays" onPress={() => nav.navigate('Holidays')}>
        <HolidayHero holidays={data.holidays} compact />
      </Pressable>
    ) : null,
    tasks: (
      <View key="tasks" style={{ gap: 10 }}>
        <SectionHeader title="Próximas tareas" action="Ver todas" onAction={() => nav.navigate('Agenda', { view: 'tasks' })} />
        <Card padding={6}>
          {upcomingTasks.length === 0 ? (
            <Pressable onPress={() => nav.navigate('TaskForm')} style={{ padding: 14, flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Icon name="CirclePlus" size={20} color={t.accent.base} />
              <T secondary>No tenés tareas pendientes. Agregá una.</T>
            </Pressable>
          ) : upcomingTasks.map((task) => {
            const overdue = !!task.dueDate && task.dueDate < today;
            return (
              <Pressable key={task.id} onPress={() => nav.navigate('TaskForm', { id: task.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                <Check checked={false} onPress={() => toggleTask(task.id, true)} color={PRIORITY_COLORS[task.priority]} />
                <View style={{ flex: 1 }}>
                  <T variant="bodyStrong" numberOfLines={1}>{task.title}</T>
                  {task.dueDate ? (
                    <T variant="small" color={overdue ? t.c.danger : t.c.textMuted}>
                      {overdue ? 'Atrasada · ' : ''}{formatRelativeDay(task.dueDate)}{task.dueTime ? ` · ${task.dueTime}` : ''}
                    </T>
                  ) : <T variant="small" muted>Sin fecha</T>}
                </View>
              </Pressable>
            );
          })}
        </Card>
      </View>
    ),
    events: (
      <View key="events" style={{ gap: 10 }}>
        <SectionHeader title="Próximos eventos" action="Calendario" onAction={() => nav.navigate('Agenda', { view: 'calendar' })} />
        <Card padding={6}>
          {occ.length === 0 ? (
            <T secondary style={{ padding: 14 }}>Nada agendado para los próximos 7 días.</T>
          ) : occ.slice(0, 4).map((o) => (
            <Pressable key={`${o.event.id}-${o.date}`} onPress={() => nav.navigate('EventForm', { id: o.event.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
              <View style={{ width: 48, alignItems: 'center' }}>
                <T variant="small" color={t.accent.base}>{formatRelativeDay(o.date).split(' ')[0]}</T>
                <T variant="bodyStrong">{o.event.allDay || !o.event.startTime ? '—' : o.event.startTime}</T>
              </View>
              <View style={{ width: 3, alignSelf: 'stretch', borderRadius: 2, backgroundColor: t.accentSoft }} />
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" numberOfLines={1}>{o.event.type === 'birthday' ? `Cumpleaños de ${o.event.title}` : o.event.title}</T>
                <T variant="small" muted numberOfLines={1}>{formatRelativeDay(o.date)}{o.event.location ? ` · ${o.event.location}` : ''}</T>
              </View>
            </Pressable>
          ))}
        </Card>
      </View>
    ),
    reminders: upcomingRem.length ? (
      <View key="reminders" style={{ gap: 10 }}>
        <SectionHeader title="Recordatorios" action="Ver todos" onAction={() => nav.navigate('Reminders')} />
        <Card padding={6}>
          {upcomingRem.map((r) => (
            <Pressable key={r.id} onPress={() => nav.navigate('ReminderForm', { id: r.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
              <IconBox icon={r.kind === 'payment' ? 'Receipt' : 'BellRing'} size={34} color={r.kind === 'payment' ? '#F97316' : t.accent.base} />
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" numberOfLines={1}>{r.title}</T>
                <T variant="small" muted>
                  {r.repeat === 'none' ? formatRelativeDay(r.date) : r.repeat === 'daily' ? 'Todos los días' : r.repeat === 'weekly' ? 'Cada semana' : 'Cada mes'} · {r.time}
                  {r.amount ? ` · ${formatMoney(r.amount)}` : ''}
                </T>
              </View>
            </Pressable>
          ))}
        </Card>
      </View>
    ) : null,
    habits: (
      <View key="habits" style={{ gap: 10 }}>
        <SectionHeader title="Hábitos de hoy" action="Ver todos" onAction={() => nav.navigate('Habits')} />
        {todayHabits.length === 0 ? (
          <Card onPress={() => nav.navigate('HabitForm')}>
            <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Icon name="CirclePlus" size={20} color={t.accent.base} />
              <T secondary>Creá tu primer hábito.</T>
            </View>
          </Card>
        ) : (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {todayHabits.map((h) => {
              const done = !!data.logs.get(h.id)?.has(today);
              const streak = currentStreak(h, data.logs.get(h.id) ?? new Set(), today);
              return (
                <Pressable
                  key={h.id}
                  onPress={() => { tap(); toggleHabit(h.id); }}
                  style={({ pressed }) => ({
                    width: '48%', flexGrow: 1, padding: 14, borderRadius: t.radius.lg, gap: 10, opacity: pressed ? 0.8 : 1,
                    backgroundColor: done ? h.color + (t.dark ? '26' : '1C') : t.c.surface, borderWidth: 1, borderColor: done ? h.color + '66' : t.c.border,
                  })}
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: done }}
                >
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Icon name={h.icon} size={20} color={h.color} />
                    <Icon name={done ? 'CircleCheck' : 'Circle'} size={20} color={done ? h.color : t.c.textMuted} />
                  </View>
                  <T variant="bodyStrong" numberOfLines={2}>{h.title}</T>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                    <Icon name="Flame" size={13} color={streak ? '#F97316' : t.c.textMuted} />
                    <T variant="small" muted>{streak} {h.frequency === 'weekly' ? 'sem.' : 'días'}</T>
                  </View>
                </Pressable>
              );
            })}
          </View>
        )}
      </View>
    ),
    goals: (
      <View key="goals" style={{ gap: 10 }}>
        <SectionHeader title="Objetivos" action="Ver todos" onAction={() => nav.navigate('Goals')} />
        <Card>
          {activeGoals.length === 0 ? (
            <Pressable onPress={() => nav.navigate('GoalForm')} style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Icon name="CirclePlus" size={20} color={t.accent.base} />
              <T secondary>Definí un objetivo para empezar.</T>
            </Pressable>
          ) : (
            <View style={{ gap: 16 }}>
              {activeGoals.map((g) => (
                <Pressable key={g.id} onPress={() => nav.navigate('GoalForm', { id: g.id })} style={{ gap: 8 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 10 }}>
                    <T variant="bodyStrong" numberOfLines={1} style={{ flex: 1 }}>{g.title}</T>
                    <T variant="caption" color={t.accent.base}>{g.progress}%</T>
                  </View>
                  <ProgressBar value={g.progress} />
                </Pressable>
              ))}
            </View>
          )}
        </Card>
      </View>
    ),
    finance: (
      <View key="finance" style={{ gap: 10 }}>
        <SectionHeader title="Finanzas del mes" action="Abrir" onAction={() => nav.navigate('Finance')} />
        <Card onPress={() => nav.navigate('Finance')}>
          <T variant="small" secondary>Saldo disponible</T>
          <T variant="number" style={{ marginTop: 4 }} color={balance < 0 ? t.c.danger : t.c.text}>{formatMoney(balance, s.currency)}</T>
          <View style={{ flexDirection: 'row', marginTop: 14, gap: 12 }}>
            <Stat label="Ingresos" value={formatMoney(fin.income, s.currency)} color={t.c.success} icon="ArrowDownLeft" />
            <Stat label="Gastos" value={formatMoney(fin.expense, s.currency)} color={t.c.danger} icon="ArrowUpRight" />
          </View>
        </Card>
      </View>
    ),
    weekly: s.showWeeklySummary || s.showMonthlySummary ? (
      <View key="weekly" style={{ gap: 10 }}>
        <SectionHeader title="Resumen" action="Estadísticas" onAction={() => nav.navigate('Stats')} />
        {[s.showWeeklySummary && 'week', s.showMonthlySummary && 'month'].filter(Boolean).map((p) => {
          const period = p as 'week' | 'month';
          const st = computePeriodStats(periodRange(period, today), today, { tasks: data.tasks, habits: data.habits, habitLogs: data.logs, goals: data.goals, txs: data.txs });
          return (
            <Card key={period}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <T variant="bodyStrong">{period === 'week' ? 'Esta semana' : 'Este mes'}</T>
                <Badge label={period === 'week' ? 'Semanal' : 'Mensual'} />
              </View>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <Stat label="Tareas hechas" value={String(st.tasksCompleted)} />
                <Stat label="Hábitos" value={`${st.habitRate}%`} />
                <Stat label="Gastado" value={formatMoney(st.expense, s.currency)} />
              </View>
            </Card>
          );
        })}
      </View>
    ) : null,
  };

  const visible = s.dashboardCards
    .filter((c) => c.visible)
    .filter((c) => { const m = CARD_MODULE[c.key]; return !m || isModuleOn(s.modules, m); })
    .map((c) => cards[c.key])
    .filter(Boolean);

  return (
    <>
    <Screen tabs hero>
      {header}
      {visible.length ? visible : (
        <Card>
          <T secondary>Ocultaste todas las tarjetas del inicio.</T>
        </Card>
      )}
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 4 }}>
        <Button title="Personalizar inicio" icon="SlidersHorizontal" variant="ghost" size="sm" full={false} onPress={() => nav.navigate('DashboardSettings')} />
        <Button title="Módulos" icon="LayoutGrid" variant="ghost" size="sm" full={false} onPress={() => nav.navigate('Modules')} />
      </View>
    </Screen>
    <RNPressable
      onPress={() => { tap(); setQuick(true); }}
      accessibilityRole="button"
      accessibilityLabel="Cargar un gasto rápido"
      style={({ pressed }) => ({
        position: 'absolute', right: assistantOn ? 86 : 18, bottom: 118, width: 56, height: 56, borderRadius: 20, alignItems: 'center', justifyContent: 'center',
        backgroundColor: t.c.bgElevated, borderWidth: 1, borderColor: t.c.borderStrong, transform: [{ scale: pressed ? 0.94 : 1 }],
      })}
    >
      <Icon name="Plus" size={26} color={t.accent.light} />
    </RNPressable>
    <QuickExpenseSheet visible={quick} onClose={() => setQuick(false)} />
    {assistantOn ? (
      <RNPressable
        onPress={() => { tap(); nav.navigate('Assistant'); }}
        accessibilityRole="button"
        accessibilityLabel={`Hablar con ${s.assistant.name}`}
        style={({ pressed }) => ({
          position: 'absolute', right: 18, bottom: 118, width: 56, height: 56, borderRadius: 20, alignItems: 'center', justifyContent: 'center',
          backgroundColor: t.accent.base, borderWidth: 1, borderColor: t.accent.light + '80', transform: [{ scale: pressed ? 0.94 : 1 }], ...t.glow(),
        })}
      >
        <Icon name="Sparkles" size={24} color="#fff" />
      </RNPressable>
    ) : null}
    </>
  );
}

function DollarSpark({ casa, color }: { casa: any; color: string }) {
  const [pts, setPts] = React.useState<{ date: string; value: number }[]>([]);
  React.useEffect(() => {
    let alive = true;
    dollarRepo.series(casa, addDays(todayISO(), -7), todayISO()).then((rs) => { if (alive) setPts(seriesFor(rs, 7)); }).catch(() => {});
    return () => { alive = false; };
  }, [casa]);
  if (pts.length < 2) return null;
  return <LineChart points={pts} color={color} height={44} hideAxis />;
}
