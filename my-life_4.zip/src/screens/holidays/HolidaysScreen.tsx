import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View } from 'react-native';
import { useProfile, useTheme } from '../../state/AppContext';
import { Badge, Card, EmptyState, Screen, SectionHeader, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { holidaysRepo } from '../../db/repos';
import { daysUntil, holidayLabel, longWeekends, nextHoliday, nextLongWeekend } from '../../logic/holidays';
import { refreshHolidays } from '../../services/argentinaDatosService';
import { addDays, formatLongDate, todayISO, capitalize, WEEKDAYS_LONG, weekday } from '../../lib/dates';
import type { Holiday } from '../../types';

export function HolidayHero({ holidays, compact }: { holidays: Holiday[]; compact?: boolean }) {
  const t = useTheme();
  const today = todayISO();
  const next = nextHoliday(holidays, today);
  const lw = nextLongWeekend(holidays, today);
  if (!next) return null;
  const d = daysUntil(next.date, today);
  return (
    <Card gradient accentBorder>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
        <View style={{ alignItems: 'center', minWidth: 72 }}>
          <T variant="display" style={{ fontSize: 40, lineHeight: 44 }}>{d}</T>
          <T variant="small" muted>{d === 1 ? 'día' : 'días'}</T>
        </View>
        <View style={{ flex: 1, gap: 3 }}>
          <T variant="label" muted>Próximo feriado</T>
          <T variant="bodyStrong" numberOfLines={2}>{next.name}</T>
          <T variant="caption" secondary>{capitalize(WEEKDAYS_LONG[weekday(next.date)])} {next.date.slice(8, 10)}/{next.date.slice(5, 7)}{holidayLabel(next) ? ` · ${holidayLabel(next)}` : ''}</T>
        </View>
      </View>
      {!compact && lw ? (
        <View style={{ marginTop: 14, flexDirection: 'row', alignItems: 'center', gap: 10, paddingTop: 12, borderTopWidth: 1, borderTopColor: t.c.border }}>
          <Icon name="Sun" size={18} color={t.c.warning} />
          <T variant="caption" secondary style={{ flex: 1 }}>Finde largo de {lw.days} días: del {lw.from.slice(8, 10)}/{lw.from.slice(5, 7)} al {lw.to.slice(8, 10)}/{lw.to.slice(5, 7)} ({daysUntil(lw.from, today) <= 0 ? '¡es ahora!' : `en ${daysUntil(lw.from, today)} días`})</T>
        </View>
      ) : null}
    </Card>
  );
}

export default function HolidaysScreen() {
  const t = useTheme();
  const profile = useProfile();
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [status, setStatus] = useState<string | null>(null);
  const today = todayISO();
  const load = useCallback(async () => setHolidays(await holidaysRepo.list(addDays(today, -370), addDays(today, 400))), [today]);
  useEffect(() => {
    load();
    (async () => {
      const ok = await refreshHolidays();
      if (!ok) setStatus('Sin conexión: no se pudieron traer los feriados.');
      load();
    })();
  }, [load]);

  const upcoming = useMemo(() => holidays.filter((h) => h.date >= today), [holidays, today]);
  const lws = useMemo(() => longWeekends(holidays, today, addDays(today, 400)), [holidays, today]);
  const byMonth = useMemo(() => {
    const m = new Map<string, Holiday[]>();
    for (const h of upcoming) { const k = h.date.slice(0, 7); m.set(k, [...(m.get(k) ?? []), h]); }
    return [...m.entries()];
  }, [upcoming]);

  return (
    <Screen title="Feriados" subtitle={`${upcoming.length} por venir`} back>
      {!holidays.length ? (
        <EmptyState icon="CalendarHeart" title={status ? 'Sin datos todavía' : 'Cargando feriados…'} text={status ?? 'Un momento.'} />
      ) : (
        <>
          <HolidayHero holidays={holidays} />
          {lws.length ? (
            <>
              <SectionHeader title="Fines de semana largos" />
              <Card padding={6}>
                {lws.slice(0, 8).map((lw) => (
                  <View key={lw.from} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                    <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: t.c.warning + '22', alignItems: 'center', justifyContent: 'center' }}><T variant="bodyStrong" color={t.c.warning}>{lw.days}</T></View>
                    <View style={{ flex: 1 }}>
                      <T variant="bodyStrong">{capitalize(formatLongDate(lw.from))} al {lw.to.slice(8, 10)}/{lw.to.slice(5, 7)}</T>
                      <T variant="small" muted numberOfLines={1}>{lw.holidays.map((h) => h.name).join(' · ')}</T>
                    </View>
                    <T variant="small" muted>{daysUntil(lw.from, today) <= 0 ? 'ahora' : `en ${daysUntil(lw.from, today)} d`}</T>
                  </View>
                ))}
              </Card>
            </>
          ) : null}
          {byMonth.map(([month, list]) => (
            <View key={month} style={{ gap: 8 }}>
              <SectionHeader title={capitalize(formatLongDate(month + '-01')).replace(/^\w+ \d+ de /, '')} />
              <Card padding={6}>
                {list.map((h) => (
                  <View key={h.date} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                    <View style={{ width: 48, alignItems: 'center' }}>
                      <T variant="small" color={t.accent.base}>{WEEKDAYS_LONG[weekday(h.date)].slice(0, 3)}</T>
                      <T variant="bodyStrong">{Number(h.date.slice(8, 10))}</T>
                    </View>
                    <View style={{ flex: 1 }}>
                      <T variant="bodyStrong" numberOfLines={2}>{h.name}</T>
                      <T variant="small" muted>{daysUntil(h.date, today) === 0 ? 'Es hoy' : `En ${daysUntil(h.date, today)} días`}</T>
                    </View>
                    {holidayLabel(h) ? <Badge label={holidayLabel(h)} color={/no laborable/i.test(h.type) ? t.c.textMuted : undefined} /> : null}
                  </View>
                ))}
              </Card>
            </View>
          ))}
          <T variant="small" muted>Fuente: calendario oficial de feriados nacionales (ArgentinaDatos). Los no laborables son optativos para el sector privado. Perfil: {profile.name.split(' ')[0]}.</T>
        </>
      )}
    </Screen>
  );
}
