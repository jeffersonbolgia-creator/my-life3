import React from 'react';
import { View } from 'react-native';
import { useProfile } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { EmptyState, IconButton, Screen, SectionHeader, T } from '../../ui/kit';
import { countdownsRepo } from '../../db/repos';
import { featured, sortCountdowns } from '../../logic/countdown';
import { todayISO } from '../../lib/dates';
import type { Countdown } from '../../types';
import { CountdownHero, CountdownRow } from './CountdownCard';

export default function CountdownsScreen({ navigation }: any) {
  useProfile();
  const { data: list } = useData<Countdown[]>((pid) => countdownsRepo.list(pid), []);
  const now = new Date();
  const today = todayISO(now);
  const hero = featured(list, now);
  const sorted = sortCountdowns(list, now).filter((c) => c.id !== hero?.id);
  const upcoming = sorted.filter((c) => c.date >= today);
  const past = sorted.filter((c) => c.date < today);

  return (
    <Screen title="Cuenta regresiva" back right={<IconButton icon="Plus" label="Nueva cuenta regresiva" filled onPress={() => navigation.navigate('CountdownForm')} />}>
      {list.length === 0 ? (
        <EmptyState
          icon="Hourglass"
          title="¿Qué estás esperando?"
          text="Un viaje, un examen, un cumpleaños, el estreno de un juego... Agregalo y mirá cuánto falta."
          action="Crear cuenta regresiva"
          onAction={() => navigation.navigate('CountdownForm')}
        />
      ) : (
        <>
          {hero ? <CountdownHero c={hero} onPress={() => navigation.navigate('CountdownForm', { id: hero.id })} /> : null}
          {upcoming.length ? (
            <View style={{ gap: 10 }}>
              <SectionHeader title="Próximas" />
              {upcoming.map((c) => <CountdownRow key={c.id} c={c} onPress={() => navigation.navigate('CountdownForm', { id: c.id })} />)}
            </View>
          ) : null}
          {past.length ? (
            <View style={{ gap: 10 }}>
              <SectionHeader title="Ya pasaron" />
              {past.map((c) => <CountdownRow key={c.id} c={c} onPress={() => navigation.navigate('CountdownForm', { id: c.id })} />)}
            </View>
          ) : null}
          {!hero && !upcoming.length ? <T secondary align="center">Todas tus cuentas regresivas ya pasaron. Creá una nueva.</T> : null}
        </>
      )}
    </Screen>
  );
}
