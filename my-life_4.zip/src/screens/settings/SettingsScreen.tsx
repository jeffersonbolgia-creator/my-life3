import React from 'react';
import { useApp, useProfile } from '../../state/AppContext';
import { Group, Row, Screen, SectionHeader } from '../../ui/kit';
import { ACCENTS } from '../../theme/theme';

export default function SettingsScreen({ navigation }: any) {
  const profile = useProfile();
  const { lock } = useApp();
  const s = profile.settings;
  const go = (r: string) => () => navigation.navigate(r);
  return (
    <Screen title="Configuración" back>
      <SectionHeader title="Perfil" />
      <Group>
        <Row icon="User" title="Editar perfil" subtitle={profile.name} chevron onPress={go('ProfileEdit')} />
        <Row icon="ShieldCheck" title="Seguridad" subtitle={`PIN de ${s.pinLength} dígitos${s.biometrics ? ' · huella activada' : ''}`} chevron onPress={go('Security')} />
      </Group>
      <SectionHeader title="Personalización" />
      <Group>
        <Row icon="Palette" title="Apariencia" subtitle={`${s.themeMode === 'dark' ? 'Oscuro' : s.themeMode === 'light' ? 'Claro' : 'Automático'} · ${ACCENTS[s.accent].name}`} chevron onPress={go('Appearance')} />
        <Row icon="LayoutDashboard" title="Inicio y resúmenes" subtitle="Tarjetas visibles, resúmenes semanales y mensuales" chevron onPress={go('DashboardSettings')} />
        <Row icon="Bell" title="Notificaciones" subtitle={s.notifications.enabled ? 'Activadas' : 'Desactivadas'} chevron onPress={go('NotificationSettings')} />
      </Group>
      <SectionHeader title="Datos" />
      <Group>
        <Row icon="DatabaseBackup" title="Copias de seguridad" subtitle="Exportar, guardar y restaurar" chevron onPress={go('Backup')} />
      </Group>
      <SectionHeader title="Información" />
      <Group>
        <Row icon="Info" title="Acerca de MY LIFE" chevron onPress={go('About')} />
        <Row icon="LockKeyhole" title="Bloquear ahora" onPress={lock} />
      </Group>
    </Screen>
  );
}
