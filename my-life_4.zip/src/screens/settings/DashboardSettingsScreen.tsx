import React from 'react';
import { View, Switch } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, Group, IconButton, Screen, SectionHeader, T, ToggleRow } from '../../ui/kit';
import { CARD_MODULE, DASHBOARD_CARD_LABELS } from '../../db/defaults';
import { isModuleOn, moduleDef } from '../../modules/registry';
import { tap } from '../../ui/haptics';

export default function DashboardSettingsScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const s = profile.settings;
  const cards = s.dashboardCards;

  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= cards.length) return;
    const next = [...cards];
    [next[i], next[j]] = [next[j], next[i]];
    updateSettings({ dashboardCards: next });
  };
  const toggle = (i: number, v: boolean) => updateSettings({ dashboardCards: cards.map((c, k) => (k === i ? { ...c, visible: v } : c)) });

  return (
    <Screen title="Inicio y resúmenes" back>
      <T secondary>Elegí qué tarjetas ves en el inicio y en qué orden.</T>
      <Card padding={0} style={{ paddingHorizontal: 12 }}>
        {cards.map((c, i) => (
          <View key={c.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 8, borderTopWidth: i ? 1 : 0, borderTopColor: t.c.border }}>
            <View style={{ gap: 2 }}>
              <IconButton icon="ChevronUp" label="Subir" size={30} onPress={() => move(i, -1)} />
            </View>
            <IconButton icon="ChevronDown" label="Bajar" size={30} onPress={() => move(i, 1)} />
            <View style={{ flex: 1, marginLeft: 6, opacity: c.visible ? 1 : 0.5 }}>
              <T variant="bodyStrong">{DASHBOARD_CARD_LABELS[c.key]}</T>
              {CARD_MODULE[c.key] && !isModuleOn(s.modules, CARD_MODULE[c.key]!) ? <T variant="small" muted>Módulo "{moduleDef(CARD_MODULE[c.key]!).label}" apagado</T> : null}
            </View>
            <Switch value={c.visible} onValueChange={(v) => { tap(); toggle(i, v); }} trackColor={{ false: t.c.surface3, true: t.accent.base }} thumbColor="#fff" />
          </View>
        ))}
      </Card>

      <SectionHeader title="Resúmenes" />
      <Group>
        <ToggleRow icon="CalendarRange" title="Resumen semanal" subtitle="En el inicio y en estadísticas" value={s.showWeeklySummary} onChange={(v) => updateSettings({ showWeeklySummary: v })} />
        <ToggleRow icon="CalendarDays" title="Resumen mensual" subtitle="En el inicio y en estadísticas" value={s.showMonthlySummary} onChange={(v) => updateSettings({ showMonthlySummary: v })} />
      </Group>
    </Screen>
  );
}
