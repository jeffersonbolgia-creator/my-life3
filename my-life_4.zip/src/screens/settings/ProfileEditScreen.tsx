import React, { useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Avatar, Button, ChipGroup, DateField, Field, Screen, SectionHeader, T, TimeField, Card, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { AVATAR_COLORS } from '../../db/defaults';
import { ageFromBirth } from '../../lib/dates';
import { profilesRepo } from '../../db/repos';
import { deleteSecrets } from '../../security/pin';
import { cancelAllForProfile } from '../../notifications/notifications';
import { success, toast } from '../../ui/haptics';

const INTERESTS = ['Tecnología', 'Videojuegos', 'Música', 'Deportes', 'Lectura', 'Cine y series', 'Cocina', 'Viajes', 'Moda', 'Fotografía', 'Ciencia', 'Emprender', 'Naturaleza', 'Autos', 'Anime'];

export default function ProfileEditScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { updateProfile, refreshProfiles, lock } = useApp();
  const a = profile.answers;
  const [name, setName] = useState(profile.name);
  const [birth, setBirth] = useState<string | null>(profile.birthDate);
  const [ageText, setAgeText] = useState(profile.birthDate ? '' : profile.age != null ? String(profile.age) : '');
  const [color, setColor] = useState(profile.avatarColor);
  const [school, setSchool] = useState(!!a.studiesAtSchool);
  const [studies, setStudies] = useState(!!a.studies);
  const [studyWhat, setStudyWhat] = useState(a.studyWhat ?? '');
  const [works, setWorks] = useState(!!a.works);
  const [workWhat, setWorkWhat] = useState(a.workWhat ?? '');
  const [wake, setWake] = useState<string | null>(a.wakeTime ?? null);
  const [sleep, setSleep] = useState<string | null>(a.sleepTime ?? null);
  const [interests, setInterests] = useState<string[]>(a.interests ?? []);
  const [activities, setActivities] = useState((a.activities ?? []).join(', '));
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (name.trim().length < 2) return Alert.alert('Nombre', 'Escribí tu nombre.');
    setSaving(true);
    const age = birth ? ageFromBirth(birth) : ageText ? Number(ageText) : null;
    await updateProfile({
      name: name.trim(),
      birthDate: birth,
      age: age != null && Number.isFinite(age) ? age : null,
      avatarColor: color,
      answers: {
        ...a,
        studiesAtSchool: school,
        studies,
        studyWhat: studyWhat.trim() || undefined,
        works,
        workWhat: workWhat.trim() || undefined,
        wakeTime: wake ?? undefined,
        sleepTime: sleep ?? undefined,
        interests,
        activities: activities.split(',').map((x) => x.trim()).filter(Boolean),
      },
    });
    setSaving(false);
    success();
    toast('Perfil actualizado');
    navigation.goBack();
  };

  const deleteProfile = () => {
    Alert.alert(
      'Eliminar perfil',
      `Se borrarán para siempre todos los datos de ${profile.name}: tareas, finanzas, notas, hábitos y objetivos. Esta acción no se puede deshacer.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Eliminar todo',
          style: 'destructive',
          onPress: () =>
            Alert.alert('Confirmación final', '¿Seguro? Te recomendamos hacer una copia de seguridad antes.', [
                  { text: 'Cancelar', style: 'cancel' },
                  {
                    text: 'Sí, eliminar',
                    style: 'destructive',
                    onPress: async () => {
                      await cancelAllForProfile(profile.id);
                      await deleteSecrets(profile.id);
                      await profilesRepo.remove(profile.id);
                      lock();
                      await refreshProfiles();
                    },
                  },
              ]),
        },
      ],
    );
  };

  return (
    <Screen title="Editar perfil" back>
      <View style={{ alignItems: 'center', gap: 14 }}>
        <Avatar name={name || '?'} color={color} size={78} />
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {AVATAR_COLORS.map((c) => (
            <Pressable key={c} onPress={() => setColor(c)} style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: c, borderWidth: 3, borderColor: color === c ? t.c.text : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
              {color === c ? <Icon name="Check" size={14} color="#fff" strokeWidth={3} /> : null}
            </Pressable>
          ))}
        </View>
      </View>
      <Field label="Nombre" value={name} onChangeText={setName} maxLength={40} />
      <DateField label="Fecha de nacimiento" value={birth} onChange={setBirth} maximumDate={new Date()} placeholder="Sin fecha" />
      {!birth && <Field label="Edad" value={ageText} onChangeText={(v) => setAgeText(v.replace(/\D/g, '').slice(0, 3))} keyboardType="number-pad" />}

      <SectionHeader title="Actividades" />
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <ToggleRow icon="School" title="Voy al colegio" value={school} onChange={setSchool} />
        <ToggleRow icon="GraduationCap" title="Estudio" value={studies} onChange={setStudies} />
        <ToggleRow icon="Briefcase" title="Trabajo" value={works} onChange={setWorks} />
      </Card>
      {studies && <Field label="¿Qué estudiás?" value={studyWhat} onChangeText={setStudyWhat} />}
      {works && <Field label="¿De qué trabajás?" value={workWhat} onChangeText={setWorkWhat} />}
      <Field label="Otras actividades (separadas por coma)" value={activities} onChangeText={setActivities} placeholder="Fútbol, inglés, guitarra" />
      <T variant="small" muted>Tus horarios de colegio o trabajo están en el calendario como eventos de tipo “Horario”; podés editarlos desde ahí.</T>

      <SectionHeader title="Rutina" />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <TimeField label="Me levanto" value={wake} onChange={setWake} />
        <TimeField label="Me acuesto" value={sleep} onChange={setSleep} />
      </View>

      <SectionHeader title="Intereses" />
      <ChipGroup multi options={[...new Set([...INTERESTS, ...interests])].map((v) => ({ value: v, label: v }))} value={interests} onChange={setInterests} />

      <Button title="Guardar cambios" icon="Check" size="lg" onPress={save} loading={saving} style={{ marginTop: 10 }} />
      <Button title="Eliminar este perfil" icon="Trash2" variant="ghost" onPress={deleteProfile} />
    </Screen>
  );
}
