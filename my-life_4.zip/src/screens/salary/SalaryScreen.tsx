import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, Chip, EmptyState, Field, IconButton, Screen, SectionHeader, Sheet, Stat, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { LineChart } from '../../ui/charts';
import { dollarRepo, inflationRepo, salariesRepo } from '../../db/repos';
import { buildSalaryRows, currentMonth, monthLabel, salaryVerdict } from '../../logic/salary';
import { CASA_LABELS } from '../../logic/dollar';
import { refreshInflation } from '../../services/argentinaDatosService';
import { refreshDollar } from '../../services/dollarService';
import { addDays, addMonthsToKey, todayISO } from '../../lib/dates';
import { centsToInput, formatMoney, parseAmount } from '../../lib/money';
import { success, toast } from '../../ui/haptics';
import type { DollarRate, InflationRate, Salary } from '../../types';

export default function SalaryScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { dataVersion } = useApp();
  const casa = profile.settings.dollarCasa;
  const [salaries, setSalaries] = useState<Salary[]>([]);
  const [rates, setRates] = useState<DollarRate[]>([]);
  const [infl, setInfl] = useState<InflationRate[]>([]);
  const [sheet, setSheet] = useState<{ open: boolean; month: string; amount: string }>({ open: false, month: currentMonth(), amount: '' });
  const [netStatus, setNetStatus] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [s, r, i] = await Promise.all([salariesRepo.list(profile.id), dollarRepo.series(casa, addDays(todayISO(), -400), todayISO()), inflationRepo.list()]);
    setSalaries(s); setRates(r); setInfl(i);
    return r.length;
  }, [profile.id, casa]);

  useEffect(() => {
    (async () => {
      const haveRates = await load();
      const ok = await refreshInflation();
      if (!ok) setNetStatus('Sin conexión: faltan datos de inflación.');
      if (!haveRates) await refreshDollar({ evaluate: false }).catch(() => {});
      load();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load, dataVersion]);

  const rows = useMemo(() => buildSalaryRows(salaries, rates, infl), [salaries, rates, infl]);
  const last = rows[rows.length - 1] ?? null;
  const verdict = salaryVerdict(rows);
  const lastInfl = infl[infl.length - 1] ?? null;

  const openSheet = (month = currentMonth(), amount = '') => setSheet({ open: true, month, amount });
  const save = async () => {
    const v = parseAmount(sheet.amount);
    if (v == null || v <= 0) return toast('Escribí el sueldo');
    try {
      await salariesRepo.set(profile.id, sheet.month, v);
      success();
      setSheet((s) => ({ ...s, open: false }));
      load();
    } catch (e: any) {
      Alert.alert('Error', String(e?.message ?? e));
    }
  };
  const remove = (month: string) => Alert.alert('Borrar', `¿Borrar el sueldo de ${monthLabel(month)}?`, [{ text: 'Cancelar', style: 'cancel' }, { text: 'Borrar', style: 'destructive', onPress: async () => { await salariesRepo.remove(profile.id, month); load(); } }]);

  const months = [0, -1, -2, -3, -4, -5].map((n) => addMonthsToKey(currentMonth(), n));

  return (
    <Screen title="Sueldo e inflación" subtitle={lastInfl ? `Inflación ${monthLabel(lastInfl.month)}: ${String(lastInfl.value).replace('.', ',')}%` : 'Cuánto vale tu sueldo'} back right={<IconButton icon="Plus" label="Cargar sueldo" filled onPress={() => openSheet()} />}>
      {!salaries.length ? (
        <EmptyState icon="Banknote" title="Cargá tu sueldo de cada mes" text="Te mostramos cuánto equivale en dólares y cuánto poder de compra ganó o perdió contra la inflación oficial." action="Cargar el primero" onAction={() => openSheet()} />
      ) : (
        <>
          <Card gradient accentBorder>
            <T variant="label" muted>{monthLabel(last!.month)}</T>
            <T variant="display" style={{ marginTop: 4 }}>{formatMoney(last!.amount)}</T>
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
              <Stat label={`En dólares (${CASA_LABELS[casa].short})`} value={last!.usd != null ? `US$ ${last!.usd.toFixed(0)}` : '—'} icon="CircleDollarSign" />
              <Stat label="Inflación acumulada" value={last!.inflationSince != null ? `${last!.inflationSince.toFixed(1).replace('.', ',')}%` : '—'} icon="TrendingUp" color={t.c.warning} />
            </View>
            {verdict ? <T variant="caption" secondary style={{ marginTop: 12 }}>{verdict}</T> : <T variant="caption" secondary style={{ marginTop: 12 }}>Cargá otro mes para comparar.</T>}
          </Card>
          {rows.length >= 2 ? (
            <>
              <SectionHeader title="Tu sueldo en dólares" />
              <Card>
                <LineChart points={rows.filter((r) => r.usd != null).map((r) => ({ date: r.month + '-01', value: r.usd! }))} color={t.c.success} format={(v) => `US$ ${Math.round(v)}`} height={150} />
              </Card>
              <SectionHeader title="Poder de compra" />
              <Card>
                <T variant="caption" secondary style={{ marginBottom: 8 }}>Lo que vale tu sueldo en pesos de {monthLabel(rows[0].month)}, descontando la inflación.</T>
                <LineChart points={rows.filter((r) => r.realAmount != null).map((r) => ({ date: r.month + '-01', value: r.realAmount! / 100 }))} color={t.accent.light} format={(v) => formatMoney(Math.round(v * 100))} height={150} />
              </Card>
            </>
          ) : null}
          <SectionHeader title="Meses cargados" />
          <Card padding={6}>
            {[...rows].reverse().map((r) => (
              <Pressable key={r.month} onPress={() => openSheet(r.month, centsToInput(r.amount))} onLongPress={() => remove(r.month)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                <View style={{ flex: 1 }}>
                  <T variant="bodyStrong">{monthLabel(r.month)}</T>
                  <T variant="small" muted>{r.usd != null ? `US$ ${r.usd.toFixed(0)} · ` : ''}{r.realChange != null ? `${r.realChange >= 0 ? '+' : ''}${r.realChange.toFixed(1).replace('.', ',')}% real vs. mes anterior` : r.nominalChange != null ? `${r.nominalChange >= 0 ? '+' : ''}${r.nominalChange.toFixed(1).replace('.', ',')}% vs. mes anterior` : 'Primer mes'}</T>
                </View>
                <T variant="bodyStrong">{formatMoney(r.amount)}</T>
                <Icon name="ChevronRight" size={16} color={t.c.textMuted} />
              </Pressable>
            ))}
          </Card>
          <T variant="small" muted>Tocá un mes para corregirlo; mantené apretado para borrarlo. La inflación es la oficial (INDEC, vía ArgentinaDatos); el último mes suele publicarse con demora.</T>
        </>
      )}
      {netStatus ? <T variant="small" muted>{netStatus}</T> : null}

      <Sheet visible={sheet.open} onClose={() => setSheet((s) => ({ ...s, open: false }))} title="Sueldo del mes">
        <View style={{ gap: 14 }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {months.map((m) => <Chip key={m} label={monthLabel(m)} selected={sheet.month === m} onPress={() => setSheet((s) => ({ ...s, month: m }))} />)}
          </View>
          <Field label="Sueldo neto (lo que cobrás)" value={sheet.amount} onChangeText={(v) => setSheet((s) => ({ ...s, amount: v }))} keyboardType="decimal-pad" prefix="$" placeholder="0" autoFocus />
          <Button title="Guardar" icon="Check" onPress={save} />
        </View>
      </Sheet>
    </Screen>
  );
}
