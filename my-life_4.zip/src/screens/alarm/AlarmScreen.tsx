import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../../state/AppContext';
import { Button, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { snoozeAlarm, stopAlarm } from '../../notifications/notifications';
import { SNOOZE_MINUTES } from '../../logic/alarms';
import { success, tap } from '../../ui/haptics';

/**
 * Pantalla completa de alarma, como un despertador. Se abre al tocar una alarma, o sola
 * si la app está abierta cuando suena. "Listo" apaga las repeticiones; "Posponer" vuelve a avisar.
 */
export default function AlarmScreen({ navigation, route }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { id, title, body, data } = route.params ?? {};
  const [now, setNow] = useState(new Date());
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const i = setInterval(() => setNow(new Date()), 1000);
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1.12, duration: 700, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 1, duration: 700, useNativeDriver: true }),
    ]));
    loop.start();
    return () => { clearInterval(i); loop.stop(); };
  }, [pulse]);

  const done = async () => {
    success();
    await stopAlarm(String(id ?? ''));
    const route = typeof data?.route === 'string' ? data.route : null;
    if (navigation.canGoBack()) navigation.goBack();
    else navigation.navigate('Main');
    if (route && !['Alarm', 'Main'].includes(route)) setTimeout(() => { try { navigation.navigate(route); } catch {} }, 150);
  };
  const snooze = async () => {
    tap();
    await snoozeAlarm(String(id ?? ''), { title: String(title ?? 'Alarma'), body: String(body ?? ''), data: data ?? {} });
    if (navigation.canGoBack()) navigation.goBack();
    else navigation.navigate('Main');
  };

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg }}>
      <LinearGradient colors={[t.accent.deep + 'AA', t.c.bg]} style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 480 }} />
      <View style={{ flex: 1, paddingTop: insets.top + 40, paddingHorizontal: 28, alignItems: 'center', justifyContent: 'space-between', paddingBottom: insets.bottom + 28 }}>
        <View style={{ alignItems: 'center', gap: 8 }}>
          <T variant="display" style={{ fontSize: 64, lineHeight: 70, letterSpacing: -2 }}>{now.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}</T>
          <T variant="caption" secondary>{now.toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' })}</T>
        </View>
        <View style={{ alignItems: 'center', gap: 22 }}>
          <Animated.View style={{ transform: [{ scale: pulse }], width: 132, height: 132, borderRadius: 66, backgroundColor: t.accent.base, alignItems: 'center', justifyContent: 'center', ...t.glow() }}>
            <Icon name="BellRing" size={60} color="#fff" strokeWidth={1.6} />
          </Animated.View>
          <View style={{ alignItems: 'center', gap: 6 }}>
            <T variant="title" align="center">{String(title ?? 'Alarma')}</T>
            {body ? <T secondary align="center">{String(body)}</T> : null}
          </View>
        </View>
        <View style={{ width: '100%', gap: 12 }}>
          <Button title="Listo" icon="Check" size="lg" onPress={done} />
          <Pressable onPress={snooze} style={({ pressed }) => ({ alignItems: 'center', paddingVertical: 14, opacity: pressed ? 0.7 : 1 })} accessibilityRole="button" accessibilityLabel={`Posponer ${SNOOZE_MINUTES} minutos`}>
            <T variant="bodyStrong" color={t.accent.light}>Posponer {SNOOZE_MINUTES} minutos</T>
          </Pressable>
        </View>
      </View>
    </View>
  );
}
