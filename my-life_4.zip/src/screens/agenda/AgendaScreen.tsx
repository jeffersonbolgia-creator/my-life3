import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Badge, Card, Check, ChipGroup, EmptyState, Field, IconButton, Screen, SectionHeader, Segmented, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { eventsRepo, tasksRepo } from '../../db/repos';
import {
  addDays, addMonthsToKey, capitalize, formatLongDate, formatMonthYear, formatRelativeDay, monthGrid, monthKey,
  parseISODate, startOfWeek, todayISO, WEEKDAYS_SHORT, WEEK_ORDER, WEEKDAYS_LETTER,
} from '../../lib/dates';
import { occurrencesInRange, birthdayAge, type Occurrence } from '../../logic/calendar';
import { matchesSearch } from '../../lib/text';
import { eventMeta, PRIORITY_COLORS, PRIORITY_LABELS } from './shared';
import type { Task } from '../../types';
import { success } from '../../ui/haptics';

type TaskFilter = 'pending' | 'today' | 'overdue' | 'done';

function TaskRow({ task, onToggle, onOpen, onDelete }: { task: Task; onToggle: () => void; onOpen: () => void; onDelete: () => void }) {
  const t = useTheme();
  const today = todayISO();
  const done = !!task.completedAt;
  const overdue = !done && !!task.dueDate && task.dueDate < today;
  return (
    <Pressable onPress={onOpen} onLongPress={onDelete} delayLongPress={350} style={{ flexDirection: 'row', gap: 12, paddingVertical: 12, paddingHorizontal: 12, alignItems: 'flex-start' }}>
      <View style={{ paddingTop: 1 }}>
        <Check checked={done} onPress={onToggle} color={PRIORITY_COLORS[task.priority]} />
      </View>
      <View style={{ flex: 1, gap: 4 }}>
        <T variant="bodyStrong" numberOfLines={2} style={done ? { textDecorationLine: 'line-through', opacity: 0.5 } : undefined}>{task.title}</T>
        {task.description ? <T variant="caption" secondary numberOfLines={1}>{task.description}</T> : null}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, alignItems: 'center' }}>
          {task.dueDate ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Icon name="CalendarDays" size={12} color={overdue ? t.c.danger : t.c.textMuted} />
              <T variant="small" color={overdue ? t.c.danger : t.c.textMuted}>
                {formatRelativeDay(task.dueDate)}{task.dueTime ? ` · ${task.dueTime}` : ''}
              </T>
            </View>
          ) : null}
          {task.remindMinutes != null && !done ? <Icon name="Bell" size={12} color={t.c.textMuted} /> : null}
          {task.category ? <Badge label={task.category} color={t.c.textSecondary} /> : null}
          {task.priority === 2 ? <Badge label={PRIORITY_LABELS[2]} color={PRIORITY_COLORS[2]} /> : null}
        </View>
      </View>
    </Pressable>
  );
}

function TasksView() {
  const t = useTheme();
  const nav = useNavigation<any>();
  const profile = useProfile();
  const { bump } = useApp();
  const { data: tasks } = useData<Task[]>((pid) => tasksRepo.list(pid), []);
  const [filter, setFilter] = useState<TaskFilter>('pending');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState<string>('Todas');
  const today = todayISO();

  const cats = useMemo(() => ['Todas', ...new Set(tasks.map((x) => x.category).filter(Boolean))], [tasks]);
  const list = tasks.filter((x) => {
    if (cat !== 'Todas' && x.category !== cat) return false;
    if (q && !matchesSearch(`${x.title} ${x.description}`, q)) return false;
    if (filter === 'done') return !!x.completedAt;
    if (x.completedAt) return false;
    if (filter === 'today') return x.dueDate === today;
    if (filter === 'overdue') return !!x.dueDate && x.dueDate < today;
    return true;
  });
  const overdueCount = tasks.filter((x) => !x.completedAt && x.dueDate && x.dueDate < today).length;

  const groups: { title: string; items: Task[] }[] = [];
  if (filter === 'pending') {
    const add = (title: string, items: Task[]) => items.length && groups.push({ title, items });
    add('Atrasadas', list.filter((x) => x.dueDate && x.dueDate < today));
    add('Hoy', list.filter((x) => x.dueDate === today));
    add('Mañana', list.filter((x) => x.dueDate === addDays(today, 1)));
    add('Próximas', list.filter((x) => x.dueDate && x.dueDate > addDays(today, 1)));
    add('Sin fecha', list.filter((x) => !x.dueDate));
  } else if (list.length) groups.push({ title: '', items: filter === 'done' ? [...list].sort((a, b) => (b.completedAt ?? '').localeCompare(a.completedAt ?? '')) : list });

  const toggle = async (task: Task) => {
    await tasksRepo.setCompleted(profile.id, task.id, !task.completedAt);
    if (!task.completedAt) success();
    bump();
  };
  const remove = (task: Task) =>
    Alert.alert('Eliminar tarea', `¿Eliminar "${task.title}"?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await tasksRepo.remove(profile.id, task.id); bump(); } },
    ]);

  return (
    <View style={{ gap: 14 }}>
      <Field value={q} onChangeText={setQ} placeholder="Buscar tareas" right={<Icon name="Search" size={18} color={t.c.textMuted} />} />
      <Segmented
        value={filter}
        onChange={setFilter}
        options={[
          { value: 'pending', label: 'Pendientes' },
          { value: 'today', label: 'Hoy' },
          { value: 'overdue', label: overdueCount ? `Atrasadas (${overdueCount})` : 'Atrasadas' },
          { value: 'done', label: 'Hechas' },
        ]}
      />
      {cats.length > 2 && <ChipGroup options={cats.map((c) => ({ value: c, label: c }))} value={cat} onChange={setCat} />}
      {groups.length === 0 ? (
        <EmptyState
          icon="ListChecks"
          title={filter === 'done' ? 'Todavía no completaste tareas' : filter === 'overdue' ? 'Nada atrasado' : 'Sin tareas'}
          text={filter === 'pending' ? 'Organizá tu día agregando tu primera tarea.' : undefined}
          action={filter === 'pending' ? 'Nueva tarea' : undefined}
          onAction={() => nav.navigate('TaskForm')}
        />
      ) : groups.map((g) => (
        <View key={g.title || 'all'} style={{ gap: 8 }}>
          {g.title ? <SectionHeader title={`${g.title} · ${g.items.length}`} /> : null}
          <Card padding={2}>
            {g.items.map((task, i) => (
              <View key={task.id} style={i ? { borderTopWidth: 1, borderTopColor: t.c.border } : undefined}>
                <TaskRow task={task} onToggle={() => toggle(task)} onOpen={() => nav.navigate('TaskForm', { id: task.id })} onDelete={() => remove(task)} />
              </View>
            ))}
          </Card>
        </View>
      ))}
      {groups.length > 0 && <T variant="small" muted align="center">Mantené presionada una tarea para eliminarla.</T>}
    </View>
  );
}

function OccurrenceRow({ o, onPress }: { o: Occurrence; onPress: () => void }) {
  const t = useTheme();
  const m = eventMeta(o.event.type);
  const age = birthdayAge(o.event, o.date);
  return (
    <Pressable onPress={onPress} style={{ flexDirection: 'row', gap: 12, padding: 12, alignItems: 'center' }}>
      <View style={{ width: 52 }}>
        <T variant="bodyStrong">{o.event.allDay || !o.event.startTime ? 'Todo' : o.event.startTime}</T>
        <T variant="small" muted>{o.event.allDay || !o.event.startTime ? 'el día' : o.event.endTime ?? ''}</T>
      </View>
      <View style={{ width: 4, alignSelf: 'stretch', borderRadius: 2, backgroundColor: m.color }} />
      <View style={{ flex: 1, gap: 2 }}>
        <T variant="bodyStrong" numberOfLines={1}>
          {o.event.type === 'birthday' ? `Cumpleaños de ${o.event.title}${age ? ` (${age})` : ''}` : o.event.title}
        </T>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Icon name={m.icon} size={12} color={m.color} />
          <T variant="small" muted numberOfLines={1}>{m.label}{o.event.location ? ` · ${o.event.location}` : ''}</T>
          {o.event.remindMinutes != null ? <Icon name="Bell" size={11} color={t.c.textMuted} /> : null}
        </View>
      </View>
    </Pressable>
  );
}

type CalView = 'day' | 'week' | 'month';

function CalendarView() {
  const t = useTheme();
  const nav = useNavigation<any>();
  const today = todayISO();
  const [view, setView] = useState<CalView>('month');
  const [selected, setSelected] = useState(today);
  const [month, setMonth] = useState(monthKey(today));
  const { data } = useData((pid) => Promise.all([eventsRepo.list(pid), tasksRepo.list(pid)]), [[], []] as [any[], Task[]]);
  const [events, tasks] = data;

  const grid = useMemo(() => monthGrid(month), [month]);
  const rangeFrom = view === 'month' ? grid[0][0] : view === 'week' ? startOfWeek(selected) : selected;
  const rangeTo = view === 'month' ? grid[grid.length - 1][6] : view === 'week' ? addDays(startOfWeek(selected), 6) : selected;
  const occ = useMemo(() => occurrencesInRange(events, rangeFrom, rangeTo), [events, rangeFrom, rangeTo]);
  const byDay = useMemo(() => {
    const m = new Map<string, Occurrence[]>();
    for (const o of occ) {
      if (!m.has(o.date)) m.set(o.date, []);
      m.get(o.date)!.push(o);
    }
    return m;
  }, [occ]);
  const tasksByDay = useMemo(() => {
    const m = new Map<string, Task[]>();
    for (const x of tasks) if (x.dueDate && !x.completedAt) {
      if (!m.has(x.dueDate)) m.set(x.dueDate, []);
      m.get(x.dueDate)!.push(x);
    }
    return m;
  }, [tasks]);

  const shift = (dir: number) => {
    if (view === 'month') setMonth((m) => addMonthsToKey(m, dir));
    else {
      const d = addDays(selected, view === 'week' ? 7 * dir : dir);
      setSelected(d);
      setMonth(monthKey(d));
    }
  };
  const goToday = () => {
    setSelected(today);
    setMonth(monthKey(today));
  };

  const title = view === 'month' ? formatMonthYear(month) : view === 'week'
    ? `Semana del ${parseISODate(startOfWeek(selected)).getDate()} ${formatMonthYear(monthKey(startOfWeek(selected))).split(' ')[0].toLowerCase()}`
    : capitalize(formatLongDate(selected));

  const DayList = ({ date, showHeader }: { date: string; showHeader?: boolean }) => {
    const items = byDay.get(date) ?? [];
    const dayTasks = tasksByDay.get(date) ?? [];
    if (showHeader && !items.length && !dayTasks.length) return null;
    return (
      <View style={{ gap: 8 }}>
        {showHeader ? <SectionHeader title={formatRelativeDay(date)} /> : null}
        {items.length || dayTasks.length ? (
          <Card padding={2}>
            {items.map((o, i) => (
              <View key={`${o.event.id}-${i}`} style={i ? { borderTopWidth: 1, borderTopColor: t.c.border } : undefined}>
                <OccurrenceRow o={o} onPress={() => nav.navigate('EventForm', { id: o.event.id })} />
              </View>
            ))}
            {dayTasks.map((x, i) => (
              <Pressable key={'t' + x.id} onPress={() => nav.navigate('TaskForm', { id: x.id })} style={{ flexDirection: 'row', gap: 12, padding: 12, alignItems: 'center', borderTopWidth: items.length || i ? 1 : 0, borderTopColor: t.c.border }}>
                <View style={{ width: 52 }}><T variant="bodyStrong">{x.dueTime ?? '—'}</T></View>
                <View style={{ width: 4, alignSelf: 'stretch', borderRadius: 2, backgroundColor: PRIORITY_COLORS[x.priority] }} />
                <View style={{ flex: 1 }}>
                  <T variant="bodyStrong" numberOfLines={1}>{x.title}</T>
                  <T variant="small" muted>Tarea</T>
                </View>
              </Pressable>
            ))}
          </Card>
        ) : (
          <Card><T secondary>No hay nada agendado este día.</T></Card>
        )}
      </View>
    );
  };

  return (
    <View style={{ gap: 14 }}>
      <Segmented value={view} onChange={setView} options={[{ value: 'day', label: 'Día' }, { value: 'week', label: 'Semana' }, { value: 'month', label: 'Mes' }]} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <IconButton icon="ChevronLeft" label="Anterior" onPress={() => shift(-1)} size={36} />
        <T variant="heading" style={{ flex: 1 }} align="center" numberOfLines={1}>{title}</T>
        <IconButton icon="ChevronRight" label="Siguiente" onPress={() => shift(1)} size={36} />
      </View>
      {(selected !== today || month !== monthKey(today)) && (
        <Pressable onPress={goToday} style={{ alignSelf: 'center' }}><T variant="caption" color={t.accent.base}>Ir a hoy</T></Pressable>
      )}

      {view === 'month' && (
        <Card padding={10}>
          <View style={{ flexDirection: 'row', marginBottom: 6 }}>
            {WEEK_ORDER.map((d) => <T key={d} variant="small" muted align="center" style={{ flex: 1 }}>{WEEKDAYS_LETTER[d]}</T>)}
          </View>
          {grid.map((week, wi) => (
            <View key={wi} style={{ flexDirection: 'row' }}>
              {week.map((d) => {
                const inMonth = monthKey(d) === month;
                const isSel = d === selected;
                const isToday = d === today;
                const dots = (byDay.get(d) ?? []).slice(0, 3);
                const hasTask = (tasksByDay.get(d) ?? []).length > 0;
                return (
                  <Pressable key={d} onPress={() => setSelected(d)} style={{ flex: 1, alignItems: 'center', paddingVertical: 4 }} accessibilityLabel={formatLongDate(d)}>
                    <View style={{
                      width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center',
                      backgroundColor: isSel ? t.accent.base : isToday ? t.accentSoft : 'transparent',
                    }}>
                      <T variant="bodyStrong" color={isSel ? '#fff' : !inMonth ? t.c.textMuted : isToday ? t.accent.base : t.c.text} style={{ opacity: inMonth ? 1 : 0.5 }}>
                        {parseISODate(d).getDate()}
                      </T>
                    </View>
                    <View style={{ flexDirection: 'row', gap: 3, height: 6, marginTop: 2 }}>
                      {dots.map((o, i) => <View key={i} style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: eventMeta(o.event.type).color }} />)}
                      {hasTask ? <View style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: t.c.textSecondary }} /> : null}
                    </View>
                  </Pressable>
                );
              })}
            </View>
          ))}
        </Card>
      )}

      {view === 'week' && (
        <View style={{ flexDirection: 'row', gap: 6 }}>
          {Array.from({ length: 7 }).map((_, i) => {
            const d = addDays(startOfWeek(selected), i);
            const isSel = d === selected;
            const count = (byDay.get(d)?.length ?? 0) + (tasksByDay.get(d)?.length ?? 0);
            return (
              <Pressable key={d} onPress={() => setSelected(d)} style={{
                flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 14, gap: 4,
                backgroundColor: isSel ? t.accent.base : t.c.surface, borderWidth: 1, borderColor: d === today && !isSel ? t.accent.base : t.c.border,
              }}>
                <T variant="small" color={isSel ? '#ffffffCC' : t.c.textMuted}>{WEEKDAYS_SHORT[parseISODate(d).getDay()]}</T>
                <T variant="bodyStrong" color={isSel ? '#fff' : t.c.text}>{parseISODate(d).getDate()}</T>
                <View style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: count ? (isSel ? '#fff' : t.accent.base) : 'transparent' }} />
              </Pressable>
            );
          })}
        </View>
      )}

      {view === 'week' ? (
        <>
          {Array.from({ length: 7 }).map((_, i) => <DayList key={i} date={addDays(startOfWeek(selected), i)} showHeader />)}
          {occ.length === 0 && ![...tasksByDay.keys()].some((d) => d >= rangeFrom && d <= rangeTo) && (
            <EmptyState icon="CalendarDays" title="Semana libre" text="No hay eventos ni tareas esta semana." action="Nuevo evento" onAction={() => nav.navigate('EventForm', { date: selected })} />
          )}
        </>
      ) : (
        <>
          <SectionHeader title={view === 'month' ? formatRelativeDay(selected) : 'Agenda del día'} action="Agregar" onAction={() => nav.navigate('EventForm', { date: selected })} />
          <DayList date={selected} />
        </>
      )}
    </View>
  );
}

export default function AgendaScreen() {
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const [tab, setTab] = useState<'tasks' | 'calendar'>(route.params?.view ?? 'tasks');
  useEffect(() => {
    if (route.params?.view) setTab(route.params.view);
  }, [route.params]);
  return (
    <Screen
      title="Agenda"
      tabs
      right={<IconButton icon="Plus" label="Agregar" filled onPress={() => nav.navigate(tab === 'tasks' ? 'TaskForm' : 'EventForm')} />}
    >
      <Segmented
        value={tab}
        onChange={setTab}
        options={[{ value: 'tasks', label: 'Tareas' }, { value: 'calendar', label: 'Calendario' }]}
      />
      {tab === 'tasks' ? <TasksView /> : <CalendarView />}
    </Screen>
  );
}
