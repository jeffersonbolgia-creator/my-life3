import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Chip, Sheet, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { financeRepo } from '../../db/repos';
import { EXPENSE_CATEGORIES } from '../../logic/finance';
import { guessCategory } from '../../assistant/intents';
import { formatMoney, parseAmount } from '../../lib/money';
import { todayISO } from '../../lib/dates';
import { normalizeText } from '../../lib/text';
import { FONT } from '../../theme/theme';
import { success, tap, toast } from '../../ui/haptics';
import type { Transaction } from '../../types';

interface Recent { name: string; category: string; amount: number; emoji: string; n: number }

/** Los gastos que más se repiten en el perfil (para cargarlos con un toque). */
export function recentExpenses(txs: Transaction[], max = 6): Recent[] {
  const map = new Map<string, Recent>();
  for (const tx of txs) {
    if (tx.kind !== 'expense') continue;
    const k = normalizeText(tx.name);
    const cur = map.get(k);
    if (cur) { cur.n++; cur.amount = tx.amount; }
    else map.set(k, { name: tx.name, category: tx.category, amount: tx.amount, emoji: tx.emoji, n: 1 });
  }
  return [...map.values()].sort((a, b) => b.n - a.n).slice(0, max);
}

/**
 * Hoja de gasto rápido: monto y listo. Nombre y categoría son opcionales (la categoría se adivina).
 * Pensada para "de la pantalla de inicio a gasto guardado en tres toques".
 */
export function QuickExpenseSheet({ visible, onClose, onSaved }: { visible: boolean; onClose: () => void; onSaved?: () => void }) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const [amount, setAmount] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState<string | null>(null);
  const [recent, setRecent] = useState<Recent[]>([]);
  const [saving, setSaving] = useState(false);
  const amountRef = useRef<TextInput>(null);

  useEffect(() => {
    if (!visible) return;
    setAmount(''); setName(''); setCategory(null);
    financeRepo.list(profile.id).then((txs) => setRecent(recentExpenses(txs))).catch(() => {});
    const tm = setTimeout(() => amountRef.current?.focus(), 350);
    return () => clearTimeout(tm);
  }, [visible, profile.id]);

  const cents = useMemo(() => parseAmount(amount), [amount]);
  const guessed = useMemo(() => category ?? guessCategory(name) ?? 'Otros', [category, name]);

  const save = async (over?: Partial<{ name: string; category: string; amount: number; emoji: string }>) => {
    const value = over?.amount ?? cents;
    if (value == null || value <= 0) return toast('Escribí el monto');
    setSaving(true);
    try {
      const n = (over?.name ?? name).trim() || 'Gasto';
      const id = await financeRepo.create(profile.id, { kind: 'expense', name: n, emoji: over?.emoji ?? '', category: over?.category ?? guessed, quantity: 1, unitPrice: null, amount: value, date: todayISO(), description: '' });
      success();
      bump();
      onClose();
      onSaved?.();
      toast(`Gasto de ${formatMoney(value)} guardado · tocá para deshacer`, () => { financeRepo.remove(profile.id, id).then(() => { bump(); toast('Gasto deshecho'); }); });
    } catch (e: any) {
      toast(String(e?.message ?? e));
    }
    setSaving(false);
  };

  return (
    <Sheet visible={visible} onClose={onClose} title="Gasto rápido">
      <View style={{ gap: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: t.radius.lg, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: t.c.border, paddingHorizontal: 16, height: 72 }}>
          <T variant="display" muted>$</T>
          <TextInput
            ref={amountRef}
            value={amount}
            onChangeText={setAmount}
            keyboardType="decimal-pad"
            placeholder="0"
            placeholderTextColor={t.c.textMuted}
            style={{ flex: 1, color: t.c.text, fontFamily: FONT.bold, fontSize: 34 }}
            returnKeyType="done"
            onSubmitEditing={() => save()}
            accessibilityLabel="Monto"
          />
        </View>
        <TextInput
          value={name}
          onChangeText={(v) => { setName(v); setCategory(null); }}
          placeholder="¿En qué? (opcional, ej.: kiosco)"
          placeholderTextColor={t.c.textMuted}
          style={{ color: t.c.text, fontFamily: FONT.regular, fontSize: 16, borderRadius: t.radius.md, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: t.c.border, paddingHorizontal: 14, height: 48 }}
          returnKeyType="done"
          onSubmitEditing={() => save()}
        />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, alignItems: 'center' }}>
          <T variant="small" muted style={{ marginRight: 4 }}>Categoría:</T>
          {[guessed, ...EXPENSE_CATEGORIES.filter((c) => c !== guessed).slice(0, 5)].map((c) => <Chip key={c} label={c} selected={c === guessed} onPress={() => setCategory(c)} />)}
        </View>
        {recent.length ? (
          <View style={{ gap: 8 }}>
            <T variant="small" muted>Repetir un gasto habitual</T>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {recent.map((r) => (
                <Pressable key={r.name} onPress={() => { tap(); save({ name: r.name, category: r.category, amount: cents && cents > 0 ? cents : r.amount, emoji: r.emoji }); }} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, height: 40, borderRadius: 20, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: t.c.border, opacity: pressed ? 0.7 : 1 })}>
                  {r.emoji ? <T>{r.emoji}</T> : <Icon name="RotateCcw" size={14} color={t.c.textSecondary} />}
                  <T variant="caption">{r.name}</T>
                  <T variant="small" muted>{formatMoney(r.amount)}</T>
                </Pressable>
              ))}
            </View>
          </View>
        ) : null}
        <Button title={cents && cents > 0 ? `Guardar ${formatMoney(cents)}` : 'Guardar gasto'} icon="Check" size="lg" onPress={() => save()} loading={saving} />
      </View>
    </Sheet>
  );
}
