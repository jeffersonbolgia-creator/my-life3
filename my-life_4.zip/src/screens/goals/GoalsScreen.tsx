import React, { useState } from 'react';
import { View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Badge, Card, ChipGroup, EmptyState, IconButton, ProgressBar, ProgressRing, Screen, Segmented, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { goalsRepo } from '../../db/repos';
import { diffDays, formatShortDate, todayISO } from '../../lib/dates';
import type { Goal } from '../../types';
import { success } from '../../ui/haptics';
import { formatMoney } from '../../lib/money';

export function GoalCard({ goal, onOpen, onStep }: { goal: Goal; onOpen: () => void; onStep?: (delta: number) => void }) {
  const t = useTheme();
  const today = todayISO();
  const days = goal.targetDate ? diffDays(goal.targetDate, today) : null;
  const done = !!goal.completedAt;
  return (
    <Card onPress={onOpen}>
      <View style={{ flexDirection: 'row', gap: 14, alignItems: 'center' }}>
        <ProgressRing value={goal.progress} size={58} stroke={6} color={done ? t.c.success : undefined}>
          {done ? <Icon name="Trophy" size={20} color={t.c.success} /> : <T variant="caption">{goal.progress}%</T>}
        </ProgressRing>
        <View style={{ flex: 1, gap: 6 }}>
          <T variant="bodyStrong" numberOfLines={2}>{goal.title}</T>
          {goal.savingTarget ? (
            <T variant="caption" secondary>
              {goal.savingCurrency === 'USD' ? `US$ ${(goal.savingSaved / 100).toFixed(0)} de US$ ${(goal.savingTarget / 100).toFixed(0)}` : `${formatMoney(goal.savingSaved)} de ${formatMoney(goal.savingTarget)}`}
            </T>
          ) : null}
          <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
            {goal.savingTarget ? <Badge label="Ahorro" color={t.c.success} /> : null}
            <Badge label={goal.term === 'short' ? 'Corto plazo' : 'Largo plazo'} color={goal.term === 'short' ? t.accent.base : '#06B6D4'} />
            {done ? (
              <Badge label={`Logrado el ${formatShortDate(goal.completedAt!.slice(0, 10))}`} color={t.c.success} />
            ) : days != null ? (
              <Badge label={days < 0 ? `Venció hace ${-days} d` : days === 0 ? 'Vence hoy' : `Faltan ${days} d`} color={days < 0 ? t.c.danger : days <= 7 ? t.c.warning : t.c.textSecondary} />
            ) : null}
          </View>
        </View>
      </View>
      {!done && onStep && !goal.savingTarget && (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14 }}>
          <IconButton icon="Minus" label="Restar 10%" size={34} onPress={() => onStep(-10)} />
          <View style={{ flex: 1 }}><ProgressBar value={goal.progress} /></View>
          <IconButton icon="Plus" label="Sumar 10%" size={34} filled onPress={() => onStep(10)} />
        </View>
      )}
      {!done && goal.savingTarget ? (
        <View style={{ marginTop: 14 }}><ProgressBar value={goal.progress} color={t.c.success} /></View>
      ) : null}
    </Card>
  );
}

export default function GoalsScreen({ navigation }: any) {
  const profile = useProfile();
  const { bump } = useApp();
  const [tab, setTab] = useState<'active' | 'done'>('active');
  const [term, setTerm] = useState<'all' | 'short' | 'long'>('all');
  const { data: goals } = useData<Goal[]>((pid) => goalsRepo.list(pid), []);

  const list = goals.filter((g) => (tab === 'done' ? !!g.completedAt : !g.completedAt) && (term === 'all' || g.term === term));
  const doneCount = goals.filter((g) => g.completedAt).length;
  const avg = goals.filter((g) => !g.completedAt).reduce((s, g, _, a) => s + g.progress / a.length, 0);

  const step = async (g: Goal, delta: number) => {
    const next = Math.max(0, Math.min(100, g.progress + delta));
    await goalsRepo.setProgress(profile.id, g.id, next);
    if (next >= 100) success();
    bump();
  };

  return (
    <Screen title="Objetivos" back right={<IconButton icon="Plus" label="Nuevo objetivo" filled onPress={() => navigation.navigate('GoalForm')} />}>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Card style={{ flex: 1 }}>
          <T variant="small" secondary>Progreso promedio</T>
          <T variant="title" style={{ marginTop: 4 }}>{Math.round(avg)}%</T>
        </Card>
        <Card style={{ flex: 1 }}>
          <T variant="small" secondary>Alcanzados</T>
          <T variant="title" style={{ marginTop: 4 }}>{doneCount}</T>
        </Card>
      </View>
      <Segmented value={tab} onChange={setTab} options={[{ value: 'active', label: 'En curso' }, { value: 'done', label: 'Historial' }]} />
      <ChipGroup options={[{ value: 'all', label: 'Todos' }, { value: 'short', label: 'Corto plazo' }, { value: 'long', label: 'Largo plazo' }]} value={term} onChange={setTerm} />
      {list.length === 0 ? (
        <EmptyState
          icon={tab === 'done' ? 'Trophy' : 'Target'}
          title={tab === 'done' ? 'Todavía no alcanzaste objetivos' : 'Sin objetivos en curso'}
          text={tab === 'done' ? 'Cuando un objetivo llegue al 100% va a aparecer acá.' : 'Definí qué querés lograr y seguí tu avance.'}
          action={tab === 'active' ? 'Crear objetivo' : undefined}
          onAction={() => navigation.navigate('GoalForm')}
        />
      ) : list.map((g) => <GoalCard key={g.id} goal={g} onOpen={() => navigation.navigate('GoalForm', { id: g.id })} onStep={(d) => step(g, d)} />)}
    </Screen>
  );
}
