import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { useApp, useTheme } from '../../state/AppContext';
import { Avatar, Button, Card, Field, Screen, T, Segmented } from '../../ui/kit';
import { PinDots, PinPad } from '../../ui/PinPad';
import { checkRecoveryAnswer, getLockState, isWeakPin, pinInUse, registerFailure, resetFailures, setPin } from '../../security/pin';
import { success } from '../../ui/haptics';
import { profilesRepo } from '../../db/repos';
import type { Profile } from '../../types';

export default function RecoveryScreen({ navigation }: any) {
  const t = useTheme();
  const { profiles, unlock, refreshProfiles } = useApp();
  const [selected, setSelected] = useState<Profile | null>(profiles.length === 1 ? profiles[0] : null);
  const [answer, setAnswer] = useState('');
  const [verified, setVerified] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [len, setLen] = useState<4 | 6>(4);
  const [pin, setPin1] = useState('');
  const [pin2, setPin2] = useState('');
  const [phase, setPhase] = useState<'new' | 'confirm'>('new');
  const [lockedUntil, setLockedUntil] = useState(0);

  useEffect(() => {
    getLockState().then((s) => setLockedUntil(s.lockedUntil)).catch(() => {});
  }, []);

  const verify = async () => {
    if (!selected) return;
    if (lockedUntil > Date.now()) {
      setError(`Demasiados intentos. Esperá ${Math.ceil((lockedUntil - Date.now()) / 1000)} s.`);
      return;
    }
    setBusy(true);
    setTimeout(async () => {
      const ok = await checkRecoveryAnswer(selected.id, answer);
      setBusy(false);
      if (ok) {
        await resetFailures();
        setVerified(true);
        setError(null);
      } else {
        const s = await registerFailure();
        setLockedUntil(s.lockedUntil);
        setError('La respuesta no es correcta.');
      }
    }, 30);
  };

  const onDigit = async (d: string) => {
    setError(null);
    if (phase === 'new') {
      const v = (pin + d).slice(0, len);
      setPin1(v);
      if (v.length === len) {
        if (isWeakPin(v)) {
          setError('Ese PIN es muy fácil. Probá otro.');
          setTimeout(() => setPin1(''), 400);
        } else if (await pinInUse(profiles.map((p) => p.id), v, selected!.id)) {
          setError('Ese PIN ya lo usa otro perfil.');
          setTimeout(() => setPin1(''), 400);
        } else setPhase('confirm');
      }
    } else {
      const v = (pin2 + d).slice(0, len);
      setPin2(v);
      if (v.length === len) {
        if (v !== pin) {
          setError('No coinciden. Empezá de nuevo.');
          setTimeout(() => { setPin1(''); setPin2(''); setPhase('new'); }, 500);
          return;
        }
        try {
          await setPin(selected!.id, v);
          await profilesRepo.updateSettings(selected!.id, { pinLength: len });
          await refreshProfiles();
          success();
          Alert.alert('PIN actualizado', 'Ya podés usar tu nuevo PIN.');
          await unlock(selected!.id);
        } catch (e: any) {
          Alert.alert('Error', String(e?.message ?? e));
        }
      }
    }
  };

  return (
    <Screen title="Recuperar PIN" back>
      {!selected ? (
        <>
          <T secondary>¿De quién es el perfil?</T>
          {profiles.map((p) => (
            <Card key={p.id} onPress={() => setSelected(p)}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <Avatar name={p.name} color={p.avatarColor} />
                <T variant="bodyStrong">{p.name}</T>
              </View>
            </Card>
          ))}
        </>
      ) : !verified ? (
        <>
          <Card>
            <T variant="label" muted>Pregunta de seguridad</T>
            <T variant="heading" style={{ marginTop: 8 }}>{selected.securityQuestion || 'Sin pregunta configurada'}</T>
          </Card>
          <Field label="Tu respuesta" value={answer} onChangeText={setAnswer} autoCapitalize="none" autoFocus error={error} onSubmitEditing={verify} />
          <Button title="Verificar" onPress={verify} loading={busy} disabled={answer.trim().length < 2} />
          {profiles.length > 1 && <Button title="Elegir otro perfil" variant="ghost" onPress={() => { setSelected(null); setAnswer(''); setError(null); }} />}
        </>
      ) : (
        <View style={{ gap: 18 }}>
          <T variant="heading" align="center">{phase === 'new' ? 'Elegí tu nuevo PIN' : 'Confirmá el nuevo PIN'}</T>
          {phase === 'new' && (
            <Segmented value={String(len)} options={[{ value: '4', label: '4 dígitos' }, { value: '6', label: '6 dígitos' }]} onChange={(v) => { setLen(v === '6' ? 6 : 4); setPin1(''); }} />
          )}
          <PinDots length={len} filled={phase === 'new' ? pin.length : pin2.length} error={!!error} />
          <T variant="caption" align="center" color={t.c.danger} style={{ minHeight: 18 }}>{error ?? ''}</T>
          <PinPad onDigit={onDigit} onDelete={() => (phase === 'new' ? setPin1((p) => p.slice(0, -1)) : setPin2((p) => p.slice(0, -1)))} />
        </View>
      )}
      <View style={{ height: 8 }} />
      <T variant="small" muted align="center" onPress={() => navigation.goBack()}>Volver a la pantalla de PIN</T>
    </Screen>
  );
}
