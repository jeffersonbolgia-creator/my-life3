import React, { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, Field, FormActions, IconButton, Screen, Segmented, T, TimeField, ToggleRow } from '../../ui/kit';
import { DayPicker } from '../../ui/DayPicker';
import { Icon } from '../../ui/Icon';
import { routinesRepo } from '../../db/repos';
import { CATEGORY_COLORS } from '../../theme/theme';
import { ROUTINE_TEMPLATES } from '../../db/defaults';
import { stepTimes, totalMinutes } from '../../logic/routines';
import { success, toast } from '../../ui/haptics';
import type { RoutineKind, RoutineStep } from '../../types';

const ICONS = ['Sunrise', 'Moon', 'Sun', 'Coffee', 'Dumbbell', 'BookOpen', 'Briefcase', 'GraduationCap', 'House', 'Sparkles', 'Heart', 'Music'];

let seq = 0;
const newId = () => `s${Date.now().toString(36)}${(seq++).toString(36)}`;

export default function RoutineFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [title, setTitle] = useState('');
  const [kind, setKind] = useState<RoutineKind>('morning');
  const [icon, setIcon] = useState('Sunrise');
  const [color, setColor] = useState('#FBBF24');
  const [startTime, setStartTime] = useState<string | null>(profile.answers.wakeTime ?? null);
  const [steps, setSteps] = useState<RoutineStep[]>([]);
  const [weekdays, setWeekdays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [remind, setRemind] = useState(true);
  const [archived, setArchived] = useState(false);
  const [newStep, setNewStep] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) {
      const tpl = ROUTINE_TEMPLATES[0];
      setSteps(tpl.steps.map((s) => ({ id: newId(), title: s.title, minutes: s.minutes })));
      setTitle(tpl.title);
      return;
    }
    routinesRepo.get(profile.id, id).then((r) => {
      if (!r) return;
      setTitle(r.title); setKind(r.kind); setIcon(r.icon); setColor(r.color); setStartTime(r.startTime);
      setSteps(r.steps); setWeekdays(r.weekdays.length ? r.weekdays : [0, 1, 2, 3, 4, 5, 6]); setRemind(r.remind); setArchived(r.archived);
    });
  }, [id, profile.id]);

  const applyKind = (k: RoutineKind) => {
    setKind(k);
    if (k === 'morning') { setIcon('Sunrise'); setColor('#FBBF24'); setStartTime(profile.answers.wakeTime ?? startTime); if (!id && title === ROUTINE_TEMPLATES[1].title) setTitle(ROUTINE_TEMPLATES[0].title); }
    if (k === 'night') { setIcon('Moon'); setColor('#6366F1'); setStartTime(profile.answers.sleepTime ?? startTime); if (!id && title === ROUTINE_TEMPLATES[0].title) setTitle(ROUTINE_TEMPLATES[1].title); }
  };

  const addStep = () => {
    const v = newStep.trim();
    if (!v) return;
    setSteps((s) => [...s, { id: newId(), title: v, minutes: 5 }]);
    setNewStep('');
    setError(null);
  };
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= steps.length) return;
    const next = [...steps];
    [next[i], next[j]] = [next[j], next[i]];
    setSteps(next);
  };
  const setMinutes = (i: number, delta: number) => setSteps((s) => s.map((x, k) => (k === i ? { ...x, minutes: Math.max(0, Math.min(180, x.minutes + delta)) } : x)));
  const removeStep = (i: number) => setSteps((s) => s.filter((_, k) => k !== i));

  const save = async () => {
    if (!title.trim()) return setError('Ponele un nombre a la rutina');
    if (!steps.length) return setError('Agregá al menos un paso');
    if (weekdays.length === 0) return Alert.alert('Días', 'Elegí al menos un día.');
    setSaving(true);
    const data = { title: title.trim(), kind, icon, color, startTime, steps, weekdays: weekdays.length < 7 ? weekdays : [], remind };
    try {
      if (id) await routinesRepo.update(profile.id, id, data);
      else await routinesRepo.create(profile.id, data);
      success();
      toast('Rutina guardada');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar rutina', 'Se borra también su historial. Si sólo querés pausarla, archivala.', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await routinesRepo.remove(profile.id, id!); bump(); navigation.navigate('Routines'); } },
    ]);
  const toggleArchive = async () => {
    await routinesRepo.setArchived(profile.id, id!, !archived);
    toast(archived ? 'Rutina reactivada' : 'Rutina archivada');
    bump();
    navigation.goBack();
  };

  const times = stepTimes({ startTime, steps });
  const total = totalMinutes(steps);

  return (
    <Screen title={id ? 'Editar rutina' : 'Nueva rutina'} back>
      <Field label="Nombre" value={title} onChangeText={(v) => { setTitle(v); setError(null); }} placeholder="Ej.: Rutina de mañana" error={error} maxLength={50} />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Tipo</T>
        <Segmented value={kind} onChange={applyKind} options={[{ value: 'morning', label: 'Mañana' }, { value: 'night', label: 'Noche' }, { value: 'custom', label: 'Otra' }]} />
      </View>
      <TimeField label="Empieza a las" value={startTime} onChange={setStartTime} placeholder="Sin horario" />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>¿Qué días?</T>
        <DayPicker value={weekdays} onChange={setWeekdays} />
      </View>

      <View style={{ gap: 8 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <T variant="caption" secondary>Pasos ({steps.length})</T>
          {total ? <T variant="small" muted>{total} min en total</T> : null}
        </View>
        <Card padding={0} style={{ paddingHorizontal: 12 }}>
          {steps.map((s, i) => (
            <View key={s.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 8, borderTopWidth: i ? 1 : 0, borderTopColor: t.c.border }}>
              <View style={{ gap: 2 }}>
                <IconButton icon="ChevronUp" label="Subir" size={28} onPress={() => move(i, -1)} />
                <IconButton icon="ChevronDown" label="Bajar" size={28} onPress={() => move(i, 1)} />
              </View>
              <View style={{ flex: 1, marginLeft: 4 }}>
                <T variant="bodyStrong" numberOfLines={2}>{s.title}</T>
                <T variant="small" muted>{times[i] ? `${times[i]} · ` : ''}{s.minutes} min</T>
              </View>
              <IconButton icon="Minus" label="Menos minutos" size={30} onPress={() => setMinutes(i, -5)} />
              <IconButton icon="Plus" label="Más minutos" size={30} onPress={() => setMinutes(i, 5)} />
              <Pressable onPress={() => removeStep(i)} hitSlop={8} accessibilityLabel="Quitar paso" style={{ padding: 6 }}>
                <Icon name="X" size={18} color={t.c.textMuted} />
              </Pressable>
            </View>
          ))}
          {!steps.length ? <T secondary style={{ paddingVertical: 14 }}>Todavía no hay pasos.</T> : null}
        </Card>
        <Field
          value={newStep}
          onChangeText={setNewStep}
          placeholder="Agregar un paso (ej.: Desayunar)"
          onSubmitEditing={addStep}
          returnKeyType="done"
          blurOnSubmit={false}
          maxLength={60}
          right={<Pressable onPress={addStep} hitSlop={10} accessibilityLabel="Agregar paso"><Icon name="Plus" size={22} color={t.accent.base} /></Pressable>}
        />
      </View>

      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Ícono</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {ICONS.map((i) => (
            <Pressable key={i} onPress={() => setIcon(i)} style={{ width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: icon === i ? color + '2E' : t.c.surface2, borderWidth: 1, borderColor: icon === i ? color : t.c.border }}>
              <Icon name={i} size={22} color={icon === i ? color : t.c.textSecondary} />
            </Pressable>
          ))}
        </View>
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Color</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {['#FBBF24', '#6366F1', ...CATEGORY_COLORS.filter((c) => c !== '#F59E0B')].map((c) => (
            <Pressable key={c} onPress={() => setColor(c)} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: c, borderWidth: 3, borderColor: color === c ? t.c.text : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
              {color === c ? <Icon name="Check" size={16} color="#fff" strokeWidth={3} /> : null}
            </Pressable>
          ))}
        </View>
      </View>
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <ToggleRow icon="BellRing" title="Avisarme cuando empieza" subtitle={startTime ? `Notificación a las ${startTime}` : 'Necesita una hora de inicio'} value={remind && !!startTime} onChange={setRemind} disabled={!startTime} />
      </Card>
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
      {id ? <Button title={archived ? 'Reactivar rutina' : 'Archivar rutina'} icon="Archive" variant="secondary" onPress={toggleArchive} /> : null}
    </Screen>
  );
}
