import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Button, Card, Chip, EmptyState, IconButton, Screen, SectionHeader, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { routinesRepo } from '../../db/repos';
import { routinesForDay } from '../../logic/routines';
import { todayISO } from '../../lib/dates';
import { ROUTINE_TEMPLATES } from '../../db/defaults';
import { success } from '../../ui/haptics';
import type { Routine, RoutineLog } from '../../types';
import { RoutineHistory, RoutineSteps, RoutineSummary } from './RoutineCard';

async function load(pid: number) {
  const [routines, logs] = await Promise.all([routinesRepo.list(pid), routinesRepo.logs(pid)]);
  return { routines, logs };
}

export default function RoutinesScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const today = todayISO();
  const { data, reload } = useData<{ routines: Routine[]; logs: Map<number, Map<string, RoutineLog>> }>(load, { routines: [], logs: new Map() });
  const [selected, setSelected] = useState<number | null>(route.params?.id ?? null);

  const todays = routinesForDay(data.routines, today);
  const others = data.routines.filter((r) => !todays.includes(r));
  const sel = data.routines.find((r) => r.id === selected) ?? todays[0] ?? data.routines[0] ?? null;

  useEffect(() => {
    if (sel && sel.id !== selected) setSelected(sel.id);
  }, [sel, selected]);

  const toggle = async (stepId: string) => {
    if (!sel) return;
    const log = await routinesRepo.toggleStep(profile.id, sel.id, today, stepId);
    if (log?.completed) success();
    reload();
    bump();
  };
  const all = async (done: boolean) => {
    if (!sel) return;
    await routinesRepo.setAll(profile.id, sel.id, today, done);
    if (done) success();
    reload();
    bump();
  };

  const createFromTemplate = async (i: number) => {
    const tpl = ROUTINE_TEMPLATES[i];
    const wake = profile.answers.wakeTime ?? null;
    const sleep = profile.answers.sleepTime ?? null;
    const id = await routinesRepo.create(profile.id, {
      title: tpl.title, kind: tpl.kind, icon: tpl.icon, color: tpl.color,
      startTime: tpl.kind === 'morning' ? wake : tpl.kind === 'night' ? sleep : null,
      steps: tpl.steps.map((s, k) => ({ id: `s${k + 1}`, title: s.title, minutes: s.minutes })),
      weekdays: [], remind: !!(tpl.kind === 'morning' ? wake : sleep),
    });
    setSelected(id);
    reload();
    bump();
  };

  return (
    <Screen title="Rutinas" back right={<IconButton icon="Plus" label="Nueva rutina" filled onPress={() => navigation.navigate('RoutineForm')} />}>
      {data.routines.length === 0 ? (
        <>
          <EmptyState icon="Sunrise" title="Armá tu rutina" text="Una lista de pasos que se repite cada día. Empezá con una de estas o creá la tuya." />
          <View style={{ gap: 10 }}>
            {ROUTINE_TEMPLATES.map((tpl, i) => (
              <Card key={tpl.kind} onPress={() => createFromTemplate(i)}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                  <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: tpl.color + '24', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={tpl.icon} size={22} color={tpl.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <T variant="bodyStrong">{tpl.title}</T>
                    <T variant="caption" secondary numberOfLines={2}>{tpl.steps.map((s) => s.title).join(' · ')}</T>
                  </View>
                  <Icon name="Plus" size={20} color={t.accent.base} />
                </View>
              </Card>
            ))}
            <Button title="Crear una rutina propia" variant="secondary" icon="Plus" onPress={() => navigation.navigate('RoutineForm')} />
          </View>
        </>
      ) : (
        <>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {[...todays, ...others].map((r) => (
              <Chip key={r.id} label={r.title} icon={r.icon} color={r.color} selected={sel?.id === r.id} onPress={() => setSelected(r.id)} />
            ))}
          </View>
          {sel ? (
            <>
              <RoutineSummary r={sel} log={data.logs.get(sel.id)?.get(today)} logs={data.logs.get(sel.id)} today={today} onPress={() => navigation.navigate('RoutineForm', { id: sel.id })} />
              {!todays.includes(sel) ? <T variant="caption" secondary>Esta rutina no está programada para hoy, pero podés marcarla igual.</T> : null}
              <SectionHeader title="Pasos de hoy" action="Editar" onAction={() => navigation.navigate('RoutineForm', { id: sel.id })} />
              <Card>
                <RoutineSteps r={sel} log={data.logs.get(sel.id)?.get(today)} onToggle={toggle} onAll={all} />
              </Card>
              <RoutineHistory r={sel} logs={data.logs.get(sel.id)} today={today} />
            </>
          ) : null}
        </>
      )}
    </Screen>
  );
}
