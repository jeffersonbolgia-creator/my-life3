// Reproductor de podcasts dentro de la app (expo-audio). Si el paquete no estuviera,
// el episodio se abre afuera y nada se rompe.

let Audio: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  Audio = require('expo-audio');
} catch {
  Audio = null;
}

export interface PlayerState {
  playing: boolean;
  position: number; // segundos
  duration: number; // segundos (0 si no se sabe)
  title: string;
  author: string;
  image: string | null;
  url: string;
}

type Listener = (s: PlayerState | null) => void;

let player: any = null;
let state: PlayerState | null = null;
let timer: ReturnType<typeof setInterval> | null = null;
const listeners = new Set<Listener>();

export function playerAvailable(): boolean {
  return !!Audio && typeof Audio.createAudioPlayer === 'function';
}

function emit() {
  for (const l of listeners) l(state ? { ...state } : null);
}

function tick() {
  if (!player || !state) return;
  try {
    state.playing = !!player.playing;
    state.position = Number(player.currentTime ?? 0) || 0;
    state.duration = Number(player.duration ?? 0) || 0;
  } catch {}
  emit();
}

export async function playEpisode(ep: { url: string; title: string; author: string; image: string | null }): Promise<boolean> {
  if (!playerAvailable()) return false;
  try {
    // 'doNotMix' habilita los controles en la pantalla de bloqueo; shouldPlayInBackground sigue sonando con la app atrás.
    if (Audio.setAudioModeAsync) await Audio.setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: true, interruptionMode: 'doNotMix', interruptionModeAndroid: 'doNotMix' }).catch(() => {});
    if (player) {
      try { player.remove?.(); } catch {}
      player = null;
    }
    player = Audio.createAudioPlayer({ uri: ep.url });
    state = { playing: true, position: 0, duration: 0, title: ep.title, author: ep.author, image: ep.image, url: ep.url };
    player.play();
    // Controles en la pantalla de bloqueo (si la versión de expo-audio los tiene); sin esto Android corta a los ~3 min en segundo plano.
    try { player.setActiveForLockScreen?.(true, { title: ep.title, artist: ep.author, artworkUrl: ep.image ?? undefined }); } catch {}
    if (timer) clearInterval(timer);
    timer = setInterval(tick, 1000);
    emit();
    return true;
  } catch {
    state = null;
    emit();
    return false;
  }
}

export function toggle() {
  if (!player || !state) return;
  try {
    if (player.playing) player.pause();
    else player.play();
  } catch {}
  tick();
}

export function seekBy(seconds: number) {
  if (!player || !state) return;
  try {
    const to = Math.max(0, (Number(player.currentTime) || 0) + seconds);
    player.seekTo(to);
  } catch {}
  tick();
}

export function stop() {
  if (timer) clearInterval(timer);
  timer = null;
  try { player?.pause?.(); player?.remove?.(); } catch {}
  player = null;
  state = null;
  emit();
}

export function subscribe(l: Listener): () => void {
  listeners.add(l);
  l(state ? { ...state } : null);
  return () => { listeners.delete(l); };
}

export function fmtTime(s: number): string {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  if (m >= 60) return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  return `${m}:${String(sec).padStart(2, '0')}`;
}
