import React, { useEffect, useState } from 'react';
import { Image, Pressable, View } from 'react-native';
import { useTheme } from '../../state/AppContext';
import { T, ProgressBar } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { fmtTime, seekBy, stop, subscribe, toggle, type PlayerState } from './podcastPlayer';

/** Barra del reproductor de podcasts, abajo de la pantalla del Feed. */
export function PlayerBar({ bottom = 0 }: { bottom?: number }) {
  const t = useTheme();
  const [s, setS] = useState<PlayerState | null>(null);
  useEffect(() => subscribe(setS), []);
  if (!s) return null;
  return (
    <View style={{ position: 'absolute', left: 12, right: 12, bottom, borderRadius: 18, backgroundColor: t.c.bgElevated, borderWidth: 1, borderColor: t.c.borderStrong, padding: 10, gap: 8, ...t.glow() }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        {s.image ? <Image source={{ uri: s.image }} style={{ width: 42, height: 42, borderRadius: 10 }} /> : <View style={{ width: 42, height: 42, borderRadius: 10, backgroundColor: t.accentSoft, alignItems: 'center', justifyContent: 'center' }}><Icon name="Podcast" size={20} color={t.accent.base} /></View>}
        <View style={{ flex: 1 }}>
          <T variant="caption" numberOfLines={1} style={{ fontWeight: '600' }}>{s.title}</T>
          <T variant="small" muted numberOfLines={1}>{s.author} · {fmtTime(s.position)}{s.duration ? ` / ${fmtTime(s.duration)}` : ''}</T>
        </View>
        <Pressable onPress={() => seekBy(-15)} hitSlop={6} accessibilityLabel="Atrás 15 segundos"><Icon name="RotateCcw" size={20} color={t.c.textSecondary} /></Pressable>
        <Pressable onPress={toggle} accessibilityLabel={s.playing ? 'Pausar' : 'Reproducir'} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: t.accent.base, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={s.playing ? 'Pause' : 'Play'} size={20} color="#fff" />
        </Pressable>
        <Pressable onPress={() => seekBy(30)} hitSlop={6} accessibilityLabel="Adelante 30 segundos"><Icon name="RotateCw" size={20} color={t.c.textSecondary} /></Pressable>
        <Pressable onPress={stop} hitSlop={6} accessibilityLabel="Cerrar"><Icon name="X" size={20} color={t.c.textMuted} /></Pressable>
      </View>
      {s.duration ? <ProgressBar value={Math.min(100, (s.position / s.duration) * 100)} height={4} /> : null}
    </View>
  );
}
