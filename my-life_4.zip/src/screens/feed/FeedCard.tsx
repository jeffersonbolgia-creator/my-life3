import React, { useState } from 'react';
import { Image, Pressable, View } from 'react-native';
import { useTheme } from '../../state/AppContext';
import { T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { LineChart } from '../../ui/charts';
import { compactNumber, kindDef, timeAgo } from '../../logic/feed';
import { topicDef } from '../../logic/discover';
import { initials } from '../../lib/text';
import type { FeedItem } from '../../types';
import type { MatchExtra } from '../../logic/sources/espn';

export interface FeedCardProps {
  item: FeedItem;
  spoilerFree: boolean;
  onOpen: () => void;
  onMore: () => void;
  onPlay?: () => void;
}

function Avatar({ uri, label, color, size = 40 }: { uri: string | null; label: string; color: string; size?: number }) {
  const [broken, setBroken] = useState(false);
  if (uri && !broken) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} onError={() => setBroken(true)} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color + '33', alignItems: 'center', justifyContent: 'center' }}>
      <T variant="caption" color={color}>{initials(label || '?')}</T>
    </View>
  );
}

function Pic({ uri, ratio = 16 / 9, radius = 14, fallbackIcon, color }: { uri: string | null; ratio?: number; radius?: number; fallbackIcon?: string; color?: string }) {
  const t = useTheme();
  const [broken, setBroken] = useState(false);
  if (!uri || broken) {
    if (!fallbackIcon) return null;
    return (
      <View style={{ width: '100%', aspectRatio: ratio, borderRadius: radius, backgroundColor: (color ?? t.accent.base) + '1A', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={fallbackIcon} size={34} color={color ?? t.accent.base} />
      </View>
    );
  }
  return <Image source={{ uri }} style={{ width: '100%', aspectRatio: ratio, borderRadius: radius, backgroundColor: t.c.surface2 }} resizeMode="cover" onError={() => setBroken(true)} />;
}

/** Cabecera estilo publicación: avatar, nombre, @usuario · hace cuánto. */
function Header({ avatar, name, handle, when, color, onMore }: { avatar: string | null; name: string; handle: string; when: string; color: string; onMore: () => void }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
      <Avatar uri={avatar} label={name} color={color} />
      <View style={{ flex: 1 }}>
        <T variant="bodyStrong" numberOfLines={1}>{name}</T>
        <T variant="small" muted numberOfLines={1}>{handle ? `${handle} · ` : ''}{when}</T>
      </View>
      <Pressable onPress={onMore} hitSlop={10} accessibilityLabel="Opciones" style={{ padding: 4 }}>
        <Icon name="Ellipsis" size={20} color={t.c.textMuted} />
      </Pressable>
    </View>
  );
}

function Stat({ icon, value }: { icon: string; value: string }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
      <Icon name={icon} size={15} color={t.c.textMuted} />
      <T variant="small" muted>{value}</T>
    </View>
  );
}

function Side({ s, align, color }: { s: MatchExtra['home']; align: 'left' | 'right'; color: string }) {
  return (
    <View style={{ flex: 1, alignItems: align === 'left' ? 'flex-start' : 'flex-end', gap: 6 }}>
      <Avatar uri={s?.logo ?? null} label={s?.short || s?.name || '?'} color={color} size={44} />
      <T variant="caption" numberOfLines={2} align={align} style={{ fontWeight: '600' }}>{s?.name ?? '—'}</T>
    </View>
  );
}

function SpoilerCover({ label, onReveal }: { label: string; onReveal: () => void }) {
  const t = useTheme();
  return (
    <Pressable onPress={onReveal} style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, borderRadius: 14, backgroundColor: t.c.bgElevated + 'F2', alignItems: 'center', justifyContent: 'center', gap: 6 }} accessibilityRole="button" accessibilityLabel="Mostrar">
      <Icon name="EyeOff" size={22} color={t.c.textSecondary} />
      <T variant="caption" secondary>{label}</T>
      <T variant="small" color={t.accent.base}>Tocá para ver</T>
    </Pressable>
  );
}

export function FeedCard({ item, spoilerFree, onOpen, onMore, onPlay }: FeedCardProps) {
  const t = useTheme();
  const def = kindDef(item.kind);
  const [revealed, setRevealed] = useState(false);
  const covered = spoilerFree && item.spoiler && !revealed;
  const when = timeAgo(item.publishedAt);
  const x: any = item.extra ?? {};

  let body: React.ReactNode = null;
  let header: React.ReactNode = null;

  switch (item.kind) {
    case 'post':
      header = <Header avatar={item.authorAvatar} name={item.author} handle={item.authorHandle} when={when} color={def.color} onMore={onMore} />;
      body = (
        <>
          <T>{item.text}</T>
          {item.imageUrl ? <Pic uri={item.imageUrl} /> : null}
          <View style={{ flexDirection: 'row', gap: 18 }}>
            <Stat icon="Heart" value={compactNumber(item.likes ?? 0)} />
            <Stat icon="Repeat2" value={compactNumber(Number(x.reposts ?? 0))} />
            <Stat icon="MessageCircle" value={compactNumber(Number(x.replies ?? 0))} />
            <View style={{ flex: 1 }} />
            <T variant="small" muted>Bluesky</T>
          </View>
        </>
      );
      break;
    case 'news': {
      const tdef = topicDef(item.topic);
      header = <Header avatar={null} name={item.author || 'Noticia'} handle={item.topic} when={when} color={tdef.color} onMore={onMore} />;
      body = (
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <View style={{ flex: 1, gap: 4 }}>
            <T variant="bodyStrong">{item.title}</T>
            {item.text ? <T variant="caption" secondary numberOfLines={3}>{item.text}</T> : null}
          </View>
          {item.imageUrl ? <View style={{ width: 84 }}><Pic uri={item.imageUrl} ratio={1} radius={12} /></View> : (
            <View style={{ width: 56, height: 56, borderRadius: 14, backgroundColor: tdef.color + '1F', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={tdef.icon} size={24} color={tdef.color} />
            </View>
          )}
        </View>
      );
      break;
    }
    case 'video':
      header = <Header avatar={null} name={item.author} handle="YouTube" when={when} color={def.color} onMore={onMore} />;
      body = (
        <>
          <View>
            <Pic uri={item.imageUrl} fallbackIcon="Play" color={def.color} />
            <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' }}>
              <View style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: '#000000AA', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="Play" size={26} color="#fff" />
              </View>
            </View>
          </View>
          <T variant="bodyStrong">{item.title}</T>
        </>
      );
      break;
    case 'podcast':
      header = <Header avatar={item.authorAvatar} name={item.author} handle="Podcast" when={when} color={def.color} onMore={onMore} />;
      body = (
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <View style={{ width: 72 }}><Pic uri={item.imageUrl ?? item.authorAvatar} ratio={1} radius={12} fallbackIcon="Podcast" color={def.color} /></View>
          <View style={{ flex: 1, gap: 4 }}>
            <T variant="bodyStrong" numberOfLines={2}>{item.title}</T>
            <T variant="small" muted>{x.duration ? `${x.duration} · ` : ''}{item.text ? item.text.slice(0, 80) : ''}</T>
          </View>
          <Pressable onPress={onPlay ?? onOpen} accessibilityLabel="Reproducir" style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: t.accent.base, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="Play" size={22} color="#fff" />
          </Pressable>
        </View>
      );
      break;
    case 'match': {
      const m = x as MatchExtra;
      const live = m.status === 'live';
      const final = m.status === 'final';
      const when2 = m.status === 'pre' ? startLabel(m.start) : m.detail || (final ? 'Final' : 'En juego');
      header = <Header avatar={null} name={m.league || item.author} handle={m.venue ? m.venue.slice(0, 30) : ''} when={when2} color={live ? t.c.danger : def.color} onMore={onMore} />;
      body = (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Side s={m.home} align="left" color={def.color} />
          <View style={{ alignItems: 'center', minWidth: 96, gap: 2 }}>
            {m.status === 'pre' ? (
              <>
                <T variant="title">{m.start ? new Date(m.start).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' }) : 'vs'}</T>
                <T variant="small" muted>{m.start ? dayLabel(m.start) : ''}</T>
              </>
            ) : (
              <>
                <T variant="display" style={{ fontSize: 30 }}>{m.home?.score ?? '-'} : {m.away?.score ?? '-'}</T>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                  {live ? <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: t.c.danger }} /> : null}
                  <T variant="small" color={live ? t.c.danger : t.c.textMuted}>{live ? 'En vivo' : 'Final'}</T>
                </View>
              </>
            )}
          </View>
          <Side s={m.away} align="right" color={def.color} />
        </View>
      );
      break;
    }
    case 'game':
      header = <Header avatar={null} name={item.topic} handle={item.author} when={x.release ? '' : when} color={def.color} onMore={onMore} />;
      body = (
        <>
          <Pic uri={item.imageUrl} ratio={460 / 215} fallbackIcon="Gamepad2" color={def.color} />
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ flex: 1 }}>
              <T variant="bodyStrong">{item.title}</T>
              <T variant="small" muted>{item.text}</T>
            </View>
            {x.priceText ? (
              <View style={{ alignItems: 'flex-end' }}>
                {x.discount ? <T variant="small" muted style={{ textDecorationLine: 'line-through' }}>{x.initialText}</T> : null}
                <View style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10, backgroundColor: (x.discount ? t.c.success : t.accent.base) + '22' }}>
                  <T variant="bodyStrong" color={x.discount ? t.c.success : t.accent.light}>{x.priceText}</T>
                </View>
              </View>
            ) : null}
          </View>
        </>
      );
      break;
    case 'show':
      header = <Header avatar={null} name={item.topic} handle={item.author} when={when} color={def.color} onMore={onMore} />;
      body = (
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <View style={{ width: 78 }}><Pic uri={item.imageUrl} ratio={2 / 3} radius={12} fallbackIcon="Tv" color={def.color} /></View>
          <View style={{ flex: 1, gap: 4, justifyContent: 'center' }}>
            <T variant="bodyStrong">{item.title}</T>
            <T variant="caption" secondary>{item.text}</T>
            {Array.isArray(x.genres) && x.genres.length ? <T variant="small" muted>{x.genres.slice(0, 3).join(' · ')}</T> : null}
          </View>
        </View>
      );
      break;
    case 'music':
      header = <Header avatar={null} name={item.author} handle="Lanzamiento" when={when} color={def.color} onMore={onMore} />;
      body = (
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <View style={{ width: 84 }}><Pic uri={item.imageUrl} ratio={1} radius={12} fallbackIcon="Music" color={def.color} /></View>
          <View style={{ flex: 1, gap: 4 }}>
            <T variant="bodyStrong" numberOfLines={2}>{item.title}</T>
            <T variant="small" muted>{item.text}{x.releaseDate ? ` · ${x.releaseDate.slice(8, 10)}/${x.releaseDate.slice(5, 7)}/${x.releaseDate.slice(0, 4)}` : ''}</T>
          </View>
          <Icon name="ExternalLink" size={18} color={t.c.textMuted} />
        </View>
      );
      break;
    case 'crypto': {
      const ch = typeof x.change24h === 'number' ? x.change24h : null;
      const up = (ch ?? 0) >= 0;
      const spark: number[] = Array.isArray(x.spark) ? x.spark : [];
      header = <Header avatar={item.authorAvatar} name={item.topic} handle={x.symbol ?? ''} when="ahora" color={def.color} onMore={onMore} />;
      body = (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ flex: 1, gap: 2 }}>
            <T variant="title">{x.priceText ?? ''}</T>
            {ch != null ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <Icon name={up ? 'TrendingUp' : 'TrendingDown'} size={14} color={up ? t.c.success : t.c.danger} />
                <T variant="caption" color={up ? t.c.success : t.c.danger}>{up ? '+' : ''}{ch.toFixed(2).replace('.', ',')}% en 24 h</T>
              </View>
            ) : null}
            {typeof x.change7d === 'number' ? <T variant="small" muted>{x.change7d > 0 ? '+' : ''}{x.change7d.toFixed(1).replace('.', ',')}% en 7 días</T> : null}
          </View>
          {spark.length > 2 ? <View style={{ width: 120 }}><LineChart points={spark.map((v, i) => ({ date: String(i), value: v }))} color={up ? t.c.success : t.c.danger} height={48} hideAxis /></View> : null}
        </View>
      );
      break;
    }
  }

  return (
    <Pressable onPress={onOpen} onLongPress={onMore} delayLongPress={350} accessibilityRole="link" accessibilityLabel={item.title}
      style={({ pressed }) => ({ borderRadius: t.radius.lg, backgroundColor: t.c.surface, borderWidth: 1, borderColor: t.c.border, padding: 14, gap: 12, opacity: pressed ? 0.88 : 1 })}>
      {header}
      <View style={{ gap: 10 }}>
        {body}
        {covered ? <SpoilerCover label={item.kind === 'match' ? 'Resultado oculto' : 'Puede tener spoilers'} onReveal={() => setRevealed(true)} /> : null}
      </View>
      {item.saved ? (
        <View style={{ position: 'absolute', top: 12, right: 44 }}>
          <Icon name="Bookmark" size={16} color={t.accent.base} />
        </View>
      ) : null}
    </Pressable>
  );
}

function dayLabel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const today = new Date();
  const same = d.toDateString() === today.toDateString();
  const tomorrow = new Date(today.getTime() + 86400_000).toDateString() === d.toDateString();
  if (same) return 'Hoy';
  if (tomorrow) return 'Mañana';
  return d.toLocaleDateString('es-AR', { weekday: 'short', day: 'numeric', month: 'short' });
}

function startLabel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Próximamente';
  return `${dayLabel(iso)} ${d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}`;
}
