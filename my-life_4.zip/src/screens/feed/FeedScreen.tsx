import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { FlatList, Linking, Pressable, RefreshControl, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Chip, EmptyState, Field, IconButton, Sheet, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { feedRepo, feedSourcesRepo, watchlistRepo } from '../../db/repos';
import { FEED_KIND_DEFS, adjustWeight, feedSummary, filterFeed, kindDef, rankFeed } from '../../logic/feed';
import { topicsFromInterests } from '../../logic/discover';
import { activeKinds, isStale, refreshFeed } from '../../services/feedService';
import { hasRawg, hasTmdb } from '../../services/keys';
import { FeedCard } from './FeedCard';
import { PlayerBar } from './PlayerBar';
import { playEpisode, playerAvailable } from './podcastPlayer';
import { tap, toast } from '../../ui/haptics';
import type { FeedItem, FeedKind } from '../../types';

type Tab = 'all' | 'saved' | FeedKind;

export default function FeedScreen({ navigation }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const s = profile.settings;
  const prefs = s.discover;
  const kinds = useMemo(() => activeKinds(profile), [s.feed.tabs]);
  const [tab, setTab] = useState<Tab>('all');
  const [items, setItems] = useState<FeedItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [more, setMore] = useState<FeedItem | null>(null);
  const [followedCount, setFollowedCount] = useState(0);
  const listRef = useRef<any>(null);

  const load = useCallback(async () => {
    if (tab === 'saved') setItems(await feedRepo.saved(profile.id));
    else if (tab === 'all') setItems(await feedRepo.list(profile.id, { limit: 400 }));
    else setItems(await feedRepo.list(profile.id, { kind: tab, limit: 200 }));
    setFollowedCount((await feedSourcesRepo.list(profile.id)).length + prefs.topics.length);
  }, [profile.id, tab, prefs.topics.length]);

  const refresh = useCallback(async (silent = false, only?: FeedKind) => {
    if (!silent) setLoading(true);
    try {
      const r = await refreshFeed(profile.id, only);
      const failedLabels = r.failed.map((k) => kindDef(k).label);
      const tried = r.results.filter((x) => x.ok || x.error === 'sin datos');
      setStatus(r.failed.length && r.failed.length === tried.length && tried.length ? 'Sin conexión. Se muestra lo último guardado.' : r.added ? `${r.added} novedades` : failedLabels.length && !silent ? `Sin datos nuevos de ${failedLabels.join(', ')}` : null);
    } catch {
      setStatus('No se pudo actualizar.');
    }
    await load();
    setLoading(false);
  }, [profile.id, load]);

  // Primera vez: proponemos los intereses de la bienvenida como temas de noticias
  useEffect(() => {
    if (!prefs.topics.length) {
      const fromInterests = topicsFromInterests(profile.answers.interests ?? []);
      if (fromInterests.length) updateSettings({ discover: { ...prefs, topics: fromInterests } });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
    (async () => {
      if (await isStale(profile.id, 1)) refresh(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load]);

  const ranked = useMemo(() => {
    const base = tab === 'saved' ? items : tab === 'all' ? rankFeed(items, prefs.weights) : items;
    return filterFeed(base, query);
  }, [items, prefs.weights, tab, query]);

  const summary = useMemo(() => (tab === 'all' && s.feed.summary && !query ? feedSummary(items, prefs.weights, { name: s.assistant.name, spoilerFree: s.feed.spoilerFree }) : null), [items, prefs.weights, tab, s.feed.summary, s.feed.spoilerFree, s.assistant.name, query]);

  const bumpWeight = (it: FeedItem, delta: number) => updateSettings({ discover: { ...prefs, weights: adjustWeight(adjustWeight(prefs.weights, it.topic, delta), `kind:${it.kind}`, delta > 0 ? 1 : -1) } });

  const open = async (it: FeedItem) => {
    tap();
    await feedRepo.setFlag(profile.id, it.id, 'opened', true);
    bumpWeight(it, 1);
    if (!it.url) return;
    Linking.openURL(it.url).catch(() => toast('No se pudo abrir el enlace'));
  };
  const play = async (it: FeedItem) => {
    const audio = typeof it.extra.audio === 'string' ? it.extra.audio : it.url;
    tap();
    bumpWeight(it, 1);
    if (!playerAvailable() || !(await playEpisode({ url: audio, title: it.title, author: it.author, image: it.imageUrl ?? it.authorAvatar }))) {
      Linking.openURL(it.url || audio).catch(() => toast('No se pudo abrir el episodio'));
    }
  };
  const save = async (it: FeedItem) => {
    await feedRepo.setFlag(profile.id, it.id, 'saved', !it.saved);
    if (!it.saved) bumpWeight(it, 2);
    toast(it.saved ? 'Quitado de guardados' : 'Guardado para después');
    setMore(null);
    load();
  };
  const hide = async (it: FeedItem) => {
    await feedRepo.setFlag(profile.id, it.id, 'hidden', true);
    setMore(null);
    load();
  };
  const less = async (it: FeedItem) => {
    await feedRepo.setFlag(profile.id, it.id, 'hidden', true);
    bumpWeight(it, -2);
    toast(`Vas a ver menos de ${it.topic}`);
    setMore(null);
    load();
  };
  const mute = async (it: FeedItem) => {
    const def = kindDef(it.kind);
    if (!def.source) {
      // Noticias: el tema se quita de la lista
      updateSettings({ discover: { ...prefs, topics: prefs.topics.filter((x) => x.toLowerCase() !== it.topic.toLowerCase()) } });
    } else {
      const sources = await feedSourcesRepo.list(profile.id, def.source);
      const src = sources.find((x) => x.name.toLowerCase() === it.topic.toLowerCase() || x.name.toLowerCase() === it.author.toLowerCase());
      if (src) await feedSourcesRepo.setMuted(profile.id, src.id, true);
    }
    await feedRepo.hideTopic(profile.id, it.topic);
    toast(`${it.topic} silenciado`);
    setMore(null);
    load();
  };
  const addPending = async (it: FeedItem) => {
    const x: any = it.extra;
    const kind = it.kind === 'game' ? 'game' : x.type === 'movie' ? 'movie' : 'show';
    const externalId = it.kind === 'game' ? (x.rawgId ? `rawg:${x.rawgId}` : x.appId ? `steam:${x.appId}` : null) : x.tmdbId ? `tmdb:${x.type}:${x.tmdbId}` : null;
    await watchlistRepo.create(profile.id, { kind, title: it.kind === 'game' ? it.title : it.topic, imageUrl: it.imageUrl, externalId, genres: Array.isArray(x.genres) ? x.genres : [], nextDate: typeof x.episodeDate === 'string' ? x.episodeDate : typeof x.releaseDate === 'string' ? x.releaseDate : null });
    toast('Agregado a Pendientes');
    setMore(null);
  };

  const tabs: { key: Tab; label: string; icon: string; color?: string }[] = [
    { key: 'all', label: 'Para vos', icon: 'Sparkles' },
    ...FEED_KIND_DEFS.filter((d) => kinds.includes(d.kind)).map((d) => ({ key: d.kind as Tab, label: d.label, icon: d.icon, color: d.color })),
    { key: 'saved', label: 'Guardados', icon: 'Bookmark' },
  ];

  const needsKey = tab === 'show' ? !hasTmdb() : tab === 'game' ? !hasRawg() && false : false;

  const header = (
    <View style={{ gap: 12, paddingBottom: 12 }}>
      {searching ? (
        <Field value={query} onChangeText={setQuery} placeholder="Buscar en tu Feed" autoFocus returnKeyType="search" right={<Pressable onPress={() => { setQuery(''); setSearching(false); }} hitSlop={10}><Icon name="X" size={20} color={t.c.textMuted} /></Pressable>} />
      ) : null}
      {summary ? (
        <View style={{ borderRadius: t.radius.lg, borderWidth: 1, borderColor: t.accent.base + '66', backgroundColor: t.c.surface, padding: 14, gap: 10, ...t.glow() }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: t.accent.base, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="Sparkles" size={18} color="#fff" />
            </View>
            <View style={{ flex: 1 }}>
              <T variant="bodyStrong">{s.assistant.name} te resume</T>
              <T variant="small" muted>Lo nuevo de las últimas 24 horas</T>
            </View>
            <Pressable onPress={() => updateSettings({ feed: { ...s.feed, summary: false } })} hitSlop={10} accessibilityLabel="Ocultar resumen"><Icon name="X" size={18} color={t.c.textMuted} /></Pressable>
          </View>
          <T style={{ lineHeight: 22 }}>{summary.text}</T>
        </View>
      ) : null}
      {status ? <T variant="small" muted>{status}</T> : null}
    </View>
  );

  const empty = () => {
    if (tab === 'saved') return <EmptyState icon="Bookmark" title="Nada guardado todavía" text="Mantené apretada una publicación o tocá los tres puntos para guardarla." />;
    if (needsKey) return <EmptyState icon="Tv" title="Próximamente" text="Esta pestaña se activa cuando se cargue la clave gratuita de TMDB en la app." />;
    if (loading) return <EmptyState icon="Newspaper" title="Buscando novedades…" text="Un momento." />;
    const def = tab !== 'all' ? kindDef(tab as FeedKind) : null;
    if (def && def.source) return <EmptyState icon={def.icon} title={`Seguí ${def.followLabel === 'cuenta' ? 'cuentas' : def.followLabel === 'equipo o liga' ? 'equipos o ligas' : def.followLabel + 's'}`} text={`Elegí qué ${def.followLabel} querés ver acá y se actualiza solo.`} action="Elegir" onAction={() => navigation.navigate('FeedSources', { kind: tab })} />;
    if (!followedCount) return <EmptyState icon="Compass" title="¿Qué te interesa?" text="Elegí temas, cuentas, canales o equipos y cada día vas a tener cosas nuevas para ver. Sin likes ni comentarios." action="Elegir intereses" onAction={() => navigation.navigate('FeedSources')} />;
    return <EmptyState icon="WifiOff" title="Todavía no hay publicaciones" text="Conectate a internet y deslizá hacia abajo para traer lo nuevo." action="Actualizar ahora" onAction={() => refresh()} />;
  };

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg }}>
      <View style={{ paddingTop: insets.top + 8, paddingHorizontal: 18, paddingBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <IconButton icon="ChevronLeft" label="Volver" onPress={() => navigation.goBack()} />
        <View style={{ flex: 1 }}>
          <T variant="heading">Feed</T>
          <T variant="caption" secondary numberOfLines={1}>{followedCount ? `${followedCount} ${followedCount === 1 ? 'interés' : 'intereses'} · se actualiza cada hora` : 'Solo lo que te interesa'}</T>
        </View>
        <IconButton icon="Search" label="Buscar" onPress={() => setSearching((v) => !v)} />
        <IconButton icon="SlidersHorizontal" label="Intereses y pestañas" onPress={() => navigation.navigate('FeedSources')} />
      </View>
      <View style={{ height: 50 }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 18, gap: 8, alignItems: 'center' }}>
          {tabs.map((x) => <Chip key={x.key} label={x.label} icon={x.icon} color={x.color} selected={tab === x.key} onPress={() => { setTab(x.key); listRef.current?.scrollToOffset({ offset: 0, animated: false }); }} />)}
        </ScrollView>
      </View>
      <FlatList
        ref={listRef}
        data={ranked}
        keyExtractor={(it) => String(it.id)}
        renderItem={({ item }) => (
          <View style={{ marginBottom: 12 }}>
            <FeedCard item={item} spoilerFree={s.feed.spoilerFree} onOpen={() => open(item)} onMore={() => setMore(item)} onPlay={item.kind === 'podcast' ? () => play(item) : undefined} />
          </View>
        )}
        ListHeaderComponent={header}
        ListEmptyComponent={empty}
        ListFooterComponent={ranked.length ? (
          <View style={{ alignItems: 'center', paddingVertical: 10, gap: 6 }}>
            <Button title="Buscar más novedades" variant="ghost" size="sm" full={false} icon="RefreshCw" onPress={() => refresh(false, tab !== 'all' && tab !== 'saved' ? tab : undefined)} />
            <T variant="small" muted align="center">{tab !== 'all' && tab !== 'saved' ? kindDef(tab).attribution : 'Fuentes: Bluesky, Google News, YouTube, Apple, ESPN, Steam, TMDB, CoinGecko'}</T>
          </View>
        ) : null}
        contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 6, paddingBottom: insets.bottom + 120 }}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={() => refresh(false, tab !== 'all' && tab !== 'saved' ? tab : undefined)} tintColor={t.accent.base} colors={[t.accent.base]} />}
        initialNumToRender={6}
        windowSize={7}
        keyboardShouldPersistTaps="handled"
      />
      <PlayerBar bottom={insets.bottom + 16} />

      <Sheet visible={!!more} onClose={() => setMore(null)} title={more?.title}>
        {more ? (
          <View style={{ gap: 4 }}>
            <SheetRow icon="ExternalLink" label="Abrir" onPress={() => { const it = more; setMore(null); open(it); }} />
            <SheetRow icon={more.saved ? 'BookmarkCheck' : 'Bookmark'} label={more.saved ? 'Quitar de guardados' : 'Guardar para después'} onPress={() => save(more)} />
            {(more.kind === 'game' || more.kind === 'show') ? <SheetRow icon="ListPlus" label="Agregar a Pendientes" onPress={() => addPending(more)} /> : null}
            <SheetRow icon="EyeOff" label="Ocultar esta publicación" onPress={() => hide(more)} />
            <SheetRow icon="ThumbsDown" label={`Menos de ${more.topic}`} onPress={() => less(more)} />
            <SheetRow icon="BellOff" label={`Silenciar ${more.topic}`} onPress={() => mute(more)} danger />
          </View>
        ) : <View />}
      </Sheet>
    </View>
  );
}

function SheetRow({ icon, label, onPress, danger }: { icon: string; label: string; onPress: () => void; danger?: boolean }) {
  const t = useTheme();
  return (
    <Pressable onPress={() => { tap(); onPress(); }} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 13, opacity: pressed ? 0.7 : 1 })}>
      <Icon name={icon} size={20} color={danger ? t.c.danger : t.c.textSecondary} />
      <T color={danger ? t.c.danger : undefined}>{label}</T>
    </Pressable>
  );
}
