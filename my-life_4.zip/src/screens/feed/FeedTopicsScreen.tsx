import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, Chip, Field, Screen, SectionHeader, T, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { TOPIC_CATALOG } from '../../logic/discover';
import { tap } from '../../ui/haptics';

export default function FeedTopicsScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const prefs = profile.settings.discover;
  const [custom, setCustom] = useState('');

  const toggle = (key: string) => {
    tap();
    const on = prefs.topics.includes(key);
    const topics = on ? prefs.topics.filter((x) => x !== key) : [...prefs.topics, key];
    updateSettings({ discover: { ...prefs, topics } });
  };
  const addCustom = () => {
    const v = custom.trim().replace(/\s+/g, ' ').slice(0, 40);
    if (!v) return;
    if (!prefs.topics.some((x) => x.toLowerCase() === v.toLowerCase())) updateSettings({ discover: { ...prefs, topics: [...prefs.topics, v] } });
    setCustom('');
  };
  const customTopics = prefs.topics.filter((k) => !TOPIC_CATALOG.some((c) => c.topics.some((x) => x.key === k)));

  return (
    <Screen title="Temas de noticias" subtitle={`${prefs.topics.length} elegidos`} back>
      <T secondary>Son los temas de las pestañas Noticias y Bluesky. Elegí todo lo que quieras.</T>
      <Field
        value={custom}
        onChangeText={setCustom}
        placeholder="Agregar un tema propio (ej.: Boca, Minecraft, F1)"
        onSubmitEditing={addCustom}
        returnKeyType="done"
        blurOnSubmit={false}
        right={<Pressable onPress={addCustom} hitSlop={10} accessibilityLabel="Agregar tema"><Icon name="Plus" size={22} color={t.accent.base} /></Pressable>}
      />
      {customTopics.length ? (
        <View style={{ gap: 8 }}>
          <SectionHeader title="Tus temas" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {customTopics.map((k) => <Chip key={k} label={k} icon="Hash" selected onPress={() => toggle(k)} />)}
          </View>
        </View>
      ) : null}
      {TOPIC_CATALOG.map((cat) => (
        <View key={cat.name} style={{ gap: 8 }}>
          <SectionHeader title={cat.name} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {cat.topics.map((tp) => <Chip key={tp.key} label={tp.key} icon={tp.icon} color={tp.color} selected={prefs.topics.includes(tp.key)} onPress={() => toggle(tp.key)} />)}
          </View>
        </View>
      ))}
      <SectionHeader title="Actualización" />
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <ToggleRow icon="Wifi" title="Solo con Wi-Fi" subtitle="En segundo plano no usa datos móviles" value={prefs.wifiOnly} onChange={(v) => updateSettings({ discover: { ...prefs, wifiOnly: v } })} />
      </Card>
      <T variant="small" muted>Las noticias vienen de medios públicos según el tema. Lo que tocás ajusta el orden del feed y queda solo en tu celular.</T>
    </Screen>
  );
}
