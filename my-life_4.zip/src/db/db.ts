// Capa de acceso a la base de datos. Se define una interfaz mínima para poder
// usar expo-sqlite en el teléfono y node:sqlite en las pruebas automáticas.

export type SqlValue = string | number | null;

export interface Db {
  exec(sql: string): Promise<void>;
  run(sql: string, params?: SqlValue[]): Promise<{ lastInsertRowId: number; changes: number }>;
  all<T = any>(sql: string, params?: SqlValue[]): Promise<T[]>;
  first<T = any>(sql: string, params?: SqlValue[]): Promise<T | null>;
  transaction(fn: () => Promise<void>): Promise<void>;
}

let current: Db | null = null;

export function setDb(db: Db) {
  current = db;
}

export function getDb(): Db {
  if (!current) throw new Error('La base de datos no está inicializada');
  return current;
}

export function nowStamp(d: Date = new Date()): string {
  const p = (n: number) => (n < 10 ? '0' + n : String(n));
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export const SCHEMA_VERSION = 4;

export const MIGRATIONS: Record<number, string> = {
  1: `
  CREATE TABLE IF NOT EXISTS profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    birth_date TEXT,
    age INTEGER,
    avatar_color TEXT NOT NULL DEFAULT '#8B5CF6',
    answers TEXT NOT NULL DEFAULT '{}',
    settings TEXT NOT NULL DEFAULT '{}',
    security_question TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    due_date TEXT,
    due_time TEXT,
    priority INTEGER NOT NULL DEFAULT 1,
    category TEXT NOT NULL DEFAULT '',
    remind_minutes INTEGER,
    completed_at TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_tasks_profile ON tasks(profile_id, completed_at, due_date);
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'event',
    date TEXT NOT NULL,
    start_time TEXT,
    end_time TEXT,
    all_day INTEGER NOT NULL DEFAULT 0,
    recurrence TEXT NOT NULL DEFAULT 'none',
    weekdays TEXT NOT NULL DEFAULT '',
    until_date TEXT,
    remind_minutes INTEGER,
    location TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_events_profile ON events(profile_id, date);
  CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    term TEXT NOT NULL DEFAULT 'short',
    target_date TEXT,
    progress INTEGER NOT NULL DEFAULT 0,
    completed_at TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_goals_profile ON goals(profile_id);
  CREATE TABLE IF NOT EXISTS habits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    frequency TEXT NOT NULL DEFAULT 'daily',
    weekdays TEXT NOT NULL DEFAULT '',
    target_per_week INTEGER NOT NULL DEFAULT 3,
    reminder_time TEXT,
    color TEXT NOT NULL DEFAULT '#8B5CF6',
    icon TEXT NOT NULL DEFAULT 'sparkles',
    archived INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_habits_profile ON habits(profile_id);
  CREATE TABLE IF NOT EXISTS habit_logs (
    habit_id INTEGER NOT NULL REFERENCES habits(id) ON DELETE CASCADE,
    date TEXT NOT NULL,
    PRIMARY KEY (habit_id, date)
  );
  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL DEFAULT '',
    body TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT '',
    is_list INTEGER NOT NULL DEFAULT 0,
    items TEXT NOT NULL DEFAULT '[]',
    favorite INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_notes_profile ON notes(profile_id, updated_at);
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    emoji TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT 'Otros',
    quantity REAL NOT NULL DEFAULT 1,
    unit_price INTEGER,
    amount INTEGER NOT NULL,
    date TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_tx_profile ON transactions(profile_id, date);
  CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'general',
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    repeat TEXT NOT NULL DEFAULT 'none',
    amount INTEGER,
    notes TEXT NOT NULL DEFAULT '',
    done INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_rem_profile ON reminders(profile_id, date);
  `,
  // v2: cuentas regresivas y rutinas (MY LIFE 2.0). Nunca se modifica la migración 1.
  2: `
  CREATE TABLE IF NOT EXISTS countdowns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT,
    icon TEXT NOT NULL DEFAULT 'Star',
    color TEXT NOT NULL DEFAULT '#A78BFA',
    remind_days_before INTEGER,
    pinned INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_countdowns_profile ON countdowns(profile_id, date);
  CREATE TABLE IF NOT EXISTS routines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'custom',
    icon TEXT NOT NULL DEFAULT 'Sunrise',
    color TEXT NOT NULL DEFAULT '#FBBF24',
    start_time TEXT,
    steps TEXT NOT NULL DEFAULT '[]',
    weekdays TEXT NOT NULL DEFAULT '',
    remind INTEGER NOT NULL DEFAULT 0,
    archived INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_routines_profile ON routines(profile_id, archived);
  CREATE TABLE IF NOT EXISTS routine_logs (
    routine_id INTEGER NOT NULL REFERENCES routines(id) ON DELETE CASCADE,
    date TEXT NOT NULL,
    done_steps TEXT NOT NULL DEFAULT '[]',
    completed INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (routine_id, date)
  );
  `,
  // v3: dólar, suscripciones, metas de ahorro, Descubrir y amigo.
  3: `
  CREATE TABLE IF NOT EXISTS dollar_rates (
    casa TEXT NOT NULL,
    date TEXT NOT NULL,
    buy REAL NOT NULL,
    sell REAL NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (casa, date)
  );
  CREATE TABLE IF NOT EXISTS dollar_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    casa TEXT NOT NULL,
    kind TEXT NOT NULL,
    value REAL NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    last_fired_at TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_dollar_alerts_profile ON dollar_alerts(profile_id);
  CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    icon TEXT NOT NULL DEFAULT 'Receipt',
    color TEXT NOT NULL DEFAULT '#8B5CF6',
    amount INTEGER NOT NULL,
    currency TEXT NOT NULL DEFAULT 'ARS',
    cycle TEXT NOT NULL DEFAULT 'monthly',
    next_date TEXT NOT NULL,
    remind_days_before INTEGER,
    active INTEGER NOT NULL DEFAULT 1,
    category TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_subs_profile ON subscriptions(profile_id, active, next_date);
  ALTER TABLE goals ADD COLUMN saving_target INTEGER;
  ALTER TABLE goals ADD COLUMN saving_saved INTEGER NOT NULL DEFAULT 0;
  ALTER TABLE goals ADD COLUMN saving_currency TEXT NOT NULL DEFAULT 'ARS';
  ALTER TABLE goals ADD COLUMN saving_casa TEXT;
  CREATE TABLE IF NOT EXISTS discover_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    topic TEXT NOT NULL,
    title TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    url TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT '',
    image_url TEXT,
    published_at TEXT NOT NULL,
    saved INTEGER NOT NULL DEFAULT 0,
    hidden INTEGER NOT NULL DEFAULT 0,
    opened INTEGER NOT NULL DEFAULT 0,
    fetched_at TEXT NOT NULL,
    UNIQUE (profile_id, url)
  );
  CREATE INDEX IF NOT EXISTS idx_discover_profile ON discover_items(profile_id, hidden, published_at);
  CREATE TABLE IF NOT EXISTS assistant_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    text TEXT NOT NULL,
    payload TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_assistant_profile ON assistant_messages(profile_id, id);
  `,
  // v4 (2.1): Feed unificado, lo que sigue cada perfil, pendientes, sueldos, inflación, feriados y última entrada por perfil.
  4: `
  ALTER TABLE profiles ADD COLUMN last_login_at TEXT;
  CREATE TABLE IF NOT EXISTS feed_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    kind TEXT NOT NULL DEFAULT 'news',
    topic TEXT NOT NULL DEFAULT '',
    external_id TEXT NOT NULL,
    title TEXT NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    url TEXT NOT NULL DEFAULT '',
    author TEXT NOT NULL DEFAULT '',
    author_handle TEXT NOT NULL DEFAULT '',
    author_avatar TEXT,
    image_url TEXT,
    published_at TEXT NOT NULL,
    likes INTEGER,
    extra TEXT,
    spoiler INTEGER NOT NULL DEFAULT 0,
    saved INTEGER NOT NULL DEFAULT 0,
    hidden INTEGER NOT NULL DEFAULT 0,
    opened INTEGER NOT NULL DEFAULT 0,
    fetched_at TEXT NOT NULL,
    UNIQUE (profile_id, external_id)
  );
  CREATE INDEX IF NOT EXISTS idx_feed_profile ON feed_items(profile_id, hidden, kind, published_at);
  INSERT OR IGNORE INTO feed_items (profile_id, kind, topic, external_id, title, text, url, author, image_url, published_at, saved, hidden, opened, fetched_at)
    SELECT profile_id, 'news', topic, 'news:' || url, title, summary, url, source, image_url, published_at, saved, hidden, opened, fetched_at FROM discover_items;
  CREATE TABLE IF NOT EXISTS feed_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    external_id TEXT NOT NULL,
    name TEXT NOT NULL,
    image_url TEXT,
    extra TEXT,
    muted INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    UNIQUE (profile_id, kind, external_id)
  );
  CREATE INDEX IF NOT EXISTS idx_feed_sources_profile ON feed_sources(profile_id, kind);
  CREATE TABLE IF NOT EXISTS watchlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    rating INTEGER,
    genres TEXT NOT NULL DEFAULT '[]',
    image_url TEXT,
    external_id TEXT,
    notes TEXT NOT NULL DEFAULT '',
    next_date TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_watchlist_profile ON watchlist(profile_id, status, kind);
  CREATE TABLE IF NOT EXISTS salaries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    month TEXT NOT NULL,
    amount INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE (profile_id, month)
  );
  CREATE TABLE IF NOT EXISTS inflation_rates (
    month TEXT PRIMARY KEY,
    value REAL NOT NULL
  );
  CREATE TABLE IF NOT EXISTS holidays (
    date TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT ''
  );
  `,
};

export async function migrate(db: Db): Promise<void> {
  await db.exec('PRAGMA foreign_keys = ON;');
  const row = await db.first<{ user_version: number }>('PRAGMA user_version');
  let version = row?.user_version ?? 0;
  while (version < SCHEMA_VERSION) {
    const next = version + 1;
    const sql = MIGRATIONS[next];
    await db.transaction(async () => {
      await db.exec(sql);
      await db.exec(`PRAGMA user_version = ${next}`);
    });
    version = next;
  }
}
