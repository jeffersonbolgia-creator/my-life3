import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../state/AppContext';
import { Icon } from '../ui/Icon';
import { T, Sheet } from '../ui/kit';
import { tap } from '../ui/haptics';

const TABS: Record<string, { icon: string; label: string }> = {
  Home: { icon: 'House', label: 'Inicio' },
  Agenda: { icon: 'CalendarDays', label: 'Agenda' },
  Finance: { icon: 'Wallet', label: 'Finanzas' },
  More: { icon: 'LayoutGrid', label: 'Más' },
};

export const QUICK_ACTIONS: { key: string; label: string; icon: string; color: string; route: string; params?: any }[] = [
  { key: 'task', label: 'Tarea', icon: 'CircleCheck', color: '#8B5CF6', route: 'TaskForm' },
  { key: 'expense', label: 'Gasto', icon: 'ShoppingBag', color: '#F43F5E', route: 'TxForm', params: { kind: 'expense' } },
  { key: 'income', label: 'Ingreso', icon: 'TrendingUp', color: '#10B981', route: 'TxForm', params: { kind: 'income' } },
  { key: 'event', label: 'Evento', icon: 'CalendarPlus', color: '#3B82F6', route: 'EventForm' },
  { key: 'note', label: 'Nota', icon: 'NotebookPen', color: '#F59E0B', route: 'NoteEditor' },
  { key: 'goal', label: 'Objetivo', icon: 'Target', color: '#D946EF', route: 'GoalForm' },
  { key: 'habit', label: 'Hábito', icon: 'Repeat', color: '#06B6D4', route: 'HabitForm' },
  { key: 'reminder', label: 'Recordatorio', icon: 'BellRing', color: '#F97316', route: 'ReminderForm' },
];

export function QuickAddSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const t = useTheme();
  const nav = useNavigation<any>();
  return (
    <Sheet visible={visible} onClose={onClose} title="Agregar rápido">
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', rowGap: 18, marginBottom: 8 }}>
        {QUICK_ACTIONS.map((a) => (
          <Pressable
            key={a.key}
            onPress={() => {
              tap();
              onClose();
              setTimeout(() => nav.navigate(a.route, a.params), 120);
            }}
            style={({ pressed }) => ({ width: '25%', alignItems: 'center', gap: 8, opacity: pressed ? 0.6 : 1 })}
            accessibilityRole="button"
            accessibilityLabel={`Agregar ${a.label}`}
          >
            <View style={{ width: 56, height: 56, borderRadius: 18, backgroundColor: a.color + (t.dark ? '22' : '18'), alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: a.color + '33' }}>
              <Icon name={a.icon} size={24} color={a.color} />
            </View>
            <T variant="small" secondary align="center">{a.label}</T>
          </Pressable>
        ))}
      </View>
    </Sheet>
  );
}

export function FloatingTabBar({ state, navigation }: BottomTabBarProps) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const [open, setOpen] = useState(false);
  const rot = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(rot, { toValue: open ? 1 : 0, useNativeDriver: true, speed: 18 }).start();
  }, [open, rot]);

  return (
    <>
      <View pointerEvents="box-none" style={{ position: 'absolute', left: 0, right: 0, bottom: 0, paddingBottom: Math.max(insets.bottom, 10) + 6, paddingHorizontal: 16 }}>
        <View style={{
          flexDirection: 'row', alignItems: 'center', height: 68, borderRadius: 26, backgroundColor: t.c.tabBar,
          borderWidth: 1, borderColor: t.c.borderStrong, paddingHorizontal: 6,
          shadowColor: t.dark ? '#000' : t.accent.deep, shadowOpacity: t.dark ? 0.5 : 0.12, shadowRadius: 20, shadowOffset: { width: 0, height: 10 }, elevation: 16,
        }}>
          {state.routes.map((route, index) => {
            const focused = state.index === index;
            if (route.name === 'Add') {
              return (
                <View key={route.key} style={{ flex: 1, alignItems: 'center' }}>
                  <Pressable
                    onPress={() => { tap(); setOpen(true); }}
                    accessibilityRole="button"
                    accessibilityLabel="Agregar"
                    style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.94 : 1 }] })}
                  >
                    <LinearGradient
                      colors={t.gradient}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={{
                        width: 54, height: 54, borderRadius: 19, alignItems: 'center', justifyContent: 'center', marginTop: -26,
                        borderWidth: 3, borderColor: t.c.bg,
                        shadowColor: t.accent.base, shadowOpacity: 0.55, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 10,
                      }}
                    >
                      <Animated.View style={{ transform: [{ rotate: rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '45deg'] }) }] }}>
                        <Icon name="Plus" size={26} color="#fff" strokeWidth={2.4} />
                      </Animated.View>
                    </LinearGradient>
                  </Pressable>
                </View>
              );
            }
            const cfg = TABS[route.name];
            return (
              <Pressable
                key={route.key}
                onPress={() => {
                  tap();
                  const e = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
                  if (!focused && !e.defaultPrevented) navigation.navigate(route.name as never);
                }}
                style={{ flex: 1, alignItems: 'center', justifyContent: 'center', height: 60, gap: 4 }}
                accessibilityRole="tab"
                accessibilityState={{ selected: focused }}
                accessibilityLabel={cfg.label}
              >
                <View style={{ paddingHorizontal: 14, paddingVertical: 5, borderRadius: 14, backgroundColor: focused ? t.accentSoft : 'transparent' }}>
                  <Icon name={cfg.icon} size={21} color={focused ? t.accent.base : t.c.textMuted} strokeWidth={focused ? 2.1 : 1.8} />
                </View>
                <T variant="small" color={focused ? t.c.text : t.c.textMuted} style={{ fontSize: 10.5 }}>{cfg.label}</T>
              </Pressable>
            );
          })}
        </View>
      </View>
      <QuickAddSheet visible={open} onClose={() => setOpen(false)} />
    </>
  );
}
