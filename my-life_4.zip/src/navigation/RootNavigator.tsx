import React from 'react';
import { View } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useApp } from '../state/AppContext';
import type { RootStackParamList, TabParamList } from './types';
import { FloatingTabBar } from './TabBar';

import WelcomeScreen from '../screens/onboarding/WelcomeScreen';
import SetupScreen from '../screens/onboarding/SetupScreen';
import LockScreen from '../screens/auth/LockScreen';
import RecoveryScreen from '../screens/auth/RecoveryScreen';
import HomeScreen from '../screens/home/HomeScreen';
import AgendaScreen from '../screens/agenda/AgendaScreen';
import FinanceScreen from '../screens/finance/FinanceScreen';
import MoreScreen from '../screens/more/MoreScreen';
import TaskFormScreen from '../screens/agenda/TaskFormScreen';
import EventFormScreen from '../screens/agenda/EventFormScreen';
import GoalsScreen from '../screens/goals/GoalsScreen';
import GoalFormScreen from '../screens/goals/GoalFormScreen';
import HabitsScreen from '../screens/habits/HabitsScreen';
import HabitFormScreen from '../screens/habits/HabitFormScreen';
import NotesScreen from '../screens/notes/NotesScreen';
import NoteEditorScreen from '../screens/notes/NoteEditorScreen';
import TxFormScreen from '../screens/finance/TxFormScreen';
import FinanceHistoryScreen from '../screens/finance/FinanceHistoryScreen';
import RemindersScreen from '../screens/reminders/RemindersScreen';
import ReminderFormScreen from '../screens/reminders/ReminderFormScreen';
import StatsScreen from '../screens/stats/StatsScreen';
import SettingsScreen from '../screens/settings/SettingsScreen';
import ProfileEditScreen from '../screens/settings/ProfileEditScreen';
import AppearanceScreen from '../screens/settings/AppearanceScreen';
import NotificationSettingsScreen from '../screens/settings/NotificationSettingsScreen';
import DashboardSettingsScreen from '../screens/settings/DashboardSettingsScreen';
import SecurityScreen from '../screens/settings/SecurityScreen';
import BackupScreen from '../screens/settings/BackupScreen';
import AboutScreen from '../screens/settings/AboutScreen';
import ModulesScreen from '../screens/modules/ModulesScreen';
import SearchScreen from '../screens/search/SearchScreen';
import CountdownsScreen from '../screens/countdowns/CountdownsScreen';
import CountdownFormScreen from '../screens/countdowns/CountdownFormScreen';
import RoutinesScreen from '../screens/routines/RoutinesScreen';
import RoutineFormScreen from '../screens/routines/RoutineFormScreen';
import DollarScreen from '../screens/dollar/DollarScreen';
import SubscriptionsScreen from '../screens/subscriptions/SubscriptionsScreen';
import SubscriptionFormScreen from '../screens/subscriptions/SubscriptionFormScreen';
import FeedScreen from '../screens/feed/FeedScreen';
import FeedSourcesScreen from '../screens/feed/FeedSourcesScreen';
import FeedTopicsScreen from '../screens/feed/FeedTopicsScreen';
import WatchlistScreen from '../screens/watchlist/WatchlistScreen';
import WatchFormScreen from '../screens/watchlist/WatchFormScreen';
import SalaryScreen from '../screens/salary/SalaryScreen';
import HolidaysScreen from '../screens/holidays/HolidaysScreen';
import TransportScreen from '../screens/transport/TransportScreen';
import DollarSettingsScreen from '../screens/dollar/DollarSettingsScreen';
import AlarmScreen from '../screens/alarm/AlarmScreen';
import AssistantScreen from '../screens/assistant/AssistantScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

function Empty() {
  return <View />;
}

function MainTabs() {
  return (
    <Tab.Navigator
      tabBar={(props) => <FloatingTabBar {...props} />}
      screenOptions={{ headerShown: false, lazy: true }}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Agenda" component={AgendaScreen} />
      <Tab.Screen name="Add" component={Empty} />
      <Tab.Screen name="Finance" component={FinanceScreen} />
      <Tab.Screen name="More" component={MoreScreen} />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  const { profiles, profile, theme } = useApp();
  const opts = {
    headerShown: false,
    animation: 'slide_from_right' as const,
    contentStyle: { backgroundColor: theme.c.bg },
  };
  return (
    <Stack.Navigator screenOptions={opts}>
      {profiles.length === 0 ? (
        <Stack.Group>
          <Stack.Screen name="Welcome" component={WelcomeScreen} options={{ animation: 'fade' }} />
          <Stack.Screen name="Setup" component={SetupScreen} initialParams={{ mode: 'first' }} />
        </Stack.Group>
      ) : !profile ? (
        <Stack.Group>
          <Stack.Screen name="Lock" component={LockScreen} options={{ animation: 'fade' }} />
          <Stack.Screen name="Recovery" component={RecoveryScreen} />
          <Stack.Screen name="Setup" component={SetupScreen} initialParams={{ mode: 'add' }} />
        </Stack.Group>
      ) : (
        <Stack.Group>
          <Stack.Screen name="Main" component={MainTabs} options={{ animation: 'fade' }} />
          <Stack.Screen name="TaskForm" component={TaskFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="EventForm" component={EventFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="GoalForm" component={GoalFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="HabitForm" component={HabitFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="NoteEditor" component={NoteEditorScreen} />
          <Stack.Screen name="TxForm" component={TxFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="ReminderForm" component={ReminderFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="Goals" component={GoalsScreen} />
          <Stack.Screen name="Habits" component={HabitsScreen} />
          <Stack.Screen name="Notes" component={NotesScreen} />
          <Stack.Screen name="Stats" component={StatsScreen} />
          <Stack.Screen name="Reminders" component={RemindersScreen} />
          <Stack.Screen name="FinanceHistory" component={FinanceHistoryScreen} />
          <Stack.Screen name="Settings" component={SettingsScreen} />
          <Stack.Screen name="ProfileEdit" component={ProfileEditScreen} />
          <Stack.Screen name="Appearance" component={AppearanceScreen} />
          <Stack.Screen name="NotificationSettings" component={NotificationSettingsScreen} />
          <Stack.Screen name="DashboardSettings" component={DashboardSettingsScreen} />
          <Stack.Screen name="Security" component={SecurityScreen} />
          <Stack.Screen name="Backup" component={BackupScreen} />
          <Stack.Screen name="About" component={AboutScreen} />
          <Stack.Screen name="Modules" component={ModulesScreen} />
          <Stack.Screen name="Search" component={SearchScreen} options={{ animation: 'fade_from_bottom' }} />
          <Stack.Screen name="Countdowns" component={CountdownsScreen} />
          <Stack.Screen name="CountdownForm" component={CountdownFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="Routines" component={RoutinesScreen} />
          <Stack.Screen name="RoutineForm" component={RoutineFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="Dollar" component={DollarScreen} />
          <Stack.Screen name="Subscriptions" component={SubscriptionsScreen} />
          <Stack.Screen name="SubscriptionForm" component={SubscriptionFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="Feed" component={FeedScreen} />
          <Stack.Screen name="FeedSources" component={FeedSourcesScreen} />
          <Stack.Screen name="FeedTopics" component={FeedTopicsScreen} />
          <Stack.Screen name="Watchlist" component={WatchlistScreen} />
          <Stack.Screen name="WatchForm" component={WatchFormScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="Salary" component={SalaryScreen} />
          <Stack.Screen name="Holidays" component={HolidaysScreen} />
          <Stack.Screen name="Transport" component={TransportScreen} />
          <Stack.Screen name="DollarSettings" component={DollarSettingsScreen} />
          <Stack.Screen name="Alarm" component={AlarmScreen} options={{ animation: 'fade', presentation: 'fullScreenModal' }} />
          <Stack.Screen name="Assistant" component={AssistantScreen} options={{ animation: 'slide_from_bottom' }} />
        </Stack.Group>
      )}
    </Stack.Navigator>
  );
}
