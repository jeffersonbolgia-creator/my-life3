// Notificaciones locales reales de Android (no dependen de servidores).
// Se programan en el sistema, así que suenan aunque la app esté cerrada.
//
// Alarmas: cada tipo (recordatorios, tareas, eventos, suscripciones, rutinas) puede sonar como
// alarma (volumen de alarma, atraviesa "No molestar", vibración larga) con uno de cuatro sonidos.
// "Repetir hasta apagar" programa disparos extra cada 35 s (tope 5 min); "Listo" o "Posponer 10 min"
// los cancelan, desde los botones del aviso o desde la pantalla de alarma de la app.

import * as Notifications from 'expo-notifications';
import { Platform, Linking } from 'react-native';
import { buildNotificationPlan, type ChannelId, type PlannedNotification, type PlannedTrigger } from '../logic/notificationPlan';
import { countdownsRepo, dollarAlertsRepo, eventsRepo, goalsRepo, habitsRepo, profilesRepo, remindersRepo, routinesRepo, subscriptionsRepo, tasksRepo } from '../db/repos';
import { ALARM_SOUND_FILES, SNOOZE_MINUTES, alarmChannelId, baseId, decideAlarm, repeatId, repeatTriggers, snoozeId } from '../logic/alarms';
import { ALARM_SOUNDS } from '../db/defaults';
import type { AlertHit } from '../logic/dollar';
import type { AlarmSound } from '../types';

const CHANNELS: { id: ChannelId; name: string; description: string }[] = [
  { id: 'tasks', name: 'Tareas', description: 'Recordatorios de tareas con fecha' },
  { id: 'events', name: 'Eventos y cumpleaños', description: 'Avisos del calendario' },
  { id: 'habits', name: 'Hábitos', description: 'Recordatorios de tus hábitos' },
  { id: 'payments', name: 'Pagos', description: 'Recordatorios de pagos' },
  { id: 'reminders', name: 'Recordatorios', description: 'Recordatorios generales' },
  { id: 'goals', name: 'Objetivos', description: 'Fechas límite de objetivos' },
  { id: 'summary', name: 'Resumen diario', description: 'Resumen programado de tu día' },
  { id: 'countdowns', name: 'Cuentas regresivas', description: 'Avisos de fechas que esperás' },
  { id: 'routines', name: 'Rutinas', description: 'Hora de empezar tu rutina' },
  { id: 'dollar', name: 'Dólar', description: 'Alertas de cotización' },
  { id: 'subscriptions', name: 'Suscripciones', description: 'Avisos antes de cada cobro' },
];

/** Canal silencioso para el Feed y los episodios nuevos (sin sonido ni vibración, importancia baja). */
export const QUIET_CHANNEL = 'quiet';
export const ALARM_CATEGORY = 'alarm';

let initialized = false;

export async function initNotifications(): Promise<void> {
  if (initialized) return;
  initialized = true;
  Notifications.setNotificationHandler({
    handleNotification: async (n: any) => {
      const quiet = n?.request?.content?.data?.quiet === true;
      return {
        shouldShowAlert: true,
        shouldShowBanner: !quiet,
        shouldShowList: true,
        shouldPlaySound: !quiet,
        shouldSetBadge: false,
      } as any;
    },
  });
  try {
    await Notifications.setNotificationCategoryAsync(ALARM_CATEGORY, [
      // Abren la app: con la app cerrada no hay nada corriendo que pueda apagar la repetición, así que la app se abre y lo atiende al instante.
      { identifier: 'snooze', buttonTitle: `Posponer ${SNOOZE_MINUTES} min`, options: { opensAppToForeground: true } },
      { identifier: 'done', buttonTitle: 'Listo', options: { opensAppToForeground: true } },
    ]);
  } catch (e) {
    console.warn('No se pudo crear la categoría de alarma', e);
  }
  if (Platform.OS === 'android') {
    for (const sound of ALARM_SOUNDS) {
      try {
        await Notifications.setNotificationChannelAsync(alarmChannelId(sound), {
          name: sound === 'classic' ? 'Alarmas' : `Alarmas (${sound === 'soft' ? 'suave' : sound === 'chime' ? 'campanitas' : 'campana'})`,
          description: 'Suenan como una alarma, aunque el celular esté en silencio',
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 600, 300, 600, 300, 600, 300, 600, 300, 600],
          lightColor: '#8B5CF6',
          lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
          sound: ALARM_SOUND_FILES[sound],
          audioAttributes: {
            usage: Notifications.AndroidAudioUsage.ALARM,
            contentType: Notifications.AndroidAudioContentType.SONIFICATION,
          },
          bypassDnd: true,
          enableVibrate: true,
        });
      } catch (e) {
        console.warn('No se pudo crear el canal de alarma', sound, e);
      }
    }
    try {
      await Notifications.setNotificationChannelAsync(QUIET_CHANNEL, {
        name: 'Feed y episodios',
        description: 'Avisos silenciosos: episodios nuevos y novedades del Feed',
        importance: Notifications.AndroidImportance.LOW,
        vibrationPattern: [0],
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
        sound: null,
        enableVibrate: false,
      });
    } catch (e) {
      console.warn('No se pudo crear el canal silencioso', e);
    }
    for (const c of CHANNELS) {
      try {
        await Notifications.setNotificationChannelAsync(c.id, {
          name: c.name,
          description: c.description,
          importance: Notifications.AndroidImportance.HIGH,
          vibrationPattern: [0, 220, 120, 220],
          lightColor: '#8B5CF6',
          lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
          sound: 'default',
          enableVibrate: true,
        });
      } catch (e) {
        console.warn('No se pudo crear el canal', c.id, e);
      }
    }
  }
}

export type PermissionState = 'granted' | 'denied' | 'undetermined';

export async function getPermission(): Promise<PermissionState> {
  try {
    const p = await Notifications.getPermissionsAsync();
    if (p.granted) return 'granted';
    return p.canAskAgain === false || p.status === 'denied' ? 'denied' : 'undetermined';
  } catch {
    return 'undetermined';
  }
}

export async function requestPermission(): Promise<PermissionState> {
  try {
    const p = await Notifications.requestPermissionsAsync();
    return p.granted ? 'granted' : p.canAskAgain === false ? 'denied' : 'undetermined';
  } catch {
    return 'denied';
  }
}

export function openSystemNotificationSettings() {
  Linking.openSettings().catch(() => {});
}

function toTrigger(t: PlannedTrigger, channelId: string): any {
  const T = Notifications.SchedulableTriggerInputTypes;
  if (t.kind === 'date') return { type: T.DATE, date: t.date, channelId };
  if (t.kind === 'daily') return { type: T.DAILY, hour: t.hour, minute: t.minute, channelId };
  return { type: T.WEEKLY, weekday: t.weekday, hour: t.hour, minute: t.minute, channelId };
}

async function cancelProfile(profileId: number) {
  const prefix = `p${profileId}:`;
  const all = await Notifications.getAllScheduledNotificationsAsync();
  for (const n of all) {
    // Los avisos pospuestos (":snooze:") se respetan: no los borra una resincronización.
    if (n.identifier?.startsWith(prefix) && !n.identifier.includes(':snooze:')) {
      await Notifications.cancelScheduledNotificationAsync(n.identifier).catch(() => {});
    }
  }
}

/** Android admite unas 500 alarmas pendientes por app: las repeticiones solo se programan para los próximos días. */
const REPEAT_HORIZON_MS = 7 * 86400_000;

/** Programa un aviso y, si es alarma con repetición, sus disparos extra. */
async function scheduleOne(n: PlannedNotification, settings: Parameters<typeof decideAlarm>[1]): Promise<number> {
  const d = decideAlarm(n.channel, settings);
  const content: any = {
    title: n.title,
    body: n.body,
    data: { ...n.data, alarm: d.alarm, baseId: n.id, channel: n.channel },
    sound: d.alarm ? ALARM_SOUND_FILES[d.prefs!.sound] : 'default',
    ...(d.alarm ? { categoryIdentifier: ALARM_CATEGORY, sticky: false, autoDismiss: true, priority: 'max' } : {}),
  };
  let ok = 0;
  await Notifications.scheduleNotificationAsync({ identifier: n.id, content, trigger: toTrigger(n.trigger, d.channelId) });
  ok++;
  const soon = n.trigger.kind !== 'date' || n.trigger.date.getTime() - Date.now() <= REPEAT_HORIZON_MS;
  if (d.alarm && d.prefs?.repeat && soon) {
    const reps = repeatTriggers(n.trigger);
    for (let k = 0; k < reps.length; k++) {
      try {
        await Notifications.scheduleNotificationAsync({ identifier: repeatId(n.id, k + 1), content: { ...content, data: { ...content.data, repeat: k + 1 } }, trigger: toTrigger(reps[k], d.channelId) });
      } catch {}
    }
  }
  return ok;
}

/** Reprograma todas las notificaciones de un perfil según sus datos actuales. */
export async function syncProfileNotifications(profileId: number): Promise<number> {
  await initNotifications();
  const profile = await profilesRepo.get(profileId);
  if (!profile) return 0;
  await cancelProfile(profileId);
  if ((await getPermission()) !== 'granted') return 0;
  const [tasks, events, habits, reminders, goals, countdowns, routines, subscriptions] = await Promise.all([
    tasksRepo.list(profileId),
    eventsRepo.list(profileId),
    habitsRepo.list(profileId),
    remindersRepo.list(profileId),
    goalsRepo.list(profileId),
    countdownsRepo.list(profileId),
    routinesRepo.list(profileId),
    subscriptionsRepo.list(profileId, false),
  ]);
  const plan = buildNotificationPlan({
    profileId,
    profileName: profile.name.split(' ')[0],
    settings: profile.settings.notifications,
    tasks,
    events,
    habits,
    reminders,
    goals,
    countdowns: profile.settings.modules.countdown ? countdowns : [],
    routines: profile.settings.modules.routines ? routines : [],
    subscriptions: profile.settings.modules.subscriptions ? subscriptions : [],
    now: new Date(),
  });
  let ok = 0;
  for (const n of plan) {
    try {
      ok += await scheduleOne(n, profile.settings.notifications);
    } catch (e) {
      console.warn('No se pudo programar', n.id, e);
    }
  }
  return ok;
}

export async function cancelAllForProfile(profileId: number) {
  await cancelProfile(profileId).catch(() => {});
}

const timers = new Map<number, ReturnType<typeof setTimeout>>();

/** Reprograma con una pequeña demora para agrupar varios cambios seguidos. */
export function scheduleSync(profileId: number, delay = 1200) {
  const prev = timers.get(profileId);
  if (prev) clearTimeout(prev);
  timers.set(
    profileId,
    setTimeout(() => {
      timers.delete(profileId);
      syncProfileNotifications(profileId).catch((e) => console.warn('sync notifications', e));
    }, delay),
  );
}

/** Envía una notificación de prueba en 5 segundos (como alarma, con el sonido elegido). */
export async function sendTestNotification(name: string, sound: AlarmSound = 'classic', asAlarm = true): Promise<boolean> {
  await initNotifications();
  if ((await getPermission()) !== 'granted') return false;
  const id = `test:${Date.now()}`;
  await Notifications.scheduleNotificationAsync({
    identifier: id,
    content: {
      title: asAlarm ? 'Prueba de alarma' : 'MY LIFE',
      body: asAlarm ? `¡Listo, ${name}! Así suenan tus alarmas. Tocá "Listo" para apagarla.` : `¡Listo, ${name}! Las notificaciones funcionan.`,
      sound: asAlarm ? ALARM_SOUND_FILES[sound] : 'default',
      data: { alarm: asAlarm, baseId: id, test: true },
      ...(asAlarm ? { categoryIdentifier: ALARM_CATEGORY, priority: 'max' } : {}),
    } as any,
    trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 5, channelId: asAlarm ? alarmChannelId(sound) : 'reminders' } as any,
  });
  return true;
}

export async function countScheduled(profileId: number): Promise<number> {
  const all = await Notifications.getAllScheduledNotificationsAsync();
  return all.filter((n) => n.identifier?.startsWith(`p${profileId}:`) && !/:r\d+$/.test(n.identifier)).length;
}

// ---------- Apagar y posponer alarmas ----------

/** Cancela las repeticiones pendientes y quita de la barra todo lo relacionado con un aviso. */
export async function stopAlarm(id: string): Promise<void> {
  const base = baseId(id);
  try {
    const all = await Notifications.getAllScheduledNotificationsAsync();
    for (const n of all) {
      const nid = n.identifier ?? '';
      if (nid === base || baseId(nid) !== base) continue;
      // Las repeticiones de avisos diarios/semanales son recurrentes: se dejan para mañana (ya se quitan de la barra abajo).
      const trig: any = n.trigger;
      const recurring = trig && (trig.type === 'daily' || trig.type === 'weekly' || typeof trig.hour === 'number');
      if (!recurring) await Notifications.cancelScheduledNotificationAsync(nid).catch(() => {});
    }
  } catch {}
  try {
    const shown = await Notifications.getPresentedNotificationsAsync();
    for (const n of shown) {
      const nid = n.request?.identifier ?? '';
      if (baseId(nid) === base) await Notifications.dismissNotificationAsync(nid).catch(() => {});
    }
  } catch {}
}

/** Vuelve a avisar en 10 minutos (con repetición si el tipo la tiene). */
export async function snoozeAlarm(id: string, content: { title: string; body: string; data?: Record<string, unknown> }, minutes = SNOOZE_MINUTES): Promise<void> {
  await stopAlarm(id);
  const data: any = content.data ?? {};
  const profile = typeof data.profileId === 'number' ? await profilesRepo.get(data.profileId).catch(() => null) : null;
  const channel = (data.channel ?? 'reminders') as ChannelId;
  const settings = profile?.settings.notifications;
  const d = settings ? decideAlarm(channel, settings) : { channelId: alarmChannelId('classic'), alarm: true, prefs: { alarm: true, sound: 'classic' as AlarmSound, repeat: true } };
  const when = new Date(Date.now() + minutes * 60_000);
  const nid = snoozeId(id);
  const body: any = {
    title: content.title,
    body: content.body,
    data: { ...data, alarm: true, baseId: nid, snoozed: true },
    sound: ALARM_SOUND_FILES[d.prefs?.sound ?? 'classic'],
    categoryIdentifier: ALARM_CATEGORY,
    priority: 'max',
  };
  const channelId = d.alarm ? d.channelId : alarmChannelId(d.prefs?.sound ?? 'classic');
  await Notifications.scheduleNotificationAsync({ identifier: nid, content: body, trigger: toTrigger({ kind: 'date', date: when }, channelId) });
  if (d.prefs?.repeat !== false) {
    const reps = repeatTriggers({ kind: 'date', date: when });
    for (let k = 0; k < reps.length; k++) {
      try {
        await Notifications.scheduleNotificationAsync({ identifier: repeatId(nid, k + 1), content: { ...body, data: { ...body.data, repeat: k + 1 } }, trigger: toTrigger(reps[k], channelId) });
      } catch {}
    }
  }
}

// ---------- Avisos inmediatos ----------

/** Muestra en el momento las alertas del dólar que se dispararon (una notificación por alerta). */
export async function notifyDollarHits(hits: AlertHit[]): Promise<number> {
  if (!hits.length) return 0;
  await initNotifications();
  if ((await getPermission()) !== 'granted') return 0;
  let n = 0;
  const now = new Date().toISOString();
  for (const h of hits) {
    const profile = await profilesRepo.get(h.alert.profileId);
    if (!profile || !profile.settings.modules.dollar || !profile.settings.notifications.enabled) continue;
    const discreet = profile.settings.notifications.discreet;
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: discreet ? 'MY LIFE' : h.title,
          body: discreet ? `Tenés un aviso del dólar, ${profile.name.split(' ')[0]}.` : h.body,
          data: { profileId: profile.id, route: 'Dollar' },
          sound: 'default',
        },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 1, channelId: 'dollar' } as any,
      });
      await dollarAlertsRepo.markFired(h.alert.id, now);
      n++;
    } catch (e) {
      console.warn('No se pudo avisar la alerta', e);
    }
  }
  return n;
}

/** Aviso silencioso (sin sonido ni vibración) para el Feed: episodio nuevo, estreno, etc. */
export async function notifyQuiet(profileId: number, title: string, body: string, route = 'Feed', key = ''): Promise<boolean> {
  await initNotifications();
  if ((await getPermission()) !== 'granted') return false;
  try {
    await Notifications.scheduleNotificationAsync({
      identifier: key ? `quiet:${profileId}:${key}` : undefined,
      content: { title, body, data: { profileId, route, quiet: true }, sound: null } as any,
      trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 1, channelId: QUIET_CHANNEL } as any,
    });
    return true;
  } catch (e) {
    console.warn('No se pudo mandar el aviso silencioso', e);
    return false;
  }
}

/** Cómo dejar que las alarmas suenen a tiempo en celulares que ahorran batería (Motorola, Samsung). */
export async function openBatterySettings(): Promise<void> {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const IntentLauncher = require('expo-intent-launcher');
    await IntentLauncher.startActivityAsync('android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS');
  } catch {
    openSystemNotificationSettings();
  }
}

/** Permiso de alarmas exactas (Android 12+). Si no se puede abrir el ajuste, no pasa nada. */
export async function openExactAlarmSettings(): Promise<void> {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const IntentLauncher = require('expo-intent-launcher');
    await IntentLauncher.startActivityAsync('android.settings.REQUEST_SCHEDULE_EXACT_ALARM', { data: 'package:com.mylife.organizer' });
  } catch {
    openSystemNotificationSettings();
  }
}
