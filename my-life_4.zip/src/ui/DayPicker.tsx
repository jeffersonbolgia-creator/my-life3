import React from 'react';
import { Pressable, View } from 'react-native';
import { useTheme } from '../state/AppContext';
import { T } from './kit';
import { tap } from './haptics';
import { WEEK_ORDER, WEEKDAYS_LETTER } from '../lib/dates';

export function DayPicker({ value, onChange }: { value: number[]; onChange: (v: number[]) => void }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', gap: 6 }}>
      {WEEK_ORDER.map((d) => {
        const on = value.includes(d);
        return (
          <Pressable
            key={d}
            onPress={() => { tap(); onChange(on ? value.filter((x) => x !== d) : [...value, d]); }}
            style={{ flex: 1, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? t.accent.base : t.c.surface2, borderWidth: 1, borderColor: on ? t.accent.base : t.c.border }}
            accessibilityRole="checkbox"
            accessibilityState={{ checked: on }}
          >
            <T variant="bodyStrong" color={on ? '#fff' : t.c.textSecondary}>{WEEKDAYS_LETTER[d]}</T>
          </Pressable>
        );
      })}
    </View>
  );
}

