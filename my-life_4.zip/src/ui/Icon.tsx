import React from 'react';
import * as Lucide from 'lucide-react-native';

// Envoltorio de íconos Lucide. Si un nombre cambiara entre versiones de la
// librería, se prueban nombres alternativos y nunca se rompe la pantalla.
const ALIASES: Record<string, string[]> = {
  House: ['Home'],
  CircleCheck: ['CheckCircle2', 'CircleCheckBig', 'CheckCircle'],
  CircleCheckBig: ['CheckCircle', 'CircleCheck'],
  ChartColumn: ['BarChart3', 'ChartBar', 'BarChart'],
  ChartPie: ['PieChart'],
  EllipsisVertical: ['MoreVertical'],
  LayoutGrid: ['Grid', 'Grid2x2'],
  Grid2x2: ['LayoutGrid'],
  CircleDollarSign: ['DollarSign'],
  SquarePen: ['Edit', 'PenSquare', 'Pencil'],
  CalendarClock: ['Calendar'],
  ChartNoAxesColumnIncreasing: ['BarChart2', 'ChartColumn'],
  Settings2: ['Settings'],
  LockKeyhole: ['Lock'],
};

export type IconName = string;

const cache = new Map<string, React.ComponentType<any>>();

function resolve(name: string): React.ComponentType<any> {
  const hit = cache.get(name);
  if (hit) return hit;
  const lib = Lucide as unknown as Record<string, React.ComponentType<any> | undefined>;
  let comp = lib[name];
  if (!comp) for (const alt of ALIASES[name] ?? []) if (lib[alt]) { comp = lib[alt]; break; }
  if (!comp) comp = lib.Circle ?? (() => null);
  cache.set(name, comp);
  return comp;
}

export function Icon({ name, size = 20, color, strokeWidth = 1.8 }: { name: IconName; size?: number; color: string; strokeWidth?: number }) {
  const C = resolve(name);
  return <C size={size} color={color} strokeWidth={strokeWidth} absoluteStrokeWidth={false} />;
}
