import * as Haptics from 'expo-haptics';
import { ToastAndroid, Platform } from 'react-native';

let enabled = true;
export function setHapticsEnabled(v: boolean) {
  enabled = v;
}

export function tap() {
  if (enabled) Haptics.selectionAsync().catch(() => {});
}

export function success() {
  if (enabled) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
}

export function warn() {
  if (enabled) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
}

export interface SnackMessage { text: string; action?: () => void; actionLabel?: string }
let snackHandler: ((m: SnackMessage) => void) | null = null;
/** La app registra acá su barra de avisos con botón (para "Deshacer"). */
export function setSnackHandler(h: ((m: SnackMessage) => void) | null) {
  snackHandler = h;
}

/** Aviso corto. Con `action` muestra un botón (por defecto "Deshacer") dentro de la app. */
export function toast(msg: string, action?: () => void, actionLabel = 'Deshacer') {
  if (action && snackHandler) {
    snackHandler({ text: msg.replace(/ · tocá para deshacer$/i, ''), action, actionLabel });
    return;
  }
  if (Platform.OS === 'android') ToastAndroid.show(msg, ToastAndroid.SHORT);
  else snackHandler?.({ text: msg });
}
